%*************************************************************************
%                 Balance control with Hip joint control
%*********************By Bingheng WANG, Dec.30,2019***********************
%% Configuration codes 
clear all
jointNum=8;   %10
torqueLimit=[60;60;30;30;20;20;10;5];
% jointName=["LeftHip_joint","LeftWheel_joint","RightHip_joint",...
%     "RightWheel_joint","Tail_joint","Shoulder_joint","Elbow_joint","Wrist_joint"]; 
jointName=["LeftHip_joint","RightHip_joint","LeftKnee_joint","RightKnee_joint","LeftWheel_joint","RightWheel_joint","Tail_joint","Wrist_joint"];  
%jointName=["LeftWheel_joint","RightWheel_joint","Tail_joint","Wrist_joint"];  
displayOn=true;
torque=zeros(jointNum,1); 


%% Connect to the Vrep
% 1. load api library
vrep=remApi('remoteApi'); % using the prototype file (remoteApiProto.m)
% 2. close all the potential link
vrep.simxFinish(-1);   
% 3. wait for connecting vrep, detect every 0.2s
while true
    clientID=vrep.simxStart('127.0.0.1',19997,true,true,5000,5);
    if clientID>-1 
        break;
    else
        pause(0.2);
        disp('please run the simulation on vrep...')
    end
end
disp('Connection success!')
% 4. set the simulation time step
tstep = 0.005;  % 5ms per simulation pass
vrep.simxSetFloatingParameter(clientID,vrep.sim_floatparam_simulation_time_step,tstep,vrep.simx_opmode_oneshot);
% 5. open the synchronous mode to control the objects in vrep
vrep.simxSynchronous(clientID,true);

%% Simulation Initialization
vrep.simxStartSimulation(clientID,vrep.simx_opmode_oneshot);
% get the handles
jointHandle=zeros(jointNum,1); 
for i=1:jointNum  % handles of the left and right arms
    [~,returnHandle]=vrep.simxGetObjectHandle(clientID,char(jointName(i)),vrep.simx_opmode_blocking);
    jointHandle(i)=returnHandle;
end
% set the target velocity to 0.1 and torque to 0
for i=1:jointNum
    vrep.simxSetJointForce(clientID,jointHandle(i),0,vrep.simx_opmode_oneshot);
    vrep.simxSetJointTargetVelocity(clientID,jointHandle(i),0.1,vrep.simx_opmode_oneshot);
end
baseName='Body_link_visual';
wheelName='RightWheel_link_visual';
wheelleft='LeftWheel_link_visual';
Shankleft='LeftShank_link_visual';
Shankright='RightShank_link_visual';
LeftHip='LeftHip_joint';
RightHip='RightHip_joint';
[~,baseHandle]=vrep.simxGetObjectHandle(clientID,baseName,vrep.simx_opmode_blocking);  
[~,wheelHandle]=vrep.simxGetObjectHandle(clientID,wheelName,vrep.simx_opmode_blocking);  
[~,wheelleftHandle]=vrep.simxGetObjectHandle(clientID,wheelleft,vrep.simx_opmode_blocking);  
[~,ShankleftHandle]=vrep.simxGetObjectHandle(clientID,Shankleft,vrep.simx_opmode_blocking);  
[~,ShankrightHandle]=vrep.simxGetObjectHandle(clientID,Shankright,vrep.simx_opmode_blocking);  
[~,LeftHipHandle]=vrep.simxGetObjectHandle(clientID,LeftHip,vrep.simx_opmode_blocking);  
[~,RightHipHandle]=vrep.simxGetObjectHandle(clientID,RightHip,vrep.simx_opmode_blocking);  
vrep.simxSynchronousTrigger(clientID);
disp('Handles available!')
% first call to read the joints' configuration and end-effector pose, the mode is chosen to be simx_opmode_streaming
jointConfig=zeros(jointNum,1); 
% get current joint position
for i=1:jointNum
    [~,jpos]=vrep.simxGetJointPosition(clientID,jointHandle(i),vrep.simx_opmode_streaming);
    if i>=5 && i<=7
      jointConfig(i)=-jpos; % inverse the joint angles of tail and wheel joints
    else
        jointConfig(i)=jpos;
    end
end

% get simulation time
currCmdTime=vrep.simxGetLastCmdTime(clientID);

lastCmdTime=currCmdTime;
jointConfig0=jointConfig;
jointConfigLast=jointConfig+[0;0;0;0;43.9823;43.9823;0;0];
[~,baseposition0]=vrep.simxGetObjectPosition(clientID,baseHandle,-1,vrep.simx_opmode_streaming);% defined in inertial frame
[~,wheelposition0]=vrep.simxGetObjectPosition(clientID,wheelHandle,-1,vrep.simx_opmode_streaming);
[~,wheelleftposition0]=vrep.simxGetObjectPosition(clientID,wheelleftHandle,-1,vrep.simx_opmode_streaming);  
[~,Shankleftposition0]=vrep.simxGetObjectPosition(clientID,ShankleftHandle,-1,vrep.simx_opmode_streaming);  
[~,Shankrightposition0]=vrep.simxGetObjectPosition(clientID,ShankrightHandle,-1,vrep.simx_opmode_streaming);  
[~,baseorientation0]=vrep.simxGetObjectOrientation(clientID,baseHandle,-1,vrep.simx_opmode_streaming);% defined in inertial frame
[~,LeftHipposition0]=vrep.simxGetObjectPosition(clientID,LeftHipHandle,-1,vrep.simx_opmode_streaming);  
 pause(0.1)
[~,baseposition0]=vrep.simxGetObjectPosition(clientID,baseHandle,-1,vrep.simx_opmode_buffer);% defined in inertial frame
[~,wheelposition0]=vrep.simxGetObjectPosition(clientID,wheelHandle,-1,vrep.simx_opmode_buffer);
[~,wheelleftposition0]=vrep.simxGetObjectPosition(clientID,wheelleftHandle,-1,vrep.simx_opmode_buffer);  
[~,Shankleftposition0]=vrep.simxGetObjectPosition(clientID,ShankleftHandle,-1,vrep.simx_opmode_buffer);  
[~,Shankrightposition0]=vrep.simxGetObjectPosition(clientID,ShankrightHandle,-1,vrep.simx_opmode_buffer);  
[~,baseorientation0]=vrep.simxGetObjectOrientation(clientID,baseHandle,-1,vrep.simx_opmode_streaming);% defined in inertial frame
[~,LeftHipposition0]=vrep.simxGetObjectPosition(clientID,LeftHipHandle,-1,vrep.simx_opmode_streaming);  

deltaposition0 = baseposition0-wheelposition0; % position of pendulum relative to the wheel
r = 0.1;%radius of wheel
d = 0.167;%distance from the wheel to the center of body
m = 10;%mass excluding the shanklinks and wheels
mp= 1;%mass of balance block
g = 9.8;
L2= 0.3;%length of Thighlink
mb=8;%mass of the base and the end-effector
mg=0.5;%mass of the arm and gripper
Ib= 0.29;% inertia moment of pitch axis of the main body
dh= 0.1;% height of C.O.M of the main body relative to the hip joint
dhg=0.1;% height of C.O.M of the gripper
dLg=0.15;
yawangle0 = (jointConfigLast(6)-jointConfigLast(5))*r/(2*d);% yaw angle obtained by the difference of the wheel rotation angles
px0 = deltaposition0(1);
py0 = deltaposition0(2);
pz0 = deltaposition0(3);
thetaLast = atan((px0*cos(yawangle0)-py0*sin(yawangle0))/pz0);
 positionswleft0=Shankleftposition0-wheelleftposition0;
    positionswright0=Shankrightposition0-wheelposition0;
    pswlx0 = positionswleft0(1);
    pswly0 = positionswleft0(2);
    pswlz0 = positionswleft0(3);
    pswrx0 = positionswright0(1);
    pswry0 = positionswright0(2);
    pswrz0 = positionswright0(3);
    theta0l = atan((pswlx0*cos(yawangle0)-pswly0*sin(yawangle0))/pswlz0);%tilting angle of Shankleft
    theta0r = atan((pswrx0*cos(yawangle0)-pswry0*sin(yawangle0))/pswrz0);%tilting angle of Shankright
theta0lLast = theta0l;
theta0rLast = theta0r;
positionbaseleft0=baseposition0-LeftHipposition0;
    pbhx0  = positionbaseleft0(1);
    pbhy0  = positionbaseleft0(2);
    pbhz0  = positionbaseleft0(3);
    pitch0 = atan((pbhx0*cos(yawangle0)-pbhy0*sin(yawangle0))/pbhz0);%pitch angle of base
    pitchLast = pitch0;% initial pitch angle of the base
vrep.simxSynchronousTrigger(clientID);         % every calls this function, verp is triggered, 50ms by default

%% Simulation Start
t=0;  % start the simulation
k=1;
kdl=2;%PID gain for left knee joint
kpl=100;
kil=0.1;
kdr=2;
kpr=110;
kir=0.1;

kphl=5500;%PID for left hip joint
kdhl=55;
kihl=0.1;
kphr=1000;
kdhr=11;
kihr=0.1;

errorintegl=0;%angle error integration
errorintegr=0;
errorinteghl=0;
errorinteghr=0;
theta10l = -60/180*pi;
theta10r = -60/180*pi;
tbased   = 30/180*pi; % desired and fixed angle of hip joint
kt = 0/180*pi;%angle change rate
basepositionLast=baseposition0;
dqLast = zeros(8,1);
Lp   =0.12;
dl   =0.1;
t2d  =asin(dl/Lp);

% tpd  =-mp*g*dl;
xref = [0;t2d;0.5;0;0;0];

while (vrep.simxGetConnectionId(clientID) ~= -1)  % vrep connection is still active
    % time update
    vrep.simxSetJointPosition(clientID,LeftHipHandle,tbased,vrep.simx_opmode_oneshot);
    vrep.simxSetJointPosition(clientID,RightHipHandle,tbased,vrep.simx_opmode_oneshot);
    currCmdTime=vrep.simxGetLastCmdTime(clientID);
    dt=(currCmdTime-lastCmdTime)/1000;              % simulation step, unit: s 
    % read the joints' and tips' configuration (position and velocity)
    for i=1:jointNum
        [~,jpos]=vrep.simxGetJointPosition(clientID,jointHandle(i),vrep.simx_opmode_buffer);
            if i>=5&&i<=7
               jointConfig(i)=-jpos; 
            else
               jointConfig(i)=jpos;
            end
    end
    jointConfig=jointConfig+[0;0;0;0;43.9823;43.9823;0;0];
    [~,baseposition]=vrep.simxGetObjectPosition(clientID,baseHandle,-1,vrep.simx_opmode_buffer);% defined in inertial frame
    [~,wheelposition]=vrep.simxGetObjectPosition(clientID,wheelHandle,-1,vrep.simx_opmode_buffer);
    [~,wheelleftposition]=vrep.simxGetObjectPosition(clientID,wheelleftHandle,-1,vrep.simx_opmode_buffer);  
    [~,Shankleftposition]=vrep.simxGetObjectPosition(clientID,ShankleftHandle,-1,vrep.simx_opmode_buffer);  
    [~,Shankrightposition]=vrep.simxGetObjectPosition(clientID,ShankrightHandle,-1,vrep.simx_opmode_buffer);  
    [~,baseorientation]=vrep.simxGetObjectOrientation(clientID,baseHandle,-1,vrep.simx_opmode_streaming);% defined in inertial frame
    [~,LeftHipposition]=vrep.simxGetObjectPosition(clientID,LeftHipHandle,-1,vrep.simx_opmode_streaming);  
    yawangle = (jointConfig(6)-jointConfig(5))*r/(2*d);% yaw angle obtained by the difference of the wheel rotation angles
    % attitude of the base (pitch angle)
    positionbaseleft=baseposition-LeftHipposition;
    pbhx  = positionbaseleft(1);
    pbhy  = positionbaseleft(2);
    pbhz  = positionbaseleft(3);
    pitch = atan((pbhx*cos(yawangle)-pbhy*sin(yawangle))/pbhz);%pitch angle of base
    dpitch=(pitch-pitchLast)/dt;
    Pitch(k)=pitch;
    % tilt angle
    BasePosition(:,k)=baseposition.';%save the absolute baseposition
    vbase = (baseposition.'-basepositionLast)/dt;
    gapl  = jointConfigLast(5)-jointConfig(5);
    gapr  = jointConfigLast(6)-jointConfig(6);
    if gapl<=-5 %remove the gap between two wheel angles
        jointConfig(5)=jointConfig(5)-round(abs(gapl)/(2*pi))*2*pi;
    end
    if gapr<=-5
        jointConfig(6)=jointConfig(6)-round(abs(gapr)/(2*pi))*2*pi;
    end
    Jointangle(:,k)=jointConfig;%save the joint angles in joint space
    deltaposition = baseposition-wheelposition; % position of pendulum relative to the wheel
    px = deltaposition(1);
    py = deltaposition(2);
    pz = deltaposition(3);
    theta = atan((px*cos(yawangle)-py*sin(yawangle))/pz);
    Tiltangle(k)=theta;
    dtheta=(theta-thetaLast)/dt;
    positionswleft=Shankleftposition-wheelleftposition;
    positionswright=Shankrightposition-wheelposition;
    pswlx = positionswleft(1);
    pswly = positionswleft(2);
    pswlz = positionswleft(3);
    pswrx = positionswright(1);
    pswry = positionswright(2);
    pswrz = positionswright(3);
    theta0l = atan((pswlx*cos(yawangle)-pswly*sin(yawangle))/pswlz);%tilting angle of Shankleft
    theta0r = atan((pswrx*cos(yawangle)-pswry*sin(yawangle))/pswrz);%tilting angle of Shankright
    % using Finit Difference Method to get the velocity of joints' configuration (a simple version)
    q=jointConfig;       dq=(q-jointConfigLast)./dt;  % column vector
    ddtp = (dq(7)-dqLast(7))/dt;
    dtheta0l = (theta0l-theta0lLast)./dt;
    dtheta0r = (theta0r-theta0rLast)./dt;

    dyaw = r/(2*d)*(dq(6)-dq(5));
    Yawrate(k)=dyaw;
    Qdot(:,k)=dq;
    v    = r/2*(dq(5)+dq(6));
    vb    = sqrt(vbase(1)^2+vbase(2)^2);
    Vb(k) = vb;
    Vw(k) = v;
    x    = [theta;q(7);v;dyaw;dtheta;dq(7)];
    %control gain for the LQR controller
    l1   =sqrt(px^2+pz^2);%length of the pendulum
    if l1>=0.6
        L1=0.6;
    elseif l1<=0.3
        L1=0.3;
    else
        L1=l1;
    end
    i=round((L1-0.3)/0.5);
switch i
 case{0}
        K=[-10.1358555178508,0.0849438083830591,-0.701210357598133,-0.695232143312089,-1.19503886327180,0.0881463686846291;-10.1358555178508,0.0849438083830583,-0.701210357598132,0.695232143312089,-1.19503886327180,0.0881463686846288;0.961915339288864,1.01185874597629,0.128872296457380,3.71354483426066e-16,0.250092588622973,1.00014197001020];
    case{1}
        K=[-10.6207577512335,0.0754220858188641,-0.702546234324012,-0.695232143312089,-1.29614067854283,0.0775947429615823;-10.6207577512335,0.0754220858188639,-0.702546234324010,0.695232143312089,-1.29614067854283,0.0775947429615818;0.895814646878380,1.01072298222530,0.113391257486194,-2.28231173060975e-16,0.237809615274966,1.00191761081283];
    case{2}
        K=[-11.0272304016532,0.0676914711055525,-0.703485376082013,-0.695232143312089,-1.39688007436710,0.0691854419510079;-11.0272304016532,0.0676914711055539,-0.703485376082013,0.695232143312089,-1.39688007436710,0.0691854419510091;0.836191840398102,1.00981660274231,0.101077451874750,-3.35928008684414e-16,0.227607834972050,1.00316890187455];
    case{3}
        K=[-11.3756778536348,0.0613399577652718,-0.704166085014087,-0.695232143312089,-1.49695808711044,0.0623680545583488;-11.3756778536348,0.0613399577652720,-0.704166085014085,0.695232143312089,-1.49695808711044,0.0623680545583488;0.783396156962357,1.00906127333332,0.0911057047163694,-1.03228019493794e-16,0.219034411800283,1.00407685126115];
    case{4}
        K=[-11.6798967247249,0.0560521261724093,-0.704673199296938,-0.695232143312089,-1.59622501959394,0.0567501096158171;-11.6798967247249,0.0560521261724090,-0.704673199296939,0.695232143312089,-1.59622501959394,0.0567501096158170;0.736865617434850,1.00841631179943,0.0828936932778537,3.15542532058181e-16,0.211738303947435,1.00475349415934];
    case{5}
        K=[-11.9495582778682,0.0515930912400907,-0.705060205491644,-0.695232143312089,-1.69461673904377,0.0520511816149798;-11.9495582778682,0.0515930912400920,-0.705060205491645,0.695232143312089,-1.69461673904377,0.0520511816149802;0.695808746125675,1.00785702265459,0.0760277137900880,-7.46342607272000e-16,0.205454533542814,1.00526982881166];
    case{6}
        K=[-12.1916498166494,0.0477882373298249,-0.705361829574090,-0.695232143312089,-1.79211841533061,0.0480684180467947;-12.1916498166494,0.0477882373298213,-0.705361829574091,0.695232143312089,-1.79211841533061,0.0480684180467941;0.659445515641338,1.00736665720362,0.0702095346785102,1.61055197244394e-15,0.199983376498262,1.00567209634434];
    otherwise
        K=[-11.3756778536348,0.0613399577652718,-0.704166085014087,-0.695232143312089,-1.49695808711044,0.0623680545583488;-11.3756778536348,0.0613399577652720,-0.704166085014085,0.695232143312089,-1.49695808711044,0.0623680545583488;0.783396156962357,1.00906127333332,0.0911057047163694,-1.03228019493794e-16,0.219034411800283,1.00407685126115];
end
    
     torq = -K*(x-xref);%control torque obtained by LQR for wheel motors and pendulum motor
     theta1dl =theta10l-kt*t;%desired left knee angle
     theta1dr =theta10r-kt*t;%desired right knee angle
     if theta1dl<=-80/180*pi && theta1dr<=-80/180*pi
         t1dl=-80/180*pi;
         t1dr=-80/180*pi;
     else
         t1dl=theta1dl;
         t1dr=theta1dr;
     end
     Desiredt1l(k)=t1dl;
%      theta2ld = -theta0l-q(3);
%      Theta2ld(k)=theta2ld;
%      dtheta2ld = -dtheta0l-dq(3);
%      theta2rd = -theta0r-q(4);
%      dtheta2rd = -dtheta0r-dq(4);
     Hl       =-1/2*m*g*L2*sin(theta0l+q(3));
     Hr       =-1/2*m*g*L2*sin(theta0r+q(4));
%      Hkneel   =-1/2*8.8*g*0.1*sin(theta0l+q(3)+q(1));
%      Hkneer   =-1/2*8.8*g*0.1*sin(theta0r+q(4)+q(2));
     torqlknee=Hl+kdl*(-kt-dq(3))+kpl*(t1dl-q(3))+kil*errorintegl;
     torqrknee=Hr+kdr*(-kt-dq(4))+kpl*(t1dr-q(4))+kir*errorintegr; 
%      torqlhip =Hkneel+kdlk*(dtheta2ld-dq(1))+kplk*(theta2ld-q(1))+kilk*errorintegkl;
%      torqrhip =Hkneer+kdrk*(dtheta2rd-dq(2))+kprk*(theta2rd-q(2))+kirk*errorintegkr;
     Error(k)=t1dl-q(3);
   %if t<=2 || t>=2.1
  tpd  = -mp*g*Lp*sin(q(7));
  torql=torq(1);
  torqr=torq(2);
     k=k+1;
     tabsbl=theta0l+q(3)+q(1);
     tabsbr=theta0r+q(4)+q(2);
     F = mp*g*cos(q(7))-Lp*dq(7)^2;
     Ft= mp*g*sin(q(7))+mp*Lp*ddtp;
     torqlhip=1/2*(torq(3)+tpd-F*(dh*sin(q(7))-dl*cos(q(7)))+Ft*(dh*cos(q(7))+dl*sin(q(7)))-mb*g*dh*sin(tabsbl)-mg*g*(dh*sin(tabsbl)+dLg*cos(tabsbl)+dhg*sin(tabsbl))+Ib*(kphl*(tbased-q(1))-kdhl*dq(1)+kihl*errorinteghl));
     torqrhip=1/2*(torq(3)+tpd-F*(dh*sin(q(7))-dl*cos(q(7)))+Ft*(dh*cos(q(7))+dl*sin(q(7)))-mb*g*dh*sin(tabsbr)-mg*g*(dh*sin(tabsbr)+dLg*cos(tabsbr)+dhg*sin(tabsbr))+Ib*(kphr*(tbased-q(2))-kdhr*dq(2)+kihr*errorinteghr));
    torque = [torqlhip;torqrhip;torqlknee;torqrknee;-torql;-torqr;-(torq(3)+tpd);0];
    %torque = [torq(1);torq(2);-torq(3);0.1];
   
    %torque = [1;1;1];
    % 2. display the acquisition data, or store them if plotting is needed.
%     if displayOn==true
%         disp('joints config:');       disp(q'.*180/pi);
%         disp('joints dconfig:');      disp(dq'.*180/pi);
%     end

    %torque=[20,20,10];

    %   3.3 set the torque in vrep way
    for i=1:jointNum
        if sign(torque(i))<0
            setVel=-9999; % set a trememdous large velocity for the screwy operation of the vrep torque control implementaion
            if torque(i)<-torqueLimit(i)
                setTu=-torqueLimit(i);
            else
                setTu=-torque(i);
            end
        else
            setVel=9999;
            if torque(i)>torqueLimit(i)
                setTu=torqueLimit(i);
            else
                setTu=torque(i);
            end
        end
%         if i<=2 %lock the hip motor!!!
%             setVel=0;
%         end
        vrep.simxSetJointTargetVelocity(clientID,jointHandle(i),setVel,vrep.simx_opmode_oneshot);
        vrep.simxSetJointForce(clientID,jointHandle(i),setTu,vrep.simx_opmode_oneshot);
        Torque(i,k)=setTu; 
    end
    % data recording for plotting
%     E=[E qe];    Q=[Q q];        QD=[QD qd];
%     DQ=[DQ dq];  DQD=[DQD dqd];  TAU=[TAU torque];

    % 4. update vrep(the server side)
    %tipPosLast=tipPos;       
    %tipOrtLast=tipOrt;
    lastCmdTime=currCmdTime;
    jointConfigLast=jointConfig;   
    basepositionLast=baseposition.';
    thetaLast=theta;
    pitchLast=pitch;
    dqLast=dq;
    errorintegl=errorintegl+(t1dl-q(3))*dt;
    errorintegr=errorintegr+(t1dr-q(4))*dt;
    errorinteghl=errorinteghl+(tbased-q(1))*dt;
    errorinteghr=errorinteghr+(tbased-q(2))*dt;
%     errorintegkl=errorintegkl+(theta2ld-q(1))*dt;
%     errorintegkr=errorintegkr+(theta2rd-q(2))*dt;
    vrep.simxSynchronousTrigger(clientID);
    t=t+dt; % updata simulation time
    Time(k)=t;
end
vrep.simxFinish(-1);  % close the link
vrep.delete();        % destroy the 'vrep' class

%%
% figure(1); hold off;
% subplot(411); plot(E(1,:),'r'); hold on; plot(E(2,:),'b'); title('error')
% subplot(412); plot(Q(1,:),'r'); hold on; plot(Q(2,:),'b');  plot(QD(1,:),'k'); hold on; plot(QD(2,:),'k'); title('trajectory')
% subplot(413); plot(DQ(1,:),'r'); hold on; plot(DQ(2,:),'b');  plot(DQD(1,:),'k'); hold on; plot(DQD(2,:),'k'); title('velocity')
% subplot(414); plot(TAU(1,:),'r'); hold on; plot(TAU(2,:),'b'); title('torque')

