%*************************************************************************
% Quadratic programming test for SLIP model trajectory optimization
%***************By Bingheng WANG, on Mar.4, 2020**************************
clear all
%------------------%
%Parameters Setting
%------------------%
g    = 9.8;
m    = 9.86;%total mass
kp   = 100;%proportional coefficient of knee torque
kd   = 10;%damping coefficient of knee torque
dt   = 0.001;%sampling time
r    = 0.1;%radius of wheel
%---------------------------------------%
%Initial States and Desired Final States
%---------------------------------------%
L0   = 0.84;%initial resting length of the spring excluding r
z0   = 0.7;%initial actual length of the spring including r
dz0  = 0;%initial velocity of actual length
x0   = [z0;dz0];
Tf   = 1.5;%final time
N    = Tf/dt;%prediction horizon
%calculate the desired final height and velocity
zdes = 1.2;%desired peak in flight
zf   = 0.7;%final height
dzf  = sqrt((zdes-zf)*2*g);%final velocity
xref = [zf;dzf];
%-------------------%
%Constraints Setting
%-------------------%
Lmin = 0.2;
Lmax = 0.84;
Ksmax= 4*kp/(Lmin^2);
Ksmin= 4*kp/(Lmax^2);
zmin = 0.34;
zmax = z0;
dzmin= -4;
dzmax= 2*dzf;
xmin = [zmin;dzmin];
xmax = [zmax;dzmax];
Ks   = 1/2*(Ksmax+Ksmin);%spring constant stiffness
umax = (Lmax+r-zmin)*(Ksmax-Ks)/Ks;
umin = (Lmax+r-zmin)*(Ksmin-Ks)/Ks;
U_L  = umin*ones(Tf/dt,1);
U_U  = umax*ones(Tf/dt,1);
%----------------------%
%Discrete Linear System
%----------------------%
Ac   = [0   ,1;
       -Ks/m,0];%continuous system matrix
Bc   = [0;Ks/m];
Dc   = [0;Ks*(L0+r)/m-g];
I    = eye(2);
A    = I+dt*Ac;
B    = dt*Bc;
D    = dt*Dc;
%-----------------%
%QP using quadprog
%-----------------%
[Sx,Su,Sd]=vectorLTIprediction(I,A,B,D,N);
[Hqp,fqp,Aqp,bqp]=QPfinalcost(Sx,Su,Sd,I,N,xmax,xmin,xref,x0,D);
uopt=quadprog(Hqp,fqp,Aqp,bqp,[],[],U_L,U_U);
%update
X   = Sx*x0+Su*uopt+Sd*D;
%result
n   = size(X,1);
z   = zeros(n/2,1);
dz  = zeros(n/2,1);
j   = 1;
for i=1:2:n
    z(j) = X(i,1);
    dz(j)= X(i+1,1);
    j    = j+1;
end
