function [Ats,AtF,Gs,ps,dps,Atf,pf,dpf] = TaskSpacePD(state,dstate,thetas,psym)
%This function returns the matrices needed for task-space formulation given
%the system states,e.g. dot x_t = At*dot q
%state=[x;y;z;roll;pitch;yaw;thetahl;thetakl;thetawl;thetahr;thetakr;thetawr]
%shanktilt=[theta0l;theta0r]
%psym  = [r,d,g,Lg,Ltcom,Lscom,dh,dhs,mfb,mtl,msl,mu];%system parameter vector
%****************By Bingheng WANG, on Mar.8.2020**************************
%-----------------------------------------------------------------------%
%Stance phase, base c.o.m is the task-space, space frame is body frame
%Difference: wheel frame is not needed, only sagittal plane is considered
%states =[baseposition;orientation;thetahipL;thetakneeL;thetahipR;thetakneeR]
%-----------------------------------------------------------------------%
      Ms          = [1,0,0,0;
                     0,1,0,0;
                     0,0,1,2*psym(4)+psym(7);
                     0,0,0,1];
      Slists      = [[0;1;0;0;0;0],[0;1;0;-psym(4);0;0],[0;1;0;-2*psym(4);0;0]];
      thetalists  = [thetas;-1/2*(state(8)+state(11));-1/2*(state(7)+state(10))];
      Ts          = FKinSpace(Ms, Slists, thetalists);
      [Rs, Ps]    = TransToRp(Ts);
      ps          = [state(7);state(8);state(10);state(11)];
      Jp          = JacobianSpace(Slists, thetalists);
      Tsinv       = TransInv(Ts);
      Xp2b        = Adjoint(Tsinv);
      Selects     = [zeros(3,3),eye(3)];
      selectz     = [0,0,1];
      selectx     = [1,0,0];
      At          = selectz*Rs*Selects*Xp2b*Jp;
      Jc          = selectx*Rs*Selects*Xp2b*Jp;%constraint Jacobian
      Jcd         = Jc(1);
      Jci         = [Jc(2),Jc(3)];
      Gs          = [-Jcd^(-1)*Jci;eye(2)];%kinematic matrix for constrained coordinates
      AtF         = At*Gs;
%       dqi         = [-1/2*(dstate(8)+dstate(11));-1/2*(dstate(7)+dstate(10))];
      dps         = [dstate(7);dstate(8);dstate(10);dstate(11)];
      Ats         = eye(4);
%-----------------------------------------------------------------------%
%Flight phase, wheel center is the task-space, space frame is body frame
%statef = [baseposition;orientation;thetahipL;thetakneeL;thetawL;thetahipR;thetakneeR;thetawR]
%-----------------------------------------------------------------------%
      Mf          = [1,0,0,0;
                     0,1,0,0;
                     0,0,1,-2*psym(4)-psym(7);
                     0,0,0,1];%the home configuration (position and orientation) of wheel frame in {b}
      Slistf      = [[0;1;0;psym(7);0;0],[0;1;0;psym(4)+psym(7);0;0],[0;1;0;2*psym(4)+psym(7);0;0]];
      thetalistfL = [state(7);state(8);state(9)];%hip, knee and wheel joint angles
      thetalistfR = [state(10);state(11);state(12)];
      TfL         = FKinSpace(Mf, Slistf, thetalistfL);%left side
      [RfL, pfL]  = TransToRp(TfL);%rotation matrix from {w} to {b} and position of {w} in {b}
      TfR         = FKinSpace(Mf, Slistf, thetalistfR);%right side
      [RfR, pfR]  = TransToRp(TfR);
      pf          = [pfL(1);pfL(3);state(9);pfR(1);pfR(3);state(12)];
      JsfL        = JacobianSpace(Slistf, thetalistfL);%velocity Jacobian in {b}
      JsfR        = JacobianSpace(Slistf, thetalistfR);%right side
      TfLinv      = TransInv(TfL);
      TfRinv      = TransInv(TfR);
      Xb2wL       = Adjoint(TfLinv);%adjoint matrix of Tinv
      Xb2wR       = Adjoint(TfRinv);
      JbfL        = Xb2wL*JsfL;%left body Jacobian
      JbfR        = Xb2wR*JsfR;
      Selectf     = [1,0,0;
                     0,0,1];%select x and z velocities
      AtfL        = [Selectf*RfL*Selects*JbfL;
                     [0,0,1]];
      AtfR        = [Selectf*RfR*Selects*JbfR;
                     [0,0,1]];    
      Atf         = [zeros(6,6),blkdiag(AtfL,AtfR)];
      dpf         = Atf*dstate;