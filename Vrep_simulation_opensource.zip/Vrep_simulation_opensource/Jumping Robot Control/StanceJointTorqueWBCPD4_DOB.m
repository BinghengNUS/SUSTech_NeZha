function tau = StanceJointTorqueWBCPD4_DOB(Ats,dAts,dstate,ddxtsc,torqn,D_joint,D_wip,Md,Gd,torqueLimit)
%This function returns the joint torques needed for the robot base c.o.m to
%track the desired c.o.m trajectory. The control law is PD plus gravity
%compensation.
%psym  = [r,d,g,Lg,Ltcom,Lscom,dh,dhs,mfb,mtl,msl,mw,mur,mus];
%****************By Bingheng WANG, on Mar.19 2020*************************

 %---------------------------------%
    %Quadratic programming formulation
    %---------------------------------%
    dstates = [dstate(7);dstate(8);dstate(10);dstate(11)];
    Hs    = Ats.'*Ats;
    fs    = Ats.'*(dAts*dstates-ddxtsc);
    Hsqp  = blkdiag(Hs,zeros(4,4));
    fsqp  = [fs;zeros(4,1)];
    Aeqs  = [Md,-eye(4)];
    beqs  = Md*D_joint-Gd;%
    Hsqp  = double(Hsqp);
    fsqp  = double(fsqp);
    Aeqs  = double(Aeqs);
    beqs  = double(beqs);
    usmin   = -[torqueLimit(1);torqueLimit(3);torqueLimit(2);torqueLimit(4)];
    usmax   = [torqueLimit(1);torqueLimit(3);torqueLimit(2);torqueLimit(4)];
    lb    = [-Inf(4,1);usmin];
    ub    = [Inf(4,1);usmax];
    [slns,optC] = quadprog(Hsqp,fsqp,[],[],Aeqs,beqs,lb,ub);%hip, knee, followed by right side
    hiptorqL   = slns(5);
    kneetorqL  = slns(6);
    hiptorqR   = slns(7);
    kneetorqR  = slns(8);

torqL = torqn(1)-D_wip(1);
torqR = torqn(2)-D_wip(2);
 tau = [hiptorqL;hiptorqR;kneetorqL;kneetorqR;torqL;torqR];