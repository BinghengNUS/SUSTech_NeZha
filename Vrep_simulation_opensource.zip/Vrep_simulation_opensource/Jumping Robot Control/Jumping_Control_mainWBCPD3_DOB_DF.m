%*************************************************************************
%         Balance and Jumping Control for a Wheeled Bipedal Robot
%*********************By Bingheng WANG, Mar.05,2020***********************
%% Configuration codes
% Control inputs: two hip joint torques, two knee joint torques, two wheel
% joint torques.
% Control objective: In stance phase: make the c.o.m of base track the
% trajectory optimized online by the SLIP model; In flight phase, make the
% foot track the desired trajectories manually designed offline.
% Methdology: the control is achieved by task-space quadratic programming
% {s}: inertial frame
% {b}: body frame fixed on the floating base
% {f}: body frame fixed on the foot
clear all

jointNum=6;
torqueLimit=[50;50;50;50;10;10];
jointName=["LeftHip_joint","RightHip_joint","LeftKnee_joint","RightKnee_joint","LeftWheel_joint","RightWheel_joint"];  

displayOn=true;
torque=zeros(jointNum,1); 

%% Connect to the Vrep
% 1. load api library
vrep=remApi('remoteApi'); % using the prototype file (remoteApiProto.m)
% 2. close all the potential link
vrep.simxFinish(-1);   
% 3. wait for connecting vrep, detect every 0.2s
while true
    clientID=vrep.simxStart('127.0.0.1',19997,true,true,5000,5);
    if clientID>-1 
        break;
    else
        pause(0.2);
        disp('please run the simulation on vrep...')
    end
end
disp('Connection success!')
% 4. set the simulation time step
tstep = 0.001;  % 1ms per simulation pass
vrep.simxSetFloatingParameter(clientID,vrep.sim_floatparam_simulation_time_step,tstep,vrep.simx_opmode_oneshot);
% 5. open the synchronous mode to control the objects in vrep
vrep.simxSynchronous(clientID,true);

%% Simulation Initialization
vrep.simxStartSimulation(clientID,vrep.simx_opmode_oneshot);
% get the handles
jointHandle=zeros(jointNum,1); 
for i=1:jointNum  % handles of the left and right arms
    [~,returnHandle]=vrep.simxGetObjectHandle(clientID,char(jointName(i)),vrep.simx_opmode_blocking);
    jointHandle(i)=returnHandle;
end
% set the target velocity to 0.1 and torque to 0
for i=1:jointNum
    vrep.simxSetJointForce(clientID,jointHandle(i),0,vrep.simx_opmode_oneshot);
    vrep.simxSetJointTargetVelocity(clientID,jointHandle(i),0.1,vrep.simx_opmode_oneshot);
end
baseName='Body_link_visual';
wheelName='RightWheel_link_visual';
wheelleft='LeftWheel_link_visual';
Shankleft='LeftShank_link_visual';
Shankright='RightShank_link_visual';
LeftHip='LeftHip_joint';
RightHip='RightHip_joint';
[~,baseHandle]=vrep.simxGetObjectHandle(clientID,baseName,vrep.simx_opmode_blocking);  
[~,wheelHandle]=vrep.simxGetObjectHandle(clientID,wheelName,vrep.simx_opmode_blocking);  
[~,wheelleftHandle]=vrep.simxGetObjectHandle(clientID,wheelleft,vrep.simx_opmode_blocking);  
[~,ShankleftHandle]=vrep.simxGetObjectHandle(clientID,Shankleft,vrep.simx_opmode_blocking);  
[~,ShankrightHandle]=vrep.simxGetObjectHandle(clientID,Shankright,vrep.simx_opmode_blocking);  
[~,LeftHipHandle]=vrep.simxGetObjectHandle(clientID,LeftHip,vrep.simx_opmode_blocking);  
[~,RightHipHandle]=vrep.simxGetObjectHandle(clientID,RightHip,vrep.simx_opmode_blocking);  
vrep.simxSynchronousTrigger(clientID);
disp('Handles available!')
% first call to read the joints' configuration and end-effector pose, the mode is chosen to be simx_opmode_streaming
jointConfig=zeros(jointNum,1); 
% get current joint position
for i=1:jointNum
    [~,jpos]=vrep.simxGetJointPosition(clientID,jointHandle(i),vrep.simx_opmode_streaming); 
        jointConfig(i)=jpos;
end

% get simulation time
currCmdTime=vrep.simxGetLastCmdTime(clientID);

lastCmdTime=currCmdTime;
% jointConfig0=jointConfig;
% jointConfigLast=zeros(jointNum,1);
% jointConfigLast=jointConfig+[0;0;0;0;43.9823;43.9823;0;0];;
[~,baseposition0]=vrep.simxGetObjectPosition(clientID,baseHandle,-1,vrep.simx_opmode_streaming);% defined in inertial frame
[~,wheelposition0]=vrep.simxGetObjectPosition(clientID,wheelHandle,-1,vrep.simx_opmode_streaming);
[~,wheelleftposition0]=vrep.simxGetObjectPosition(clientID,wheelleftHandle,-1,vrep.simx_opmode_streaming);  
[~,Shankleftposition0]=vrep.simxGetObjectPosition(clientID,ShankleftHandle,-1,vrep.simx_opmode_streaming);  
[~,Shankrightposition0]=vrep.simxGetObjectPosition(clientID,ShankrightHandle,-1,vrep.simx_opmode_streaming);  
[~,baseorientation0]=vrep.simxGetObjectOrientation(clientID,baseHandle,-1,vrep.simx_opmode_streaming);% defined in inertial frame
[~,LeftHipposition0]=vrep.simxGetObjectPosition(clientID,LeftHipHandle,-1,vrep.simx_opmode_streaming);  
 pause(0.1)
 for i=1:jointNum
    [~,jpos]=vrep.simxGetJointPosition(clientID,jointHandle(i),vrep.simx_opmode_streaming); 
        jointConfig(i)=jpos;
end
[~,baseposition0]=vrep.simxGetObjectPosition(clientID,baseHandle,-1,vrep.simx_opmode_buffer);% defined in inertial frame
[~,wheelposition0]=vrep.simxGetObjectPosition(clientID,wheelHandle,-1,vrep.simx_opmode_buffer);
[~,wheelleftposition0]=vrep.simxGetObjectPosition(clientID,wheelleftHandle,-1,vrep.simx_opmode_buffer);  
[~,Shankleftposition0]=vrep.simxGetObjectPosition(clientID,ShankleftHandle,-1,vrep.simx_opmode_buffer);  
[~,Shankrightposition0]=vrep.simxGetObjectPosition(clientID,ShankrightHandle,-1,vrep.simx_opmode_buffer);  
[~,baseorientation0]=vrep.simxGetObjectOrientation(clientID,baseHandle,-1,vrep.simx_opmode_streaming);% defined in inertial frame
[~,LeftHipposition0]=vrep.simxGetObjectPosition(clientID,LeftHipHandle,-1,vrep.simx_opmode_streaming);  
% jointConfig=jointConfig;%+[0;0;0;0;43.9823;43.9823;0;0];
%-----------------%
%System Parameters
%-----------------%
r     = 0.1;%radius of wheel
d     = 0.175;%distance from the wheel to the center of body
g     = 9.8;
Lg    = 0.429;%length of Thighlink
Ltcom = -0.0894;%z position of Thigh_link C.O.M in link frame
Lscom = -0.29;%z position of Shank_link C.O.M in link frame
dh    = 0.0474;% height of C.O.M of the main body relative to the hip joint
dhs   = -2.003e-02;%height of C.O.M of the main body in shape frame of bounding box
mfb   = 3.83;%mass of the floating base
mtl   = 1.429;%mass of the thigh leg
msl   = 0.7;%mass of the shank leg
mw    = 0.74;%mass of the wheel
mur   = 0.0005;%rotational friction coefficient
mus   = 0.1;%static friction coefficient 
psym  = [r,d,g,Lg,Ltcom,Lscom,dh,dhs,mfb,mtl,msl,mw,mur,mus];%system parameter vector
%--------------%
%Initial states
%--------------%
jointLAST = jointConfig;
dqLast    = zeros(6,1);
rollb0    = baseorientation0(1);
pitchb0   = baseorientation0(2);
yawb0     = baseorientation0(3);
Rs2b0     = Rzyx(rollb0,pitchb0,yawb0);
bposition0= baseposition0.'+Rs2b0.'*[6.285e-03;2.496e-07;dhs];
state0 = [bposition0;baseorientation0.';jointLAST(1);jointLAST(3);jointLAST(5);jointLAST(2);jointLAST(4);jointLAST(6)];
dstate0= zeros(12,1);
bpositionLast    = bposition0;
orientationLast  = baseorientation0.';
deulerLast       = zeros(3,1);
wbLast           = zeros(3,1);
deltawheel0      = wheelposition0-wheelleftposition0;
yaw0 = atan(deltawheel0(1)/deltawheel0(2));% yaw angle of the whole robot
deltaposition0 = bposition0-wheelposition0.'; % relative position between base and left wheel in {S}
deltap_b0      = Rotzs2b(yaw0)*deltaposition0;
theta0         = atan(deltap_b0(1)/(deltap_b0(3)));
dtheta0        = 0;
deltap_b0 = Rotzs2b(yaw0)*deltaposition0;
LlqrLast  = sqrt((deltap_b0(1))^2+(deltap_b0(3))^2);
thetaLast = atan(deltap_b0(1)/(deltap_b0(3)));
dthetaLast= 0;
dyaw0     = 0;
positionswleft0 =Shankleftposition0-wheelleftposition0;
positionswright0=Shankrightposition0-wheelposition0;
wheelLx0         = wheelleftposition0(1);
wheelLy0         = wheelleftposition0(2);
wheelRx0         = wheelposition0(1);
wheelRy0         = wheelposition0(2);
wheelLxLast      = wheelLx0;
wheelLyLast      = wheelLy0;
wheelRxLast      = wheelRx0;
wheelRyLast      = wheelRy0;
pwleft0_b = Rotzs2b(yaw0)*positionswleft0.';
pwright0_b= Rotzs2b(yaw0)*positionswright0.';
yawLast   = yaw0;
theta0l0 = atan(pwleft0_b(1)/pwleft0_b(3));%tilting angle of Shankleft
theta0r0 = atan(pwright0_b(1)/pwright0_b(3));%tilting angle of Shankright
theta0lLast = theta0l0;
theta0rLast = theta0r0;
shanktilt0  = [theta0lLast;theta0rLast];
dtheta0lLast= 0;
dtheta0rLast= 0;
dshanktilt0 = [dtheta0lLast;dtheta0rLast];
thetas0     = theta0l0-theta0;%tilting angle of {s} w.r.t {p}
v0          = 0;
[Ats0,AtF,Gs0,ps,dps,Atf0,pf,dpf] = TaskSpacePD(state0,dstate0,thetas0,psym);
GsLast      = Gs0;
AtsLast     = Ats0;
AtfLast     = Atf0;
vrep.simxSynchronousTrigger(clientID);         % every calls this function, verp is triggered, 50ms by default

%% Simulation Start
t=0;  % start the simulation
k=1;
kfly     = 1;
kstance  = 1;
kland    = 1;
%Parameters for LQR
Q      = diag([1,1,1,1]);
R      = diag([0.2,0.2]);
QL     = diag([1,1,1]);
RL     = 0.2;
vref   = 1;
dyawref= 0;
zmax   = 2.3;%maximum height of jump
%Parameters of state machine
  %stance phase
  kpx    = 500;%150,unstable oscillation is caused by small damping coefficients
  kpz    = 500;
  kpw    = 0;%no control for wheel joint angle
%   Kps    = diag([kpx,kpz,kpw,kpx,kpz,kpw]);
  Kps    = diag([kpx,kpz,kpx,kpz]);
  kdx    = 250;%80
  kdz    = 250;
  kdw    = 0;
%   Kds    = diag([kdx,kdz,kdw,kdx,kdz,kdw]);
  Kds    = diag([kdx,kdz,kdx,kdz]);
  %flight phase 
  kpx    = 2*150;%150,unstable oscillation is caused by small damping coefficients
  kpz    = 2*150;
  kpw    = 0;%no control for wheel joint angle
  Kpf    = diag([kpx,kpz,kpw,kpx,kpz,kpw]);
  kdx    = 2*105;%96
  kdz    = 2*105;
  kdw    = 5;
  Kdf    = diag([kdx,kdz,kdw,kdx,kdz,kdw]);
%Parameters of disturbance observer
  K1j    = [20;70;20;70];%zeros(4,1);
  K2j    = [10;10;10;10];%%1zeros(4,1);
  K1w    = [15;40;15];%zeros(3,1);
  K2w    = [2;2;2];%%1zeros(3,1);
flagjump = 0;%no jump, 1 for a jump that already happened
flagland = 0;%no landing 
z_joint  = [dstate0(7);dstate0(8);dstate0(10);dstate0(11)];
z_wip    = [v0;dyaw0;dtheta0];
tanh_joint = zeros(4,1);
tanh_wip   = zeros(3,1);
while (vrep.simxGetConnectionId(clientID) ~= -1)  % vrep connection is still active
    % time update
%   vrep.simxSetJointPosition(clientID,LeftHipHandle,tbased,vrep.simx_opmode_oneshot);
%   vrep.simxSetJointPosition(clientID,RightHipHandle,tbased,vrep.simx_opmode_oneshot);
    currCmdTime=vrep.simxGetLastCmdTime(clientID);
    dt=(currCmdTime-lastCmdTime)/1000;              % simulation step, unit: s 
    % read the joints' and tips' configuration (position and velocity)
    for i=1:jointNum
        [~,jpos]=vrep.simxGetJointPosition(clientID,jointHandle(i),vrep.simx_opmode_buffer);     
               jointConfig(i)=jpos;
    end
    %---------------------------%
    %System variables processing
    %---------------------------%
    gapl  = jointLAST(5)-jointConfig(5);
    gapr  = jointLAST(6)-jointConfig(6);
    if gapl<=-42
        Gapl=0;
    else
        Gapl=gapl;
    end
    if gapr<=-42
        Gapr=0;
    else
        Gapr=gapr;
    end
    
    if Gapl>=6 %remove the gap between two wheel angles, moving forward
        jointConfig(5)=jointConfig(5)+round(abs(Gapl)/(2*pi))*2*pi;
    end
    if Gapr>=6
        jointConfig(6)=jointConfig(6)+round(abs(Gapr)/(2*pi))*2*pi;
    end
    if Gapl<=-6 %remove the gap between two wheel angles, moving backward
        jointConfig(5)=jointConfig(5)-round(abs(Gapl)/(2*pi))*2*pi;
    end
    if Gapr<=-6
        jointConfig(6)=jointConfig(6)-round(abs(Gapr)/(2*pi))*2*pi;
    end
    Jointangle(:,k)=jointConfig;
    q=jointConfig;
    dQ=(q-jointLAST)./dt;  % column vector
    if k==1
        dq=zeros(jointNum,1);
    else
       if norm(dQ(1),2)>=2e2%avoid dQ being very large
        dq=zeros(jointNum,1);
       else
        dq=dQ;
       end 
    end
    
    Qdot(:,k)=dq;
    ddq = (dq-dqLast)/dt;%acceleration of joint variables
%     jointConfig=jointConfig;%+[0;0;0;0;43.9823;43.9823;0;0];
    [~,baseposition]=vrep.simxGetObjectPosition(clientID,baseHandle,-1,vrep.simx_opmode_buffer);% defined in inertial frame
    [~,wheelposition]=vrep.simxGetObjectPosition(clientID,wheelHandle,-1,vrep.simx_opmode_buffer);
    [~,wheelleftposition]=vrep.simxGetObjectPosition(clientID,wheelleftHandle,-1,vrep.simx_opmode_buffer);  
    [~,Shankleftposition]=vrep.simxGetObjectPosition(clientID,ShankleftHandle,-1,vrep.simx_opmode_buffer);  
    [~,Shankrightposition]=vrep.simxGetObjectPosition(clientID,ShankrightHandle,-1,vrep.simx_opmode_buffer);  
    [~,baseorientation]=vrep.simxGetObjectOrientation(clientID,baseHandle,-1,vrep.simx_opmode_streaming);% defined in inertial frame
    [~,LeftHipposition]=vrep.simxGetObjectPosition(clientID,LeftHipHandle,-1,vrep.simx_opmode_streaming);  
    [~,RightHipposition]=vrep.simxGetObjectPosition(clientID,RightHipHandle,-1,vrep.simx_opmode_streaming);  
    rollb     = baseorientation(1);
    pitchb    = baseorientation(2);
    yawb      = baseorientation(3);
    Rs2b      = Rzyx(rollb,pitchb,yawb);
    bposition = baseposition.'+Rs2b.'*[6.285e-03;2.496e-07;dhs];
    state     = [bposition;baseorientation.';q(1);q(3);q(5);q(2);q(4);q(6)];
    vbase     = (bposition-bpositionLast)./dt;
    dEuler    = (baseorientation.'-orientationLast)./dt;
    if k==1
        deuler=zeros(3,1);
    else
        deuler=dEuler;
    end
    ddeuler   = (deuler-deulerLast)./dt;
    dstate    = [vbase;deuler;dq(1);dq(3);dq(5);dq(2);dq(4);dq(6)];
    deltawheel= wheelposition-wheelleftposition;
%     yaw       = atan(deltawheel(1)/deltawheel(2));% yaw angle of the whole robot
    yaw       = psym(1)*(q(6)-q(5))/(2*psym(2));
    Yaw(k)    = yaw;
%     dyaw      = (yaw-yawLast)./dt;

    % attitude of the base 
    Orientation(:,k)=[baseorientation(1);baseorientation(2);baseorientation(3)];
    % tilt angle of the pendulum
    Wheelzposition(k)    = wheelposition(3);
    wheelzposition       = wheelposition(3);
    Wheelzleftposition(k)= wheelleftposition(3);
    deltaposition  = bposition-wheelposition.'; % position of pendulum relative to the wheel
    deltap_b       = Rotzs2b(yaw)*deltaposition;
    Llqr   = sqrt((deltap_b(1))^2+(deltap_b(3))^2);%length of the pendulum
    theta          = atan(deltap_b(1)/(deltap_b(3)));
    Tiltangle(k)   = theta;
    dtheta         = (theta-thetaLast)/dt;
    ddtheta        = (dtheta-dthetaLast)/dt;
    positionswleft = Shankleftposition-wheelleftposition;
    positionswright= Shankrightposition-wheelposition;
    wheelLx         = wheelleftposition(1);
    wheelLy         = wheelleftposition(2);
    wheelRx         = wheelposition(1);
    wheelRy         = wheelposition(2);
    vwLx           = (wheelLx-wheelLxLast)./dt;
    vwLy           = (wheelLy-wheelLyLast)./dt;
    vwL            = sqrt(vwLx^2+vwLy^2);
    vwRx           = (wheelRx-wheelRxLast)./dt;
    vwRy           = (wheelRy-wheelRyLast)./dt;
    vwR            = sqrt(vwRx^2+vwRy^2);
    v              = (vwLx*cos(yaw)+vwLy*sin(yaw)+vwRx*cos(yaw)+vwRy*sin(yaw))/2;
    dyaw           = r*(dq(6)-dq(5))/(2*d);%+dtheta0R-dtheta0L
    Vfw(k) = v;
    pwleft_b       = Rotzs2b(yaw)*positionswleft.';
    pwright_b      = Rotzs2b(yaw)*positionswright.';
    theta0l        = atan(pwleft_b(1)/pwleft_b(3));%tilting angle of Shankleft
    theta0r        = atan(pwright_b(1)/pwright_b(3));%tilting angle of Shankright
    thetas         = theta0l-theta;%tilting angle of {s} w.r.t {p}
    shanktilt      = [theta0l;theta0r];
    dtheta0L       = (theta0l-theta0lLast)/dt;
    dtheta0R       = (theta0r-theta0rLast)/dt;
    dthetas        = dtheta0L-dtheta;
    dshanktilt     = [dtheta0L;dtheta0R];
    ddtheta0l      = (dtheta0L-dtheta0lLast)/dt;
    ddtheta0r      = (dtheta0R-dtheta0rLast)/dt;
    ddshanktilt    = [ddtheta0l;ddtheta0r];
    
    %----------------------%
    %Task-space formulation
    %----------------------%
    [Ats,AtF,Gs,ps,dps,Atf,pf,dpf] = TaskSpacePD(state,dstate,thetas,psym);
    dGs    = (Gs-GsLast)./dt;
    dAts   = (Ats-AtsLast)./dt;
    dAtf   = (Atf-AtfLast)./dt;
    
    %--------------%
    %Task reference
    %--------------%
    drollb  = deuler(1);
    dpitchb = deuler(2);
    [T_e2w,dT_e2w] = Te2w(rollb,pitchb,drollb,dpitchb);
    wb     = T_e2w*deuler;%angular velocity of base in {b}
    dwb    = dT_e2w*deuler+T_e2w*ddeuler;
%     dwb    = (wb-wbLast)./dt;
    if wheelzposition<=0.105%reference in stance over N horizon, optimized only once
       if t<=2.5
           bs_ref   = 0.7+r+dh;
           dbs_ref  = 0;
           ddbs_ref = 0;
           dx       = 2*mtl*Ltcom*sin((q(1)+q(2))/2)/(2*mtl+mfb);%offset in x axis of c.o.m of base and thigh legs
           thetad   = atan(-dx/Llqr);
           dthetad  = 0;
       else
        if kstance<=1
            Landcon = landingCondition(QL,RL,Llqr,zmax,vref,torqueLimit);
            thetad  = Landcon(1);%desired tilting angle for landing
            vref    = Landcon(3);%desired forward velocity in thrusting
            [Bs_refr,dBs_refr,ddBs_refr,Ts_refr,dTs_refr] = SLIPtrajectory_DF(psym,Llqr,dLlqr,theta,dtheta,flagjump,zmax,thetad);
            [Bs_refr,dBs_refr,ddBs_refr] = SLIPtrajectory(psym,state,dstate,flagjump);
        elseif flagjump == 1 && flagland == 0
            thetad   = atan(-dx/Llqr);
            [Bs_ref,dBs_ref,ddBs_ref,Ts_ref,dTs_ref] = SLIPtrajectory_DF(psym,Llqr,dLlqr,theta,dtheta,flagjump,zmax,thetad);
            [Bs_ref,dBs_ref,ddBs_ref] = SLIPtrajectory(psym,state,dstate,flagjump);
            flagland = 1;
            vref     = 1;
            z_joint  = [dstate(7);dstate(8);dstate(10);dstate(11)];
            z_wip    = [v;dyaw;dtheta];
            tanh_joint = zeros(4,1);
            tanh_wip   = zeros(3,1);
        end
        if flagjump == 0%no jump
            if kstance <= size(Bs_refr,2)
                bs_ref  = Bs_refr(kstance);
                dbs_ref = dBs_refr(kstance);
                ddbs_ref= ddBs_refr(kstance);
                thetad  = Ts_refr(kstance);
                dthetad = dTs_refr(kstance);
            else
                bs_ref  = Bs_refr(size(Bs_refr,2));
                dbs_ref = dBs_refr(size(Bs_refr,2));
                ddbs_ref= ddBs_refr(size(Bs_refr,2));
                thetad  = Ts_refr(size(Bs_refr,2));
                dthetad = dTs_refr(size(Bs_refr,2));
            end
        else%landing phase
            if kland<= size(Bs_ref,2)
                bs_ref  = Bs_ref(kland);
                dbs_ref = dBs_ref(kland);
                ddbs_ref= ddBs_ref(kland);
                thetad  = Ts_ref(kland);
                dthetad = dTs_ref(kland);
            else
                bs_ref  = Bs_ref(size(Bs_ref,2));
                dbs_ref = dBs_ref(size(Bs_ref,2));
                ddbs_ref= ddBs_ref(size(Bs_ref,2));
                thetad  = Ts_ref(size(Bs_ref,2));
                dthetad = dTs_ref(size(Bs_ref,2));
            end
        end
       end
          
    else%reference in flight calculated online
        [pf_ref,dpf_ref,ddpf_ref] = FlightTaskReference(baseorientation,wb,dwb,psym,vref); 
        Pf_ref(:,kfly)  = pf_ref;
        dPf_ref(:,kfly) = dpf_ref;
        ddPf_ref(:,kfly)= ddpf_ref;
        kfly = kfly+1;
    end
    
    %-------------------------------%
    %Behavior specific state machine
    %-------------------------------%
    if wheelzposition<=0.105
       [ddhkd,dhkd,hkd,thehd,thekd]=desiredangle2(bs_ref,dbs_ref,ddbs_ref,dh,r,Lg);
        ps_ref  = [hkd;hkd];
        dps_ref = [dhkd;dhkd];
        ddps_ref= [ddhkd;ddhkd];
        Thehd(kstance)=thehd;
       ddxtsc = StanceStateMachine(ps_ref,dps_ref,ddps_ref,ps,dps,Kps,Kds);
    else
        ddxtfc = FlightStateMachine(pf_ref,dpf_ref,ddpf_ref,pf,dpf,Kpf,Kdf);
    end
    
    %---------------------------%
    %Control in different phases
    %---------------------------%
    %States for LQR
%     v      = r/2*(dq(5)+dq(6));%forward velocity+dtheta0L+dtheta0R   
    Yawrate(k)= dyaw;
    xlqr   = [theta;v;dyaw;dtheta];
    
    xref   = [thetad;vref;dyawref;dthetad];
    dLlqr  = (Llqr-LlqrLast)/dt;
    K      = LQRcontrol(Llqr,Q,R);
    torq_lqr = -K*(xlqr-xref);%control torque obtained by LQR for wheel motors and pendulum motor 
     if wheelzposition<=0.105
         [D_joint,D_wip,dz_joint,dz_wip,dtanh_joint,dtanh_wip,Xi_j,Xi_w,Md] = Disturbance_ObserverWBCPD(K1j,K2j,K1w,K2w,torque,dstate,xlqr,z_joint,z_wip,tanh_joint,tanh_wip,Llqr,psym);
         z_joint    = z_joint+dt*dz_joint;
         z_wip      = z_wip+dt*dz_wip;
         tanh_joint = tanh_joint+dt*dtanh_joint;
         tanh_wip   = tanh_wip+dt*dtanh_wip;
         D_J(:,k)   = D_joint;
         D_W(:,k)   = D_wip;
         XI_J(:,k)  = Xi_j;
         XI_W(:,k)  = Xi_w;
         torque = StanceJointTorqueWBCPD3_DOB(Ats,dAts,dstate,ddxtsc,torq_lqr,D_joint,D_wip,Md,torqueLimit);
         if flagjump == 0 && t>2.5
             kstance= kstance+1;
         else
             kland  = kland+1;
         end
     else
         torque = FlightJointTorques(Atf,dAtf,state,dstate,ddxtfc,psym,torqueLimit);
         if t>=3
             flagjump = 1;
         else
             flagjump = 0;
         end
     end
     k=k+1;
     
    %   3.3 set the torque in vrep way
    for i=1:jointNum
        if sign(torque(i))<0
            setVel=-9999; % set a trememdous large velocity for the screwy operation 
            if torque(i)<-torqueLimit(i)
                setTu=-torqueLimit(i);
            else
                setTu=-torque(i);
            end
        else
            setVel=9999;
            if torque(i)>torqueLimit(i)
                setTu=torqueLimit(i);
            else
                setTu=torque(i);
            end
        end
        vrep.simxSetJointTargetVelocity(clientID,jointHandle(i),setVel,vrep.simx_opmode_oneshot);
        vrep.simxSetJointForce(clientID,jointHandle(i),setTu,vrep.simx_opmode_oneshot);
        Torque(i,k)=setTu; 
    end

    % 4. update vrep(the server side)
    lastCmdTime     = currCmdTime;
    jointLAST       = jointConfig;   
    bpositionLast   = bposition;
    orientationLast = baseorientation.';
    deulerLast      = deuler;
    wbLast          = wb;
    thetaLast       = theta;
    dthetaLast      = dtheta;
    yawLast         = yaw;
    dqLast          = dq;
    dtheta0lLast    = dtheta0L;
    dtheta0rLast    = dtheta0R;
    LlqrLast        = Llqr;
    vbaseLast       = vbase;
    GsLast          = Gs;
    AtsLast         = Ats;
    AtfLast         = Atf;
    wheelLxLast     = wheelLx;
    wheelLyLast     = wheelLy;
    wheelRxLast     = wheelRx;
    wheelRyLast     = wheelRy;
    vrep.simxSynchronousTrigger(clientID);
    t=t+dt; % updata simulation time
    Time(k)=t;
end
vrep.simxFinish(-1);  % close the link
vrep.delete();        % destroy the 'vrep' class

%%
% figure(1); hold off;
% subplot(411); plot(E(1,:),'r'); hold on; plot(E(2,:),'b'); title('error')
% subplot(412); plot(Q(1,:),'r'); hold on; plot(Q(2,:),'b');  plot(QD(1,:),'k'); hold on; plot(QD(2,:),'k'); title('trajectory')
% subplot(413); plot(DQ(1,:),'r'); hold on; plot(DQ(2,:),'b');  plot(DQD(1,:),'k'); hold on; plot(DQD(2,:),'k'); title('velocity')
% subplot(414); plot(TAU(1,:),'r'); hold on; plot(TAU(2,:),'b'); title('torque')

