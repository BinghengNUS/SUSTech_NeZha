function tau = FlightJointTorques(Atf,dAtf,state,dstate,ddxtfc,psym,torqueLimit) 
%This function returns the joint torques for the task-space control, which
%includes two hip joint torques, two knee joint torques and two wheel joint
%torques. All torques are obtained by quadratic programming based on a full
%dynamic model
%psym  = [r,d,g,Lg,Ltcom,Lscom,dh,dhs,mfb,mtl,msl,mw,mur,mus];%system parameter vector
%optimal variables: sln 18by1, state acc., six joint torq.
%*********************By Bingheng WANG, on Mar.8 2020*********************
%flight phase
    %--------------------------%
    %full model (floating base)
    %--------------------------%
    handle.NB = 7;
    handle.parent = [0 1 2 3 1 5 6];%left part first, then right part
    handle.jtype = {'Ry', 'Ry', 'Ry', 'Ry','Ry','Ry','Ry'};
    handle.Xtree{1} = eye(6);%from {s} to base frame {b} (at base c.o.m) 
    handle.Xtree{2} = xlt([0,0.0762,-psym(7)]);%Adjoint Matrix from {parent i} Link frame to {i}
    handle.Xtree{3} = xlt([0,0.0385,-psym(4)]);
    handle.Xtree{4} = xlt([0,0.0605,-psym(4)]);
    handle.Xtree{5} = xlt([0,-0.0762,-psym(7)]);%from {b} to hip joint frame {h}, expressed in {h}
    handle.Xtree{6} = xlt([0,-0.0385,-psym(4)]);
    handle.Xtree{7} = xlt([0,-0.0605,-psym(4)]);
    mass = psym(9);%half of base
    CoM = [0,0,0];
    Icm =  diag([0.0261376195979353,0.0249232975683053,0.0143828822217345]);
    handle.I{1} = mcI( mass, CoM, Icm );
    mass = psym(10);%Thigh link
    CoM = [0,0.0637001804791891,psym(5)];
    Icm =  diag([0.0223883715246182,0.022309557436881,0.00172727939342223]);
    handle.I{2} = mcI( mass, CoM, Icm );
    mass = psym(11);%Shank link
    CoM = [0,0.0364494458894979,psym(6)];
    Icm = diag([0.0175958448813304,0.0177210394041728,0.000378821101531682]);
    handle.I{3} = mcI( mass, CoM, Icm );
    mass = psym(12);%Wheel link
    CoM = [0,0.013,0];
    Icm = diag([0.00249269451196491,0.0049481769879587,0.00249269451196491]);
    handle.I{4} = mcI( mass, CoM, Icm );
    mass = psym(10);%Thigh link
    CoM = [0,-0.0637001804791891,psym(5)];
    Icm =  diag([0.0223883715246182,0.022309557436881,0.00172727939342223]);
    handle.I{5} = mcI( mass, CoM, Icm );
    mass = psym(11);%Shank link
    CoM = [0,-0.036449445889498,psym(6)];
    Icm = diag([0.0175958448813304,0.0177210394041728,0.000378821101531682]);
    handle.I{6} = mcI( mass, CoM, Icm );
    mass = psym(12);%Wheel link
    CoM = [0,-0.0129851806070332,0];
    Icm = diag([0.00249269451196491,0.0049481769879587,0.00249269451196491]);
    handle.I{7} = mcI( mass, CoM, Icm );
    handle_fb   = floatbase(handle);
    [M,C]       = HandC(handle_fb, state, dstate, []);
    %---------------------------------%
    %Quadratic programming formulation
    %---------------------------------%
    Hf    = Atf.'*Atf;
    ff    = Atf.'*(dAtf*dstate-ddxtfc);
    Hfqp  = blkdiag(Hf,zeros(6,6));
    ffqp  = [ff;zeros(6,1)];
    Sf    = [zeros(6,6);eye(6)];
    Aeqf  = [M,-Sf];
    beqf  = -C;
    ufmin = -[torqueLimit(1);torqueLimit(3);torqueLimit(5);torqueLimit(2);torqueLimit(4);torqueLimit(6)];
    ufmax = [torqueLimit(1);torqueLimit(3);torqueLimit(5);torqueLimit(2);torqueLimit(4);torqueLimit(6)];
    Hfqp  = double(Hfqp);
    ffqp  = double(ffqp);
    Aeqf  = double(Aeqf);
    beqf  = double(beqf);
    lb    = [-Inf(12,1);ufmin];
    ub    = [Inf(12,1);ufmax];
    lb    = double(lb);
    ub    = double(ub);
    [slnf,optC] = quadprog(Hfqp,ffqp,[],[],Aeqf,beqf,lb,ub);%hip, knee, wheel, followed by right side
    tau   = [slnf(13);slnf(16);slnf(14);slnf(17);slnf(15);slnf(18)];
%       kp    = 5;
%       kd    = 2;
%       hiptorqueL  = -kd*dstate(7)+kp*(pi/6-state(7));
%       hiptorqueR  = -kd*dstate(10)+kp*(pi/6-state(10));
%       kneetorqueL = -kd*dstate(8)+kp*(-pi/3-state(8));
%       kneetorqueR = -kd*dstate(11)+kp*(-pi/3-state(11));
%       wheeltorqueL= 0;
%       wheeltorqueR= 0;
%       tau   = [hiptorqueL;hiptorqueR;kneetorqueL;kneetorqueR;wheeltorqueL;wheeltorqueR];
