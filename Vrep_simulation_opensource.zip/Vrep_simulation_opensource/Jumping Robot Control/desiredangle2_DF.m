function [ddhkd,dhkd,hkd,thehd,thekd]=desiredangle2_DF(H_des,dH_des,ddH_des,Lg)
H_des  = double(H_des);
dH_des = double(dH_des);
ddH_des= double(ddH_des);
thehd  = acos(H_des/(2*Lg));
thekd  = -2*thehd;
dthehd = dH_des/(-2*Lg*sin(thehd));
dthekd = -2*dthehd;
ddthehd= -(ddH_des+H_des*dthehd^2)/(2*Lg*sin(thehd));
ddthekd= -2*ddthehd;
ddhkd   = [ddthehd;ddthekd];
dhkd    = [dthehd;dthekd];
hkd     = [thehd;thekd];


