function ddxtsc = StanceStateMachine(ps_ref,dps_ref,ddps_ref,ps,dps,Kps,Kds)
%This function returns the dynamic commands in task-space, based on the
%reference and system task-space variables.
%Kps: proportional gain in stance phase
%Kpf: proportional gain in flight phase
%Kds: derivative gain in stance phase
%Kdf: derivative gain in flight phase
% all commands consist of a PD-based feedback control law and a feedforward
% term of desired acceleration

ddxtsc = ddps_ref+Kds*(dps_ref-dps)+Kps*(ps_ref-ps);
