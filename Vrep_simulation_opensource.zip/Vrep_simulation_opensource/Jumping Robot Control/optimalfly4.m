function alpha_f = optimalfly4(psym,Theta_LO,zmax,Llqr,dLlqr,Lds,Ltop)
% Similar to the optimization in stance phase, this function takes two
% stpes to generate the trajectories in fly. First, plan the open-loop
% trajectories provided dtheta = 0 and the top mass m_1 follows a ballistic
% trajectory. Second, optimize the trajectory that respects the linear
% nonholonomic constraint based on the open-loop trajectory
%*********************By Bingheng WANG, on May 18, 2020********************
%------------------%
%Parameters Setting
%------------------%
Lg       = psym(4);%length of leg (Thigh link and Shank link)
g        = psym(3);
r        = psym(1);%radius of wheel
dh       = psym(7);%height of base c.o.m relative to the hip joint
L0       = 2*Lg+dh;
m1       = psym(9)+2*psym(10);
m2       = 2*(psym(11)+psym(12));
kL       = m1/(m1+m2);
LTO      = Lds+dh;

%--------------------------------------%
%QP formulation for length optimization
%--------------------------------------%
 %Initialization
  L_0    = Llqr;
  dL_0   = 0;
  tr     = sqrt(2*(zmax-r-kL*L_0*cos(Theta_LO))/g);%rising time
  td     = sqrt(2*(zmax-r-kL*LTO)/g);%descending time
  Tf     = tr+td;%flight time
  N      = 200;
  deltf  = Tf/N;
  A      = zeros(N+1,10);
  b      = zeros(N+1,1);
  k      = 1;
 %Constraint
  L_d    = LTO;
  dL_d   = 0;
  for t=0:deltf:Tf
      [P0,~,~] = poly(t);
      A(k,:)=P0;
      b(k,:)=L0;
  end
  [P0_0,P1_0,~] = poly(0);
  [P0_top,~,~] = poly(tr);
  [P0_T,P1_T,~] = poly(Tf);
  H      = P0_top.'*P0_top;
  f      = -P0_top.'*Ltop;
  Aeq    = [P0_0;
            P1_0;
            P0_top;
            P0_T;
            P1_T];
  beq    = [L_0;
            dL_0;
            Ltop;
            L_d;
            dL_d];
  H      = double(H);
  f      = double(f);
  A      = double(A);
  b      = double(b);
  Aeq    = double(Aeq);
  beq    = double(beq);
  options = optimset('Display', 'on','LargeScale', 'off','MaxIter',1e3);
  alpha_f  = quadprog(H,f,A,b,Aeq,beq,[],[],[],options);