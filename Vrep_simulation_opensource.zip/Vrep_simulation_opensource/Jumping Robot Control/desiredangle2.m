function [ddhkd,dhkd,hkd,thehd,thekd]=desiredangle2(H_des,dH_des,ddH_des,dh,r,Lg)
thehd  = acos((H_des-dh-r)/(2*Lg));
thekd  = -2*thehd;
dthehd = dH_des/(-2*Lg*sin(thehd));
dthekd = -2*dthehd;
ddthehd= -(ddH_des+(H_des-dh-r)*dthehd^2)/(2*Lg*sin(thehd));
ddthekd= -2*ddthehd;
ddhkd   = [ddthehd;ddthekd];
dhkd    = [dthehd;dthekd];
hkd     = [thehd;thekd];


