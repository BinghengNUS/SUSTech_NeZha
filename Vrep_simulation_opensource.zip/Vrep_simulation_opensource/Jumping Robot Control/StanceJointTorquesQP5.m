function [tau,contorqL,contorqR,F] = StanceJointTorquesQP5(Ats,AtF,dAts,state,dstate,ddxtsc,Gs,dGs,thetas,dthetas,psym,torqueLimit,Llqr,theta,dtheta,torq_lqr) 
%This function returns the joint torques for the task-space control, which
%includes two hip joint torques, two knee joint torques and two wheel joint
%torques. All torques are obtained by quadratic programming based on a full
%dynamic model
%psym  = [r,d,g,Lg,Ltcom,Lscom,dh,dhs,mfb,mtl,msl,mw,mur,mus];%system parameter vector
%optimal varibales: sln 23by1,ddq 12by1, tau 6by1, constraint force 5by1
%*********************By Bingheng WANG, on Mar.8 2020*********************

    %---------------------------------------%
    %model in stance (full-model in sagittal plane)
    %---------------------------------------%
    r         = psym(1);
    mup       = psym(9)+2*(psym(10)+psym(11));
    g         = psym(3);
    handle.NB = 3;
    handle.parent = [0 1 2];%from the shank link to the floating base
    handle.jtype = {'Ry', 'Ry', 'Ry'};
    handle.Xtree{1} = eye(6);%from {s} to pendulum frame {p}  
    handle.Xtree{2} = xlt([0,0,psym(4)]);%Adjoint Matrix from {parent i} Link frame to {i}
    handle.Xtree{3} = xlt([0,0,psym(4)+psym(7)]);
    mass = 2*psym(11);%Shank link{s}
    CoM = [0,0.0364494458894979,psym(4)+psym(6)];
    Icm = diag(2*[0.0175958448813304,0.0177210394041728,0.000378821101531682]);
    handle.I{1} = mcI( mass, CoM, Icm );
    mass = 2*psym(10);%Thigh link
    CoM = [0,0.0637001804791891,psym(4)+psym(5)];
    Icm =  diag(2*[0.0223883715246182,0.022309557436881,0.00172727939342223]);
    handle.I{2} = mcI( mass, CoM, Icm );
    mass = psym(9);%Base 
    CoM = [0,0,0];
    Icm =  diag([0.0261376195979353,0.0249232975683053,0.0143828822217345]);
    handle.I{3} = mcI( mass, CoM, Icm );
    states  = [thetas;-(state(8)+state(11))/2;-(state(7)+state(10))/2];
    dstates = [dthetas;-(dstate(8)+dstate(11))/2;-(dstate(7)+dstate(10))/2];
    [M,C]     = HandC(handle, states, dstates, []);  
    dqi   = [-(dstate(8)+dstate(11))/2;-(dstate(7)+dstate(10))/2];
    Ms    = Gs.'*M*Gs;
    Cs    = Gs.'*M*dGs*dqi+Gs.'*C;
    S     = [zeros(1,2);eye(2)];
    Ss    = Gs.'*S;
    %---------------------------------%
    %Quadratic programming formulation
    %---------------------------------%
    Hs    = Ats.'*Ats;
    fs    = Ats.'*(dAts*dqi-ddxtsc);
    Hsqp  = blkdiag(Hs,zeros(2,2));
    fsqp  = [fs;zeros(2,1)];
    Aeqs  = [Ms,-Ss];
    beqs  = -Cs;
    Hsqp  = double(Hsqp);
    fsqp = double(fsqp);
    Aeqs = double(Aeqs);
    beqs = double(beqs);
    %limits of control torques
    usmin   = -[torqueLimit(3);torqueLimit(1)];
    usmax   = [torqueLimit(3);torqueLimit(1)];
    %limits of optimal variables
    lb    = [-Inf(2,1);usmin];
    ub    = [Inf(2,1);usmax];
    [slns,optC] = quadprog(Hsqp,fsqp,[],[],Aeqs,beqs,lb,ub);%hip, knee, followed by right side
    hiptorqueL  = 1/2*slns(4);
    kneetorqueL = 1/2*slns(3);
    hiptorqueR  = 1/2*slns(4);
    kneetorqueR = 1/2*slns(3);
    F     = pinv(AtF.')*[slns(3);slns(4)];
    mddlL = F/2-mup/2*g*cos(theta)+mup/2*Llqr*dtheta^2;
    mddlR = F/2-mup/2*g*cos(theta)+mup/2*Llqr*dtheta^2;
    k     = 0.3;
    contorqL = k*mddlL*sin(theta)*r;
    contorqR = k*mddlR*sin(theta)*r;
    wheeltorqueL = torq_lqr(1)+contorqL;
    wheeltorqueR = torq_lqr(2)+contorqR;
    tau   = [-hiptorqueL;-hiptorqueR;-kneetorqueL;-kneetorqueR;wheeltorqueL;wheeltorqueR];

