function [D_joint,D_wip,dz_joint,dz_wip,dtanh_joint,dtanh_wip,Xi_j,Xi_w,Md] = Disturbance_ObserverWBCPD(K1j,K2j,K1w,K2w,torque,dstate,x,z_joint,z_wip,tanh_joint,tanh_wip,Llqr,psym)
%This function returns the estimated disturbance via super-twisting
%algorithm(STA). The disturbance consists of the dynamics coupling between
%joints and the nonlinearity that was ignored by linearization in LQR. The
%real-time estimation is guaranteed.
%psym  = [r,d,g,Lg,Ltcom,Lscom,dh,dhs,mfb,mtl,msl,mw,mur,mus];
%**************By Bingheng WANG, on Mar.30, 2020**************************
dh          = psym(7);
Lg          = psym(4);
Ltcom       = psym(5);
mfb         = psym(9);
mtl         = psym(10);
Iyyb        = 0.0249232975683053;
Iyyt        = 0.022309557436881;
Mhip        = 1/2*(mfb*dh^2+Iyyb);
Mknee       = mtl*(Lg+Ltcom)^2+Iyyt;
%---STA-based disturbance estimation for joints---%
ep          = 100;%parameter in tanh function
Xi_j        = z_joint-[dstate(7);dstate(8);dstate(10);dstate(11)];%estimate error
D_jhL       = -K1j(1)*sqrt(abs(Xi_j(1)))*tanh(ep*Xi_j(1))-K2j(1)*tanh_joint(1);
D_jkL       = -K1j(2)*sqrt(abs(Xi_j(2)))*tanh(ep*Xi_j(2))-K2j(2)*tanh_joint(2);
D_jhR       = -K1j(3)*sqrt(abs(Xi_j(3)))*tanh(ep*Xi_j(3))-K2j(3)*tanh_joint(3);
D_jkR       = -K1j(4)*sqrt(abs(Xi_j(4)))*tanh(ep*Xi_j(4))-K2j(4)*tanh_joint(4);
D_joint     = [D_jhL;D_jkL;D_jhR;D_jkR];
dtanh_joint = [tanh(ep*Xi_j(1));tanh(ep*Xi_j(2));tanh(ep*Xi_j(3));tanh(ep*Xi_j(4))];
Md          = diag([Mhip,Mknee,Mhip,Mknee]);
tau_joint   = [torque(1);torque(3);torque(2);torque(4)];
dz_joint    = Md^(-1)*tau_joint+D_joint;
%---STA-based disturbance estimation for WIP---%
A   =[0,          0,     0,     1;
      -49539/925,    0,     0,     0;
      0,          0,     0,     0;
      58604/(925*Llqr),0,     0,     0];
B   =[0,                                                                     0;
      25/(37*Llqr) + 250/37,                             25/(37*Llqr) + 250/37;
      -17470/453,                                                    17470/453;
      -(50*(5055*Llqr + 598))/(37407*Llqr^2),-(50*(5055*Llqr + 598))/(37407*Llqr^2)];
Xi_w        = z_wip-[x(2);x(3);x(4)];%estimate error
Ar          = [A(2,1)*x(1);0;A(4,1)*x(1)];
Br          = [B(2,1),B(2,1);B(3,1),B(3,2);B(4,1),B(4,2)];
tau_wheel   = [torque(5);torque(6)];
d_wv        = -K1w(1)*sqrt(abs(Xi_w(1)))*tanh(ep*Xi_w(1))-K2w(1)*tanh_wip(1);
d_wp        = -K1w(2)*sqrt(abs(Xi_w(2)))*tanh(ep*Xi_w(2))-K2w(2)*tanh_wip(2);
d_wt        = -K1w(3)*sqrt(abs(Xi_w(3)))*tanh(ep*Xi_w(3))-K2w(3)*tanh_wip(3);
d_wip       = [d_wv;d_wp;d_wt];
dtanh_wip   = [tanh(ep*Xi_w(1));tanh(ep*Xi_w(2));tanh(ep*Xi_w(3))];
dz_wip      = Ar+Br*tau_wheel+d_wip;
D_wip       = pinv(Br)*d_wip;
