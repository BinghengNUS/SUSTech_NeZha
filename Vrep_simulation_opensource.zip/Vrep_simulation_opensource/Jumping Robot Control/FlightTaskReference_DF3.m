function [pf_ref,dpf_ref,ddpf_ref] = FlightTaskReference_DF3(baseorientation,wb,dwb,psym,v_ref,L_fd,dL_fd,ddL_fd,theta_fd,dtheta_fd,ddtheta_fd) 
%This function returns the reference for task-space. In the flight phase the reference is
%for the wheel center in {b}. The reference of base c.o.m is optimized by a
%one-dimensional SLIP model online using quadratic programming. The wheel
%center reference is temporarily constant in {s}
%state=[x;y;z;roll;pitch;yaw;thetahl;thetakl;thetawl;thetahr;thetakr;thetawr]
%shanktilt=[theta0l;theta0r]
%psym  = [r,d,g,Lg,Ltcom,Lscom,dh,dhs,mfb,mtl,msl,mw,mu];%system parameter vector
%*********************By Bingheng WANG, on Mar.8 2020*********************
    
    roll    = baseorientation(1);
    pitch   = baseorientation(2);
    yaw     = baseorientation(3);
    Rs2b    = Rzyx(roll,pitch,yaw);
    pfds    = [-L_fd*sin(theta_fd);0;-L_fd*cos(theta_fd)];%desired wheel position w.r.t base c.o.m in {s}
    dpfds   = [-dL_fd*sin(theta_fd)-L_fd*cos(theta_fd)*dtheta_fd;0;-dL_fd*cos(theta_fd)+L_fd*sin(theta_fd)*dtheta_fd];
    ddpfds  = [-ddL_fd*sin(theta_fd)-2*dL_fd*cos(theta_fd)*dtheta_fd+L_fd*sin(theta_fd)*dtheta_fd^2-L_fd*cos(theta_fd)*ddtheta_fd;
               0;
               -ddL_fd*cos(theta_fd)+2*dL_fd*sin(theta_fd)*dtheta_fd+L_fd*cos(theta_fd)*dtheta_fd^2+L_fd*sin(theta_fd)*ddtheta_fd];
           
    pfddL   = Rs2b*pfds;%transfered to {b}
    pf_ref  = [pfddL(1);pfddL(3);0;pfddL(1);pfddL(3);0];%desired x, z position of wheel in {b} and wheel joint angle
    dpfdd   = -skew(wb)*Rs2b*pfds+Rs2b*dpfds;%desired velocity of wheel center in {b}
    dpf_ref = [dpfdd(1);dpfdd(3);v_ref/psym(1);dpfdd(1);dpfdd(3);v_ref/psym(1)];
    ddpfdd  = -skew(dwb)*Rs2b*pfds+skew(wb)^2*Rs2b*pfds-skew(dwb)*Rs2b*dpfds+Rs2b*ddpfds;%desired acceleration of wheel center in {b}
    ddpf_ref= [ddpfdd(1);ddpfdd(3);0;ddpfdd(1);ddpfdd(3);0];
