function [alpha,beta,betadx,val] = Optimal_Trajectory3(psym,kp,tc,Llqr,dLlqr,theta,dtheta,v,ddtheta,flagjump,zmax,theta_LO,dtheta_LO,vd,Lds,torqueLimit,the_off)
%This function provides optimal trajectories of length, angle and velocity
%for the robot to track. The trajectories are planned via two steps:
%STEP1: plan the references via decoupled linear models
%STEP2: re-plan the trajectories by trading off between the ref. and 2D
%differentially flat model
%*********************By Bingheng WANG, on May 7, 2020********************
%------------------%
%Parameters Setting
%------------------%
    g    = psym(3);
    m    = psym(9)+2*(psym(10));%total upper mass
    mb   = 2*(psym(11)+psym(12));%mass of shank link and wheel
    kL   = m/(m+mb);
    r    = psym(1);%radius of wheel
    Lg   = psym(4);%length of leg (Thigh link and Shank link)
    dh   = psym(7);%height of base c.o.m relative to the hip joint
%------------------------------------------------------%
%STEP 1: Reference planning via decoupled linear models
%------------------------------------------------------%
  %---A: Length planning via 1D decoupled SLIP model---%
    %initialization of length planning
    L_0  = Llqr;
    dL_0 = dLlqr;
    %spring stiffness
    L0       = 2*Lg+dh;
    thekmin  = -140/180*pi;
    thekmax  = -60/180*pi;
    Lmin     = -Lg*sin(thekmax/2);
    Lmax     = -Lg*sin(thekmin/2);
    zmin     = 2*Lg*cos(thekmin/2)+dh;
    Ksmax  = kp/(Lmin^2);
    Ksmin  = kp/(Lmax^2);
    Ks     = 1/2*(Ksmax+Ksmin);
    Ts     = 2*pi*sqrt(m/Ks);%estimate of the spring period
    if flagjump==0%no jump
        T      = Ts-tc;%actual planning horizon, variable horizon
    else
        T      = Ts-tc;
    end
    
    %constraints dependent on flagjump
    
    if flagjump==0%no jump
        N      = 10;
        Ld     = Lds+dh;
        thed   = theta_LO;
        dthed  = dtheta_LO;
        dLd    = (kL^(-1)*sqrt(2*g*(zmax-kL*Ld*cos(thed)-r))+Ld*sin(thed)*dthed)/cos(thed);
        Accd   = [-(1+mb/m)*g+2*dLd*sin(thed)*dthed+Ld*cos(thed)*dthed^2;
                 -mb/m*g*tan(thed)-g*tan(thed)-2*dLd*cos(thed)*dthed+Ld*sin(thed)*dthed^2];
        Mcc    = [cos(thed),  sin(thed);
                  -sin(thed)/Ld,cos(thed)/Ld];
        accd   = Mcc^(-1)*Accd;
        ddLd   = accd(1);
    else
        N      = 10;
        Ld     = Lds+dh;
        dLd    = 0;
        ddLd   = 0;
    end
    dLmax  = (L0-zmin)*(Ksmax-Ks)/Ks;%upper limit of length change
    dLmin  = (L0-zmin)*(Ksmin-Ks)/Ks;
    %QP formulation
   
    delt   = T/N;
    A      = zeros(3*(N+1),10);
    b      = zeros(3*(N+1),1);
    k      = 1;
    H      = zeros(10,10);
    for t=0:delt:T
        [P0,~,P2] = poly(t);
        H          = H+P2.'*P2;
        A(k,:)     = m/Ks*P2+P0;
        A(k+N+1,:) = -m/Ks*P2-P0;
        b(k)       = dLmax+L0-m*g/Ks;
        b(k+N+1)   = -dLmin-L0+m*g/Ks;
        A(k+2*(N+1),:)=P0;
        b(k+2*(N+1))=L_0;
        k          = k+1;
    end
    [P0_0,P1_0,~] = poly(0);
    [P0_T,P1_T,P2_T] = poly(T);
    Aeq    = [P0_0;
              P1_0;
              P0_T;
              P1_T;
              P2_T];
    beq    = [L_0;
              dL_0;
              Ld;
              dLd;
              ddLd];
    beq    = double(beq);
    alphaL = quadprog(H,[],A,b,Aeq,beq);
    NL     = 1000;
    deltdL = T/NL;
    DelL   = zeros(N+1,1);
    k      = 1;
    for t=0:deltdL:T
        [P0,~,P2] = poly(t);
        DelL(k)   = (m*P2*alphaL+m*g-Ks*(L0-P0*alphaL))/Ks;
        k         = k+1;
    end
    t=0:deltdL:T;
    alphaDL = polyfit(t,DelL.',9);
    alphaDL = alphaDL.';
  %---B: Angle planning via 1D linearized constraint---%
    %initialization of angle planning
    the_0  = theta-the_off;%tilting angle
    dthe_0 = dtheta;%tilting angular velocity
    ddthe_0= ddtheta;
    dx_0   = v;%forward speed
    %constraints dependent on flagjump
    if flagjump==0%no jump
        thed   = theta_LO;
        dthed  = dtheta_LO;
        ddthed = accd(2);
        dxd    = vd;%+ddxd*T;
        ddxd   = g*tan(thed);%;(dxd-dx_0)/Ts
    else
        thed   = 0;
        dthed  = 0;
        ddthed = 0;
        ddxd   = 0;
        dxd    = vd;
    end
    torq_wc = torqueLimit(6);
    Fxmax   = 2*torq_wc/r;
    Fxmin   = -Fxmax;
    %QP formulation
    [P0_T,P1_T,P2_T] = poly(T);
    Q5     = 1e5;
    Q1     = 1e10/Q5;
    Q2     = 1e10/Q5;
    Q3     = 1e8/Q5;
    Q4     = 1e8/Q5;
    Q5     = 1;
    Ha     = P0_T.'*Q1*P0_T+P1_T.'*Q2*P1_T+P2_T.'*Q3*P2_T;
    Hx     = P1_T.'*Q4*P1_T+P2_T.'*Q5*P2_T;
    fa     = -(P0_T.'*Q1*thed+P1_T.'*Q2*dthed+P2_T.'*Q3*ddthed);
    fx     = -(P1_T.'*Q4*dxd+P2_T.'*Q5*ddxd);
    H2     = blkdiag(Ha,Hx);
    f2     = [fa;
              fx];
    Aeq2   = zeros(N+4,20);
    beq2   = zeros(N+4,1);
    A2     = zeros(5*(N+1),20);
    b2     = zeros(5*(N+1),1);
    k      = 1;
    for t=0:delt:T
        [P0,P1,P2] = poly(t);
        L          = P0*alphaL;
        dL         = P1*alphaL;
        ddL        = P2*alphaL;
%         Aeq2(k,:)  = [L*P2-g*P0+2*dL*P1,P2];
%         Aeq2(k,:)  = [(m*L^2+r*m*L)*P2+(r*m*ddL-m*g*L)*P0+2*m*(L+r)*dL*P1,(m*L+r*(m+mb))*P2];
%         beq2(k,1)  = 0;
        Aeq2(k,:)  = [(m*L^2+r*m*L*cos(the_0))*P2+2*m*(L+r*cos(the_0))*dL*P1+(r*m*cos(the_0)*ddL-r*m*L*sin(the_0)*ddthe_0-2*m*r*dL*sin(the_0)*dthe_0-m*g*L*cos(the_0)-2*m*r*L*cos(the_0)*dthe_0^2-4*m*r*L*sin(the_0)*dthe_0)*P0,(m*L*cos(the_0)+r*(m+mb))*P2];
        beq2(k,:)  = -r*m*sin(the_0)*ddL+r*m*cos(the_0)*the_0*ddL-r*m*L*cos(the_0)*ddthe_0-r*m*L*sin(the_0)*ddthe_0*the_0+r*m*L*cos(the_0)*ddthe_0-2*m*r*dL*cos(the_0)*dthe_0-2*m*r*dL*sin(the_0)*dthe_0*the_0+2*m*r*dL*cos(the_0)*dthe_0+m*g*L*sin(the_0)-m*g*L*cos(the_0)*the_0+2*m*r*L*sin(the_0)*dthe_0^2-2*m*r*L*cos(the_0)*dthe_0^2*the_0-4*m*r*L*sin(the_0)*dthe_0^2;
        A2(k,:)    = [m*L*P2+m*ddL*P0+2*m*dL*P1,(m+mb)*P2];
        b2(k)      = Fxmax;
        A2(k+N+1,:)= -[m*L*P2+m*ddL*P0+2*m*dL*P1,(m+mb)*P2];
        b2(k+N+1)  = -Fxmin;
        A2(k+2*(N+1),:)=[zeros(1,10),-P1];
        b2(k+2*(N+1))=-0.1;
        A2(k+3*(N+1),:)=[zeros(1,10),P1];
        b2(k+3*(N+1))= 3;
        A2(k+4*(N+1),:)=[-P0,zeros(1,10)];
        b2(k+4*(N+1))= 0;
        k          = k+1;
    end
    [P0_0,P1_0,P2_0] = poly(0);
    Aeq2(N+2:N+4,:)   = [P0_0,zeros(1,10);
                         P1_0,zeros(1,10);
                         zeros(1,10),P1_0;
%                          zeros(1,10),P2_0
                        ];
    beq2(N+2:N+4,:)   = [the_0;
                         dthe_0;
                         dx_0;
%                          ddx_0
                        ];
    beq2   = double(beq2);
    f2     = double(f2);
    options = optimset('Display', 'on','LargeScale', 'off','MaxIter',2e3);
    coeff2  = quadprog(H2,f2,A2,b2,Aeq2,beq2,[],[],[],options);
%     alphat = coeff2(1:10,1);
    betax  = coeff2(11:20,1);
%------------------------------------------------------%
%STEP 2: Integration through nonlinear model
%------------------------------------------------------%
  opts   = odeset('RelTol',1e-12,'AbsTol',1e-13);
  xs0    = [L_0;the_0;dL_0;dthe_0];
  tspan  = [0 T];
  [t,xs]  = ode45(@(t,xs)nonlinearmodel(t,xs,alphaDL,betax,g,m,mb,r,Ks,L0),tspan,xs0,opts);
  alphaLn = polyfit(t,xs(:,1),9);
  alphaLn = alphaLn.';
  betatn  = polyfit(t,xs(:,2),9);
  betatn  = betatn.';
%------------------------------------------------------%
%STEP 3: Trade-off between Ref. and nonlinear model
%------------------------------------------------------%
  %initialization
  x0     = [L_0;the_0;dL_0;dthe_0];%length, angle, length rate, angular rate
  %constraints dependent on flagjump
  if flagjump==0%no jump
      thed   = theta_LO;
      dthed  = dtheta_LO;
      ddthed = accd(2);
      Ld     = Lds+dh;
      dLd    = (kL^(-1)*sqrt(2*g*(zmax-kL*Ld*cos(thed)-r))+Ld*sin(thed)*dthed)/cos(thed);
      ddLd   = accd(1);
  else
      thed   = 0;
      dthed  = 0;
      ddthed = 0;
      Ld     = Lds+dh;
      dLd    = 0;
      ddLd   = 0;
  end
  [P0_0,P1_0,~]=poly(0);
  Aeq3   = [P0_0,zeros(1,10);
            P1_0,zeros(1,10);
            zeros(1,10),P0_0;
            zeros(1,10),P1_0];
  beq3   = [x0(1);x0(3);x0(2);x0(4)];
  beq3   = double(beq3);
  %QP formulation
  kq     = 1e-5;
  Q1     = kq*eye(10);
  Q2     = kq*eye(10);
  kr     = 1;
  QT3    = kr;
  QT4    = kr;
  QT5    = kr;
  QT6    = kr;
  QT7    = kr;
  QT8    = kr;
%   delt   = T/N;
  [PT0,PT1,PT2]=poly(T);
  Ha     = Q1+PT0.'*QT3*PT0+PT1.'*QT4*PT1+PT2.'*QT5*PT2;
  Hb     = Q2+PT0.'*QT6*PT0+PT1.'*QT7*PT1+PT2.'*QT8*PT2;
  fa     = -(Q1*alphaLn+PT0.'*QT3*Ld+PT1.'*QT4*dLd+PT2.'*QT5*ddLd);
  fb     = -(Q2*betatn+PT0.'*QT6*thed+PT1.'*QT7*dthed+PT2.'*QT8*ddthed);
  H      = blkdiag(Ha,Hb);
  f      = [fa;
            fb];
  f      = double(f);
  [coeff,val]  = quadprog(H,f,[],[],Aeq3,beq3);
  alpha  = coeff(1:10,1);%final coefficient of length
  beta   = coeff(11:20,1);%final coefficient of angle
  %integration of acceleration to get velocity
  opts   = odeset('RelTol',1e-12,'AbsTol',1e-13);
  dx0    = dx_0;
  tspan  = [0 T];
  [t,dx]  = ode45(@(t,dx)acceleration2 (t,dx,alpha,beta,g),tspan,dx0,opts);
  betadx = polyfit(t,dx,9);
  betadx = betadx.';
  