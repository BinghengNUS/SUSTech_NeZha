function K=LQRcontrol_NewPara(Llqr,theta_ref,dtheta_ref,v_ref,F_ref,Q,R)
L1   = Llqr;%bs_ref+dh;
t1   = theta_ref;
dt1  = dtheta_ref;
v    = v_ref;
%% A,B matrices for single WIP systems
A11  = 0;
A12  = 0;
A13  = 0;
A14  = 1;
A21  = -(127*F_ref*sin(t1) - 118237*L1 + 148029*L1*cos(t1)^2 - 9025*L1^2*dt1^2*cos(t1)^3 +...
    5985*L1^2*dt1^2*cos(t1) + 95*F_ref*cos(t1)^2*sin(t1) + ...
    1900*F_ref*L1*cos(t1)*sin(t1))/(L1*(95*cos(t1)^2 - 127)^2);
A22  = 0;
A23  = 0;
A24  = (190*L1*dt1*sin(t1))/(95*sin(t1)^2 + 32);
A31  = 0;
A32  = 0;
A33  = -(23750*L1*(v*sin(t1) + 2*L1*dt1*cos(t1)*sin(t1)))/(23750*L1^2 - 23750*L1^2*cos(t1)^2 + 244);
A34  = 0;
A41  = (60325*L1^2*dt1^2 - 392049*L1*cos(t1) + 591185*L1*cos(t1)^3 - 75525*L1^2*dt1^2*cos(t1)^2 +...
    1270*F_ref*cos(t1)*sin(t1) + 6350*F_ref*L1*sin(t1) + ...
    4750*F_ref*L1*cos(t1)^2*sin(t1))/(5*L1^2*(95*cos(t1)^2 - 127)^2);
A42  = 0;
A43  = 0;
A44  = (190*dt1*sin(2*t1))/(95*cos(2*t1) - 159);
B11  = 0;
B12  = 0;
B21  = -(10*(10*L1 + cos(t1)))/(L1*(95*cos(t1)^2 - 127));
B22  = -(10*(10*L1 + cos(t1)))/(L1*(95*cos(t1)^2 - 127));
B31  = -8735/(23750*L1^2 - 23750*L1^2*cos(2*t1) + 488);
B32  = 8735/(23750*L1^2 - 23750*L1^2*cos(2*t1) + 488);
B41  = (2*(950*L1*cos(t1) + 127))/(19*L1^2*(95*cos(t1)^2 - 127));
B42  = (2*(950*L1*cos(t1) + 127))/(19*L1^2*(95*cos(t1)^2 - 127));

A    = [A11,A12,A13,A14;
        A21,A22,A23,A24;
        A31,A32,A33,A34;
        A41,A42,A43,A44];
B    = [B11,B12;
        B21,B22;
        B31,B32;
        B41,B42];

K   =lqr(A,B,Q,R);