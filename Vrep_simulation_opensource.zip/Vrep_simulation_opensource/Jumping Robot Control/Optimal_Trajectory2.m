function [alpha,beta,betadx] = Optimal_Trajectory2(psym,kp,tc,Llqr,dLlqr,theta,dtheta,v,dv,flagjump,zmax,theta_LO,vd,Lds,torqueLimit,the_off)
%This function provides optimal trajectories of length, angle and velocity
%for the robot to track. The trajectories are planned via two steps:
%STEP1: plan the references via decoupled linear models
%STEP2: re-plan the trajectories by trading off between the ref. and 2D
%differentially flat model
%*********************By Bingheng WANG, on May 7, 2020********************
%------------------%
%Parameters Setting
%------------------%
    g    = psym(3);
    m    = psym(8)+2*(psym(10));%total upper mass
    mb   = 2*(psym(11)+psym(12));%mass of shank link and wheel
    r    = psym(1);%radius of wheel
    Lg   = psym(4);%length of leg (Thigh link and Shank link)
    dh   = psym(7);%height of base c.o.m relative to the hip joint
%------------------------------------------------------%
%STEP 1: Reference planning via decoupled linear models
%------------------------------------------------------%
  %---A: Length planning via 1D decoupled SLIP model---%
    %initialization of length planning
    L_0  = Llqr;
    dL_0 = dLlqr;
    %spring stiffness
    L0     = 2*Lg+dh;
    thekmin  = -140/180*pi;
    thekmax  = -60/180*pi;
    Lmin     = -Lg*sin(thekmax/2);
    Lmax     = -Lg*sin(thekmin/2);
    zmin     = 2*Lg*cos(thekmin/2)+dh;
    Ksmax  = kp/(Lmin^2);
    Ksmin  = kp/(Lmax^2);
    Ks     = 1/2*(Ksmax+Ksmin);
    Ts     = 2*pi*sqrt(m/Ks);%estimate of the spring period
    if flagjump==0%no jump
        T      = Ts-tc;%actual planning horizon, variable horizon
    else
        T      = 1.5*Ts;
    end
    
    %constraints dependent on flagjump
    
    if flagjump==0%no jump
        Ld     = Lds;
        thetad = 0;%temporarily set as 0 in the 1D model
        dLd    = sqrt(2*g*(zmax-Ld*cos(thetad)-r))/cos(thetad);
        ddLd   = -g-mb/m*g;
    else
        Ld     = Lds+dh;
        dLd    = 0;
        ddLd   = 0;
    end
    dLmax  = (L0-zmin)*(Ksmax-Ks)/Ks;%upper limit of length change
    dLmin  = (L0-zmin)*(Ksmin-Ks)/Ks;
    %QP formulation
    N      = 10;
    delt   = T/N;
    A      = zeros(2*(N+1),10);
    b      = zeros(2*(N+1),1);
    k      = 1;
    H      = zeros(10,10);
    for t=0:delt:T
        [P0,~,P2] = poly(t);
        H          = H+P2.'*P2;
        A(k,:)     = m/Ks*P2+P0;
        A(k+N+1,:) = -m/Ks*P2-P0;
        b(k)       = dLmax+L0-m*g/Ks;
        b(k+N+1)   = -dLmin-L0+m*g/Ks;
        k          = k+1;
    end
    [P0_0,P1_0,~] = poly(0);
    [P0_T,P1_T,P2_T] = poly(T);
    Aeq    = [P0_0;
              P1_0;
              P0_T;
              P1_T;
              P2_T];
    beq    = [L_0;
              dL_0;
              Ld;
              dLd;
              ddLd];
    beq    = double(beq);
    alphaL = quadprog(H,[],A,b,Aeq,beq);
  %---B: Angle planning via 1D linearized constraint---%
    %initialization of angle planning
    the_0  = theta;%tilting angle
    dthe_0 = dtheta;%tilting angular velocity
    dx_0   = v;%forward speed
    ddx_0  = dv;%forward acceleration
    %constraints dependent on flagjump
    if flagjump==0%no jump
        thed   = theta_LO;
        dthed  = 0;
        ddthed = g*sin(thed)/Ld;
        dxd    = vd/2;%+ddxd*T;
        ddxd   = g*tan(thed);%;(dxd-dx_0)/Ts
        
    else
        thed   = 0;
        dthed  = 0;
        ddthed = 0;
        ddxd   = 0;
        dxd    = vd;
    end
    torq_wc = torqueLimit(6);
    Fxmax   = 2*torq_wc/r;
    Fxmin   = -Fxmax;
    %QP formulation
    [P0_T,P1_T,P2_T] = poly(T);
    Q5     = 1e5;
    Q1     = 1e11/Q5;
    Q2     = 1e10/Q5;
    Q3     = 1e8/Q5;
    Q4     = 1e7/Q5;
    Q5     = 1;
    Ha     = P0_T.'*Q1*P0_T+P1_T.'*Q2*P1_T+P2_T.'*Q3*P2_T;
    Hx     = P1_T.'*Q4*P1_T+P2_T.'*Q5*P2_T;
    fa     = -(P0_T.'*Q1*thed+P1_T.'*Q2*dthed+P2_T.'*Q3*ddthed);
    fx     = -(P1_T.'*Q4*dxd+P2_T.'*Q5*ddxd);
    H2     = blkdiag(Ha,Hx);
    f2     = [fa;
              fx];
    Aeq2   = zeros(N+5,20);
    beq2   = zeros(N+5,1);
    A2     = zeros(3*(N+1),20);
    b2     = zeros(3*(N+1),1);
    k      = 1;
    for t=0:delt:T
        [P0,P1,P2] = poly(t);
        L          = P0*alphaL;
        dL         = P1*alphaL;
        ddL        = P2*alphaL;
        Aeq2(k,:)  = [L*P2-g*P0+2*dL*P1,P2];
        beq2(k,1)  = 0;
        A2(k,:)    = [m*L*P2+m*ddL*P0+2*m*dL*P1,(m+mb)*P2];
        b2(k)      = Fxmax;
        A2(k+N+1,:)= -[m*L*P2+m*ddL*P0+2*m*dL*P1,(m+mb)*P2];
        b2(k+N+1)  = -Fxmin;
        A2(k+2*(N+1),:)=[zeros(1,10),-P1];
        b2(k+2*(N+1))=0;
        k          = k+1;
    end
    [P0_0,P1_0,P2_0] = poly(0);
    Aeq2(N+2:N+5,:)   = [P0_0,zeros(1,10);
                         P1_0,zeros(1,10);
                         zeros(1,10),P1_0;
                         zeros(1,10),P2_0
                        ];
    beq2(N+2:N+5,:)   = [the_0;
                         dthe_0;
                         dx_0;
                         ddx_0
                        ];
    beq2   = double(beq2);
    f2     = double(f2);
    coeff2 = quadprog(H2,f2,A2,b2,Aeq2,beq2);
    alphat = coeff2(1:10,1);
%     betaddx= coeff2(11:20,1);
%------------------------------------------------------%
%STEP 2: Trade-off between Ref. and nonlinear model
%------------------------------------------------------%
  %initialization
  x0     = [L_0;the_0;dL_0;dthe_0];%length, angle, length rate, angular rate
  %constraints dependent on flagjump
  if flagjump==0%no jump
      thed   = theta_LO;
      dthed  = 0;
      ddthed = g*sin(thed)/Ld;
      Ld     = Lds;
      dLd    = sqrt(2*g*(zmax-Ld*cos(thed)-r))/cos(thed);
      ddLd   = -g*cos(thed)-mb/m*g/cos(thed);
  else
      thed   = 0;
      dthed  = 0;
      ddthed = 0;
      Ld     = Lds+dh;
      dLd    = 0;
      ddLd   = 0;
  end
  [P0_0,P1_0,~]=poly(0);
  Aeq3   = [P0_0,zeros(1,10);
            P1_0,zeros(1,10);
            zeros(1,10),P0_0;
            zeros(1,10),P1_0];
  beq3   = [x0(1);x0(3);x0(2);x0(4)];
  beq3   = double(beq3);
  %QP formulation
  kq     = 0.1;
  Q1     = kq*eye(10);
  Q2     = kq*eye(10);
  kr     = 1;
  QT3    = kr;
  QT4    = kr;
  QT5    = kr;
  QT6    = kr;
  QT7    = kr;
  QT8    = kr;
%   delt   = T/N;
  [PT0,PT1,PT2]=poly(T);
  Ha     = Q1+PT0.'*QT3*PT0+PT1.'*QT4*PT1+PT2.'*QT5*PT2;
  Hb     = Q2+PT0.'*QT6*PT0+PT1.'*QT7*PT1+PT2.'*QT8*PT2;
  fa     = -(Q1*alphaL+PT0.'*QT3*Ld+PT1.'*QT4*dLd+PT2.'*QT5*ddLd);
  fb     = -(Q2*alphat+PT0.'*QT6*thed+PT1.'*QT7*dthed+PT2.'*QT8*ddthed);
  H      = blkdiag(Ha,Hb);
  f      = [fa;
            fb];
  f      = double(f);
  coeff  = quadprog(H,f,[],[],Aeq3,beq3);
  alpha  = coeff(1:10,1);%final coefficient of length
  beta   = coeff(11:20,1);%final coefficient of angle
  %integration of acceleration to get velocity
  opts   = odeset('RelTol',1e-12,'AbsTol',1e-13);
  x0     = dx_0;
  tspan  = [0 T];
  [t,x]  = ode45(@(t,x)acceleration (t,x,alpha,beta,g),tspan,x0,opts);
  betadx = polyfit(t,x,9);
  betadx = betadx.';
  