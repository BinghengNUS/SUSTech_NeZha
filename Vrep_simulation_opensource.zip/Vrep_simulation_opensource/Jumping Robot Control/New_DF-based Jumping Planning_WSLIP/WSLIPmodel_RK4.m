function Xdot = WSLIPmodel_RK4(t,X,U_ref,kp,psym,Dist)
% X = [x;L;theta;v;dL;dtheta]
% sys = [mb,mw,L0,r,Ks,g]
g          = psym(3);
mb         = psym(9)+2*(psym(10));%total upper mass
mw         = 2*(psym(11)+psym(12));%mass of shank link and wheel
r          = psym(1);%radius of wheel
Lg         = psym(4);%length of leg (Thigh link and Shank link)
dh         = psym(7);%height of base c.o.m relative to the hip joint
%spring stiffness
    L0       = 2*Lg+dh;
    thekmin  = -140/180*pi;
    thekmax  = -60/180*pi;
    Lmin     = -Lg*sin(thekmax/2);
    Lmax     = -Lg*sin(thekmin/2);
    zmin     = 2*Lg*cos(thekmin/2)+dh;
    Ksmax  = kp/(Lmin^2);
    Ksmin  = kp/(Lmax^2);
    Ks     = 1/2*(Ksmax+Ksmin);
%initial state
L          = X(2);
theta      = X(3);
v          = X(4);
dL         = X(5);
dtheta     = X(6);

%forward dynamics
M          = [mb+mw,mb*sin(theta),mb*L*cos(theta);
              mb*sin(theta),mb,0;
              mb*L*cos(theta),0,mb*L^2];
C          = [2*mb*cos(theta)*dL*dtheta-mb*sin(theta)*L*dtheta^2;
              -mb*L*dtheta^2+mb*g*cos(theta)-Ks*(L0-L);
              2*mb*L*dL*dtheta-mb*g*L*sin(theta)];   
S          = [1,0;
              0,Ks;
              -r,0];
D          = [0;0;Dist*L*cos(theta)];
ddX        = M^(-1)*(S*U_ref+D-C);
Xdot       = [v;dL;dtheta;ddX];