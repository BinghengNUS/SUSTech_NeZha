function [alpha,beta] = Optimal_Trajectory5_plantest(psym,kp,tc,X0,zmax,theta_LO,dtheta_LO,vd,Lds)
%This function provides optimal trajectories of length, angle and velocity
%for the robot to track. The trajectories are planned via two steps:
%STEP1: plan the references via decoupled linear models
%STEP2: re-plan the trajectories by trading off between the ref. and 2D
%differentially flat model
%*********************By Bingheng WANG, on May 7, 2020********************
%X0       = [x0;L0;theta0;v0;dL0;dtheta0];
%------------------%
%Parameters Setting
%------------------%
    kg   = 1.25; 
    g    = psym(3);
    m    = psym(9)+2*(psym(10));%total upper mass
    mb   = 2*(psym(11)+psym(12));%mass of shank link and wheel
    kL   = m/(m+mb);
    r    = psym(1);%radius of wheel
    Lg   = psym(4);%length of leg (Thigh link and Shank link)
    dh   = psym(7);%height of base c.o.m relative to the hip joint
    %spring stiffness
    L0       = 2*Lg+dh;
    thekmin  = -140/180*pi;
    thekmax  = -60/180*pi;
    Lmin     = -Lg*sin(thekmax/2);
    Lmax     = -Lg*sin(thekmin/2);
    zmin     = 2*Lg*cos(thekmin/2)+dh;
    Ksmax  = kp/(Lmin^2);
    Ksmin  = kp/(Lmax^2);
    Ks     = 1/2*(Ksmax+Ksmin);
    Ts     = 2*pi*sqrt(m/Ks);%estimate of the spring period
    T      = Ts-tc;%actual planning horizon, variable horizon

%------------------------------------------------------%
%STEP 1: Inputs Planning
%------------------------------------------------------%
   %initialization 
    Llqr = X0(2);
    dLlqr= X0(5);
    theta= X0(3);
    dtheta=X0(6);
    v     =X0(4);
    L_0  = Llqr;
    dL_0 = dLlqr;
    the_0  = theta;%tilting angle
    dthe_0 = dtheta;%tilting angular velocity
    dx_0   = v;%forward speed
   %Terminal Constraints
        thed   = theta_LO;
        dxd    = vd;%+ddxd*T;
        ddxd   = kg*g*tan(thed);%;(dxd-dx_0)/Ts
   
   %---A: Length Change Planning---%
       thed   = theta_LO;
       dthed  = dtheta_LO;
       Ld     = Lds+dh;%0
       dLd    = (kL^(-1)*sqrt(2*g*(zmax-kL*Ld*cos(thed)-r))+Ld*sin(thed)*dthed)/cos(thed);
       Accd   = [-(1+mb/m)*kg*g+2*dLd*sin(thed)*dthed+Ld*cos(thed)*dthed^2;
                 -mb/m*kg*g*tan(thed)-kg*g*tan(thed)-2*dLd*cos(thed)*dthed+Ld*sin(thed)*dthed^2];
       Mcc    = [cos(thed),  sin(thed);
                  -sin(thed)/Ld,cos(thed)/Ld];
       accd   = Mcc^(-1)*Accd;
       ddLd   = accd(1);
  
%QP formulation for delL
    dLmax  = (L0-zmin)*(Ksmax-Ks)/Ks;
    dLmin  = (L0-zmin)*(Ksmin-Ks)/Ks;
    Nddx   = 200;
    A1      = zeros(2*Nddx+2,10);
    b1      = zeros(2*Nddx+2,1);
    k      = 1;
    H1     = zeros(10,10);
    deltx  = T/Nddx;
    for t=0:deltx:T
        [P0,~,P2] = poly(t);
        H1          = H1+P2.'*P2*deltx;
        A1(k,:)     = m/Ks*P2+P0;
        A1(k+101,:) = -m/Ks*P2-P0;
        b1(k)       = dLmax+L0-m*g/Ks;
        b1(k+101)   = -dLmin-L0+m*g/Ks;
        k          = k+1;
    end
    [P0_0,P1_0,~] = poly(0);
    [P0_T,P1_T,P2_T] = poly(T);
    Aeq1    = [P0_0;
              P1_0;
              P0_T;
              P1_T;
              P2_T];
    beq1    = [L_0;
              dL_0;
              Ld;
              dLd;
              ddLd];
    options = optimset('Display', 'off','LargeScale', 'off','MaxIter',1e3);
    H1     = double(H1);
    Aeq1   = double(Aeq1);
    beq1   = double(beq1);
    alphaL = quadprog(H1,[],A1,b1,Aeq1,beq1,[],[],[],options);
    DelL   = zeros(Nddx+1,1);
    k=1;
    for t=0:deltx:T
        [P0,~,P2] = poly(t);
        DelL(k)   = (m*P2*alphaL+m*g-Ks*(L0-P0*alphaL))/Ks;
        k=k+1;
    end
    t=0:deltx:T;
    alphaDL = polyfit(t,DelL.',9);
    alphaDL = alphaDL.';
   %---B: Acceleration Planning---%
     H2     = zeros(10,10);
     Nddx   = 200;
     deltx  = T/Nddx;
     A2     = zeros(Nddx+1,10);
     b2     = zeros(Nddx,1);
     k=1;
   for t=0:deltx:T
       [~,P1,P2]=poly(t);
       H2 = H2+P2.'*P2*deltx;
       A2(k,:)= -P1;
       b2(k,:)= 0;
       k=k+1;
   end
   [~,P1_0,~]=poly(0);
   [~,PT1,PT2]=poly(T);
   Aeq2   = [P1_0;
             PT1;
             PT2];
   beq2   = [dx_0;
             dxd;
             ddxd];
   H2     = double(H2);
   Aeq2   = double(Aeq2);
   beq2   = double(beq2);
   A2     = double(A2);
   b2     = double(b2);
   betax = quadprog(H2,[],[],[],Aeq2,beq2,[],[],[],options);%coefficient of x
    
%------------------------------------------------------%
%STEP 2: Integration through nonlinear model
%------------------------------------------------------%
%   opts   = odeset('events',@(t,xs)takeoff(t,xs,alphaDL,betax,g,m,mb,r,Ksn,kL,L0,flagjump),'RelTol',1e-12,'AbsTol',1e-13);
  opts   = odeset('RelTol',1e-12,'AbsTol',1e-13);
  %initialization
  x0     = [L_0;the_0;dL_0;dthe_0];%length, angle, length rate, angular rate
  tspan  = [0 T];
  
  [t,xs]  = ode45(@(t,xs)nonlinearmodel(t,xs,alphaDL,betax,g,m,mb,r,Ks,L0),tspan,x0,opts);
  alphaLn = polyfit(t,xs(:,1),9);
  alphaLn = alphaLn.';
  betatn  = polyfit(t,xs(:,2),9);
  betatn  = betatn.';
%------------------------------------------------------%
%STEP 3: Trade-off between Ref. and nonlinear model
%------------------------------------------------------%
   %QP formulation
  kq     = 1e-7;%2e-5
  Q1     = kq*eye(10);
  Q2     = kq*eye(10);
  kr     = 1;
  QT3    = kr*1;%1e-2
  QT4    = kr*1;
  QT5    = kr*1;
  
  
%constraints dependent on flagjump
      thed   = theta_LO;
      dthed  = dtheta_LO;
      Ld     = Lds+dh;
      dLd    = (kL^(-1)*sqrt(2*g*(zmax-kL*Ld*cos(thed)-r))+Ld*sin(thed)*dthed)/cos(thed);
      Accd   = [-(1+mb/m)*kg*g+2*dLd*sin(thed)*dthed+Ld*cos(thed)*dthed^2;
                 -mb/m*kg*g*tan(thed)-kg*g*tan(thed)-2*dLd*cos(thed)*dthed+Ld*sin(thed)*dthed^2];
      Mcc    = [cos(thed),  sin(thed);
                  -sin(thed)/Ld,cos(thed)/Ld];
      accd   = Mcc^(-1)*Accd;
      ddthed = accd(2);
      dLd    = (kL^(-1)*sqrt(2*g*(zmax-kL*Ld*cos(thed)-r))+Ld*sin(thed)*dthed)/cos(thed);
      ddLd   = accd(1);
      QT6    = kr*2e2;%3e6
      QT7    = kr*1;
      QT8    = kr*1;
  [PT0,PT1,PT2]=poly(T);
  [P0_0,P1_0,~]=poly(0);
  Aeq3   = [P0_0,zeros(1,10);
            P1_0,zeros(1,10);
            zeros(1,10),P0_0;
            zeros(1,10),P1_0
            ];
  Aeq3   = double(Aeq3);
  beq3   = [x0(1);x0(3);x0(2);x0(4)];
  beq3   = double(beq3);

%   delt   = T/N;
  
  Ha     = Q1+PT0.'*QT3*PT0+PT1.'*QT4*PT1+PT2.'*QT5*PT2;
  Hb     = Q2+PT0.'*QT6*PT0+PT1.'*QT7*PT1+PT2.'*QT8*PT2;
  fa     = -(Q1*alphaLn+PT0.'*QT3*Ld+PT1.'*QT4*dLd+PT2.'*QT5*ddLd);
  fb     = -(Q2*betatn+PT0.'*QT6*thed+PT1.'*QT7*dthed+PT2.'*QT8*ddthed);
  H3      = blkdiag(Ha,Hb);
  f3      = [fa;
            fb];
  f3      = double(f3);
  N       = 200;
  A3      = [-PT1,zeros(1,10);
             zeros(1,10),PT1];
  b3      = [0;dLd/(Ld*tan(thed))];
  A3     = double(A3);
  b3     = double(b3);

  H3     = double(H3);
  coeff  = quadprog(H3,f3,[],[],Aeq3,beq3,[],[],[],options);
  alpha  = coeff(1:10,1);%final coefficient of length
  beta   = coeff(11:20,1);%final coefficient of angle

  