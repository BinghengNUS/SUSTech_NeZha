function [tau,contorqL,contorqR] = StanceJointTorquePD(state,ddq,Llqr,dLlqr,theta,dtheta,ddtheta,ddxtsc,torq_lqr,psym)
%This function returns the joint torques needed for the robot base c.o.m to
%track the desired c.o.m trajectory. The control law is PD plus gravity
%compensation.
%psym  = [r,d,g,Lg,Ltcom,Lscom,dh,dhs,mfb,mtl,msl,mw,mur,mus];
%****************By Bingheng WANG, on Mar.19 2020*************************
r        = psym(1);
g        = psym(3);
dh       = psym(7);
Lg       = psym(4);
Ltcom    = psym(5);
mfb      = psym(9);
mtl      = psym(10);
mw       = psym(12);
pitchb   = state(5);
mup      = psym(9)+2*(psym(10)+psym(11));
mur      = psym(13);
Iyyb     = 0.8*0.0249232975683053;
Iyyt     = 1.2*0.022309557436881;
hiptorqL = Iyyb*ddxtsc(1)+dh*mfb/2*sin(pitchb);
hiptorqR = Iyyb*ddxtsc(3)+dh*mfb/2*sin(pitchb);
kneetorqL= Iyyt*ddxtsc(2)+(mfb/2+mtl)*(Lg+Ltcom)*sin(pitchb+state(7));
kneetorqR= Iyyt*ddxtsc(4)+(mfb/2+mtl)*(Lg+Ltcom)*sin(pitchb+state(10));
    if state(8)~=0 && state(8)~= pi
      FL     = kneetorqL/(-Lg*sin(state(8)/2)); 
    else
      FL   = mup/2*sin(theta)*r*(ddtheta+ddq(5))-mup/2*Llqr*dtheta^2+mup/2*g*cos(theta);
    end
    if state(11)~=0 && state(11)~= pi
      FR     = kneetorqR/(-Lg*sin(state(8)/2)); 
    else
      FR   = mup/2*sin(theta)*r*(ddtheta+ddq(6))-mup/2*Llqr*dtheta^2+mup/2*g*cos(theta);
    end
    mddlL = FL-mup/2*g*cos(theta)+mup/2*Llqr*dtheta^2-mup/2*sin(theta)*r*(ddtheta+ddq(5));
    mddlR = FR-mup/2*g*cos(theta)+mup/2*Llqr*dtheta^2-mup/2*sin(theta)*r*(ddtheta+ddq(6));
    MfriL = (FL*cos(theta)+mw*g)*mur;
    MfriR = (FR*cos(theta)+mw*g)*mur;
    contorqL = MfriL+mddlL*sin(theta)*r+mup*r*dLlqr*dtheta*cos(theta);
    contorqR = MfriR+mddlR*sin(theta)*r+mup*r*dLlqr*dtheta*cos(theta);
    torqL = torq_lqr(1)+contorqL;
    torqR = torq_lqr(2)+contorqR;
 tau = [hiptorqL;hiptorqR;kneetorqL;kneetorqR;torqL;torqR];