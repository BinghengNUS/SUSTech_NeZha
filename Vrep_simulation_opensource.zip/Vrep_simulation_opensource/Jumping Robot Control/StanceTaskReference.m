function [ps_ref,dps_ref,ddps_ref] = StanceTaskReference(baseorientation,wb,dwb,psym,vref,bs_ref,dbs_ref,ddbs_ref)
%This function returns the reference for task-space in stance phase
%The relative position of wheel center w.r.t the base c.o.m is the negative
%value of base c.o.m height minus the wheel radius
%state=[x;y;z;roll;pitch;yaw;thetahl;thetakl;thetawl;thetahr;thetakr;thetawr]
%psym  = [r,d,g,Lg,Ltcom,Lscom,dh,dhs,mfb,mtl,msl,mw,mu];%system parameter vector
%*********************By Bingheng WANG, on Mar.16 2020*********************
    roll    = baseorientation(1);
    pitch   = baseorientation(2);
    yaw     = baseorientation(3);
    Rs2b    = Rzyx(roll,pitch,yaw);
    psddL   = Rs2b*bs_ref;%transfered to {b}
    ps_ref  = [psddL(1);psddL(3);0;psddL(1);psddL(3);0];%desired x, z position of wheel in {b} and wheel joint angle
    dpsdd   = -skew(wb)*Rs2b*bs_ref+Rs2b*dbs_ref;%desired velocity of wheel center in {b}
    dps_ref = [dpsdd(1);dpsdd(3);vref/psym(1);dpsdd(1);dpsdd(3);vref/psym(1)];
    ddpsdd  = -skew(dwb)*Rs2b*bs_ref+skew(wb)^2*Rs2b*bs_ref-2*skew(wb)*Rs2b*dbs_ref+Rs2b*ddbs_ref;%desired acceleration of wheel center in {b}
    ddps_ref= [ddpsdd(1);ddpsdd(3);0;ddpsdd(1);ddpsdd(3);0];
    