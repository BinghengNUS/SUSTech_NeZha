function [c,ceq]=nonlinearcon(x)
L0   = 0.7;
g    = 9.8;
zmax = 2;
r    = 0.1;
dh   = 0.0474;
ceq  = x(4)*cos(x(1))-L0*sin(x(1))*x(2)+sqrt(2*g*(zmax-r-(L0+dh)*cos(x(1))));
c  = [];