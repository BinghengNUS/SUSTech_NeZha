function [tau,contorqL,contorqR] = StanceJointTorquesQP2(Ats,Jc,dAts,dJc,state,dstate,ddxtsc,psym,torqueLimit,ddq,Llqr,dLlqr,theta,dtheta,ddtheta,torq_lqr) 
%This function returns the joint torques for the task-space control, which
%includes two hip joint torques, two knee joint torques and two wheel joint
%torques. All torques are obtained by quadratic programming based on a full
%dynamic model
%psym  = [r,d,g,Lg,Ltcom,Lscom,dh,dhs,mfb,mtl,msl,mw,mur,mus];%system parameter vector
%optimal varibales: sln 23by1,ddq 12by1, tau 6by1, constraint force 5by1
%*********************By Bingheng WANG, on Mar.8 2020*********************

    %---------------------------------------%
    %model in stance (excluding wheels)
    %---------------------------------------%
    %Rigid body modeling using Roy Featherstone package
    handle.NB = 5;
    handle.parent = [0 1 2 1 4];%left part first, then right part
    handle.jtype = {'Ry', 'Ry', 'Ry', 'Ry','Ry'};
    handle.Xtree{1} = eye(6);%from {s} to base frame {b} (at base c.o.m) 
    handle.Xtree{2} = xlt([0,0.0762,-psym(7)]);%Adjoint Matrix from {parent i} Link frame to {i}
    handle.Xtree{3} = xlt([0,0.0385,-psym(4)]);
    handle.Xtree{4} = xlt([0,-0.0762,-psym(7)]);%from {b} to hip joint frame {h}, expressed in {h}
    handle.Xtree{5} = xlt([0,-0.0385,-psym(4)]);
%     handle.Xtree{7} = xlt([0,0.0605,psym(4)]);
    mass = psym(9);%half of base
    CoM = [0,0,0];
    Icm =  diag([0.0261376195979353,0.0249232975683053,0.0143828822217345]);
    handle.I{1} = mcI( mass, CoM, Icm );
    mass = psym(10);%Thigh link
    CoM = [0,0.0637001804791891,psym(5)];
    Icm =  diag([0.0223883715246182,0.022309557436881,0.00172727939342223]);
    handle.I{2} = mcI( mass, CoM, Icm );
    mass = psym(11);%Shank link
    CoM = [0,0.0364494458894979,psym(6)];
    Icm = diag([0.0175958448813304,0.0177210394041728,0.000378821101531682]);
    handle.I{3} = mcI( mass, CoM, Icm );
%     mass = psym(12);%Wheel link
%     CoM = [0,0.013,0];
%     Icm = diag([0.00249269451196491,0.0049481769879587,0.00249269451196491]);
%     handle.I{4} = mcI( mass, CoM, Icm );
    mass = psym(10);%Thigh link
    CoM = [0,-0.0637001804791891,psym(5)];
    Icm =  diag([0.0223883715246182,0.022309557436881,0.00172727939342223]);
    handle.I{4} = mcI( mass, CoM, Icm );
    mass = psym(11);%Shank link
    CoM = [0,-0.036449445889498,psym(6)];
    Icm = diag([0.0175958448813304,0.0177210394041728,0.000378821101531682]);
    handle.I{5} = mcI( mass, CoM, Icm );
    states      = [state(1);state(2);state(3);state(4);state(5);state(6);state(7);state(8);state(10);state(11)];
    dstates     = [dstate(1);dstate(2);dstate(3);dstate(4);dstate(5);dstate(6);dstate(7);dstate(8);dstate(10);dstate(11)];
    handle_fb   = floatbase(handle);
    [Ms,Cs]     = HandC(handle_fb, states, dstates, []);   
    %---------------------------------%
    %Quadratic programming formulation
    %---------------------------------%
    Hs    = Ats.'*Ats;
    fs    = Ats.'*(dAts*dstates-ddxtsc);
    Hsqp  = blkdiag(Hs,zeros(9,9));
    fsqp  = [fs;zeros(9,1)];
    Ss    = [zeros(6,4);eye(4)];
    Aeqs  = [Ms,-Ss,-Jc.';
             Jc,zeros(5,9)];
    beqs  = [-Cs;
             -dJc*dstates];
    Hsqp  = double(Hsqp);
    fsqp  = double(fsqp);
    Aeqs  = double(Aeqs);
    beqs  = double(beqs);
    %limits of constraint forces
    fczmax  = torqueLimit(5)/psym(13);
    fcymax  = fczmax*psym(14);
    taucmax = 2*fcymax*psym(2);
    fcmin   = [0;0;-fcymax;-fcymax;-taucmax];
    fcmax   = [fczmax;fczmax;fcymax;fcymax;taucmax];
    %limits of control torques
    usmin   = -[torqueLimit(1);torqueLimit(3);torqueLimit(2);torqueLimit(4)];
    usmax   = [torqueLimit(1);torqueLimit(3);torqueLimit(2);torqueLimit(4)];
    %limits of optimal variables
    lb    = [-Inf(10,1);usmin;fcmin];
    ub    = [Inf(10,1);usmax;fcmax];
    [slns,optC] = quadprog(Hsqp,fsqp,[],[],Aeqs,beqs,lb,ub);%hip, knee, followed by right side
    hiptorqueL   = slns(11);
    kneetorqueL  = slns(12);
    hiptorqueR   = slns(13);
    kneetorqueR  = slns(14);
    r        = psym(1);
    g        = psym(3);
    Lg       = psym(4);
    mw       = psym(12);
    mup      = psym(9)+2*(psym(10)+psym(11));
    mur      = psym(13);
    if state(8)~=0 && state(8)~= pi
      FL     = kneetorqueL/(-Lg*sin(state(8)/2)); 
    else
      FL   = mup/2*sin(theta)*r*(ddtheta+ddq(5))-mup/2*Llqr*dtheta^2+mup/2*g*cos(theta);
    end
    if state(11)~=0 && state(11)~= pi
      FR     = kneetorqueR/(-Lg*sin(state(8)/2)); 
    else
      FR   = mup/2*sin(theta)*r*(ddtheta+ddq(6))-mup/2*Llqr*dtheta^2+mup/2*g*cos(theta);
    end
    mddlL = FL-mup/2*g*cos(theta)+mup/2*Llqr*dtheta^2;%-mup/2*sin(theta)*r*(ddtheta+ddq(5))
    mddlR = FR-mup/2*g*cos(theta)+mup/2*Llqr*dtheta^2;%-mup/2*sin(theta)*r*(ddtheta+ddq(6))
%     MfriL = (FL*cos(theta)+mw*g)*mur;
%     MfriR = (FR*cos(theta)+mw*g)*mur;
    kc    = 0.8;
    contorqL = kc*mddlL*sin(theta)*r;
    contorqR = kc*mddlR*sin(theta)*r;
    wheeltorqueL = torq_lqr(1)+contorqL;
    wheeltorqueR = torq_lqr(2)+contorqR;
    tau   = [hiptorqueL;hiptorqueR;kneetorqueL;kneetorqueR;wheeltorqueL;wheeltorqueR];

