function [ddxtscL,ddxtscR,ddxtfc] = StateMachine(ps_ref,dps_ref,ddps_ref,pf_ref,dpf_ref,ddpf_ref,zbL,zbR,dzbL,dzbR,pf,dpf,Kps,Kpf,Kds,Kdf)
%This function returns the dynamic commands in task-space, based on the
%reference and system task-space variables.
%Kps: proportional gain in stance phase
%Kpf: proportional gain in flight phase
%Kds: derivative gain in stance phase
%Kdf: derivative gain in flight phase
% all commands consist of a PD-based feedback control law and a feedforward
% term of desired acceleration

ddxtscL = ddps_ref+Kds*(dps_ref-dzbL)+Kps*(ps_ref-zbL);
ddxtscR = ddps_ref+Kds*(dps_ref-dzbR)+Kps*(ps_ref-zbR);
ddxtfc  = ddpf_ref+Kdf*(dpf_ref-dpf)+Kpf*(pf_ref-pf);