function [tau,contorqL,contorqR,FL,FR] = StanceJointTorquesQP4(Ats,dAts,AtFL,AtFR,state,dstate,ddxtsc,GsL,dGsL,GsR,dGsR,thetasL,dthetasL,thetasR,dthetasR,psym,torqueLimit,Llqr,theta,dtheta,torq_lqr) 
%This function returns the joint torques for the task-space control, which
%includes two hip joint torques, two knee joint torques and two wheel joint
%torques. All torques are obtained by quadratic programming based on a full
%dynamic model
%psym  = [r,d,g,Lg,Ltcom,Lscom,dh,dhs,mfb,mtl,msl,mw,mur,mus];%system parameter vector
%optimal varibales: sln 23by1,ddq 12by1, tau 6by1, constraint force 5by1
%*********************By Bingheng WANG, on Mar.8 2020*********************

    %---------------------------------------%
    %model in stance (full-model in sagittal plane)
    %---------------------------------------%
    r         = psym(1);
    mup       = psym(9)+2*(psym(10)+psym(11));
    g         = psym(3);
    handle.NB = 3;
    handle.parent = [0 1 2];%from the shank link to the floating base
    handle.jtype = {'Ry', 'Ry', 'Ry'};
    handle.Xtree{1} = eye(6);%from {s} to pendulum frame {p}  
    handle.Xtree{2} = xlt([0,0,psym(4)]);%Adjoint Matrix from {parent i} Link frame to {i}
    handle.Xtree{3} = xlt([0,0,psym(4)+psym(7)]);
    mass = psym(11);%Shank link{s}
    CoM = [0,0.0364494458894979,psym(4)+psym(6)];
    Icm = diag([0.0175958448813304,0.0177210394041728,0.000378821101531682]);
    handle.I{1} = mcI( mass, CoM, Icm );
    mass = psym(10);%Thigh link
    CoM = [0,0.0637001804791891,psym(4)+psym(5)];
    Icm =  diag([0.0223883715246182,0.022309557436881,0.00172727939342223]);
    handle.I{2} = mcI( mass, CoM, Icm );
    mass = 1/2*psym(9);%Base 
    CoM = [0,0,0];
    Icm =  diag(1/2*[0.0261376195979353,0.0249232975683053,0.0143828822217345]);
    handle.I{3} = mcI( mass, CoM, Icm );
    stateL  = [thetasL;-state(8);-state(7)];
    dstateL = [dthetasL;-dstate(8);-dstate(7)];
    [ML,CL]     = HandC(handle, stateL, dstateL, []);  
    dqiL  = [-dstate(8);-dstate(7)];
    MsL   = GsL.'*ML*GsL;
    CsL   = GsL.'*ML*dGsL*dqiL+GsL.'*CL;
    S     = [zeros(1,2);eye(2)];
    SsL   = GsL.'*S;
    stateR  = [thetasR;-state(11);-state(10)];
    dstateR = [dthetasR;-dstate(11);-dstate(10)];
    [MR,CR]     = HandC(handle, stateR, dstateR, []);  
    dqiR  = [-dstate(11);-dstate(10)];
    MsR   = GsR.'*MR*GsR;
    CsR   = GsR.'*MR*dGsR*dqiR+GsR.'*CR;
    S     = [zeros(1,2);eye(2)];
    SsR   = GsR.'*S;
    %---------------------------------%
    %Quadratic programming formulation
    %---------------------------------%
    Hs    = Ats.'*Ats;
    fsL   = Ats.'*(dAts*dqiL-[ddxtsc(1);ddxtsc(2)]);
    fsR   = Ats.'*(dAts*dqiR-[ddxtsc(3);ddxtsc(4)]);
    Hsqp  = blkdiag(Hs,zeros(2,2));
    fsqpL = [fsL;zeros(2,1)];
    fsqpR = [fsR;zeros(2,1)];
    AeqsL = [MsL,-SsL];
    AeqsR = [MsR,-SsR];
    beqsL = -CsL;
    beqsR = -CsR;
    Hsqp  = double(Hsqp);
    fsqpL = double(fsqpL);
    AeqsL = double(AeqsL);
    beqsL = double(beqsL);
    fsqpR = double(fsqpR);
    AeqsR = double(AeqsR);
    beqsR = double(beqsR);
    %limits of control torques
    usmin   = -[torqueLimit(3);torqueLimit(1)];
    usmax   = [torqueLimit(3);torqueLimit(1)];
    %limits of optimal variables
    lb    = [-Inf(2,1);usmin];
    ub    = [Inf(2,1);usmax];
    [slnsL,optC] = quadprog(Hsqp,fsqpL,[],[],AeqsL,beqsL,lb,ub);%hip, knee, followed by right side
    [slnsR,optC] = quadprog(Hsqp,fsqpR,[],[],AeqsR,beqsR,lb,ub);%hip, knee, followed by right side
    hiptorqueL  = slnsL(4);
    kneetorqueL = slnsL(3);
    hiptorqueR  = slnsR(4);
    kneetorqueR = slnsR(3);
    FL     = pinv(AtFL.')*[slnsL(3);slnsL(4)];
    FR     = pinv(AtFR.')*[slnsR(3);slnsR(4)];
    mddlL = FL-mup/2*g*cos(theta)+mup/2*Llqr*dtheta^2;
    mddlR = FR-mup/2*g*cos(theta)+mup/2*Llqr*dtheta^2;
    k     = 0.3;
    contorqL = k*mddlL*sin(theta)*r;
    contorqR = k*mddlR*sin(theta)*r;
    wheeltorqueL = torq_lqr(1)+contorqL;
    wheeltorqueR = torq_lqr(2)+contorqR;
    tau   = [-hiptorqueL;-hiptorqueR;-kneetorqueL;-kneetorqueR;wheeltorqueL;wheeltorqueR];

