function U_ref = feedforwardCtrl(Tpoly,alpha,beta,kp,psym)
g          = psym(3);
mb         = psym(9)+2*(psym(10));%total upper mass
mw         = 2*(psym(11)+psym(12));%mass of shank link and wheel
r          = psym(1);%radius of wheel
Lg         = psym(4);%length of leg (Thigh link and Shank link)
dh         = psym(7);%height of base c.o.m relative to the hip joint
[P0,P1,P2] = poly(Tpoly);
L_ref      = P0*alpha;
dL_ref     = P1*alpha;
ddL_ref    = P2*alpha;
th_ref     = P0*beta;
dth_ref    = P1*beta;
ddth_ref   = P2*beta;
    %spring stiffness
    L0       = 2*Lg+dh;
    thekmin  = -140/180*pi;
    thekmax  = -60/180*pi;
    Lmin     = -Lg*sin(thekmax/2);
    Lmax     = -Lg*sin(thekmin/2);
    Ksmax  = kp/(Lmin^2);
    Ksmin  = kp/(Lmax^2);
    Ks     = 1/2*(Ksmax+Ksmin);
%feedforward control based on reference
M_rs       = [mb,0;
              r*mb*sin(th_ref),mb*L_ref^2+r*mb*cos(th_ref)*L_ref];
C_rs       = [-mb*L_ref*dth_ref^2+mb*g*cos(th_ref)-Ks*(L0-L_ref);
             (2*mb*L_ref+2*r*mb*cos(th_ref))*dL_ref*dth_ref-mb*g*L_ref*sin(th_ref)-2*mb*r*sin(th_ref)*L_ref*dth_ref^2];
S_rs       = [-mb*sin(th_ref),Ks;
              -mb*L_ref*cos(th_ref)-r*(mb+mw),0];
ddx_rs     = [ddL_ref;ddth_ref];
U_ff       = S_rs^(-1)*(M_rs*ddx_rs+C_rs);
ddx_ref    = U_ff(1);
uL_ref     = U_ff(2);
F_ref      = (mb+mw)*ddx_ref+mb*L_ref*cos(th_ref)*ddth_ref+mb*ddL_ref*sin(th_ref)...
           +2*mb*cos(th_ref)*dL_ref*dth_ref-mb*sin(th_ref)*L_ref*dth_ref^2;
U_ref      = [F_ref;uL_ref];