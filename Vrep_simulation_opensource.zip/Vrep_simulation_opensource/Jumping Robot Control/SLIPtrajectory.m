function [ps_ref,dps_ref,ddps_ref] = SLIPtrajectory(psym,state,dstate,flagjump) 
%This function returns the reference for task-space. In stance phase, the
%reference is for the base c.o.m. The reference of base c.o.m is optimized by a
%one-dimensional SLIP model online using quadratic programming. The wheel
%center reference is temporarily constant in {s}
%state=[x;y;z;roll;pitch;yaw;thetahl;thetakl;thetawl;thetahr;thetakr;thetawr]
%shanktilt=[theta0l;theta0r]
%psym  = [r,d,g,Lg,Ltcom,Lscom,dh,dhs,mfb,mtl,msl,mw,mur,mus];%system parameter vector
%*********************By Bingheng WANG, on Mar.8 2020*********************
    
%--------------------------------------------%
%Base c.o.m trajecotory based on a SLIP model
%--------------------------------------------%
%------------------%
%Parameters Setting
%------------------%
    g    = psym(3);
    m    = psym(8)+2*(psym(10)+psym(11)+psym(12));%total mass
    kp   = 100;%proportional coefficient of knee torque
    dt   = 0.001;%sampling time
    r    = psym(1);%radius of wheel
    Lg   = psym(4);%length of leg (Thigh link and Shank link)
    dh   = psym(7);%height of base c.o.m relative to the hip joint
%---------------------------------------%
%Initial States and Desired Final States
%---------------------------------------%
    L0   = 2*Lg;%initial resting length of the spring excluding r and dh
    z0   = state(3);%initial actual length of the spring including r and dh
    dz0  = dstate(3);%initial velocity of actual length
    Tf   = 0.8;%final time
    L0   = double(L0);
    r    = double(r);
    dh   = double(dh);
    z0   = double(z0);
    dt   = double(dt);
    dz0  = double(dz0);
%calculate the desired final height and velocity
    if flagjump==0%no jump
        zdes = 2.3;%desired peak in flight,2.4
        zf   = z0;%final height
        dzf  = sqrt((zdes-zf)*2*g);%final velocity
    else%landing
        zf   = z0;
        dzf  = 0;
    end
    
%-------------------%
%Constraints Setting
%-------------------%
    Lmin = 0.2;
    Lmax = 2*Lg;
    Ksmax= 4*kp/(Lmin^2);
    Ksmin= 4*kp/(Lmax^2);
    zmin = Lmin+r+dh;
    zmax = z0;
    Z_L  = zmin*ones(1,Tf/dt);%lower bound vector
    Z_U  = zmax*ones(1,Tf/dt);%upper bound vector
    dzmin= -4;
    dzmax= 2*dzf;
    dZ_L = dzmin*ones(1,Tf/dt);
    dZ_U = dzmax*ones(1,Tf/dt);
    Ks   = 1/2*(Ksmax+Ksmin);%spring constant stiffness
    umax = (L0+r-zmin)*(Ksmax-Ks)/Ks;
    umin = (L0+r-zmin)*(Ksmin-Ks)/Ks;
    U_L  = umin*ones(1,Tf/dt);
    U_U  = umax*ones(1,Tf/dt);
    cvx_begin
        variable u(1,Tf/dt);%Stiffness
    %------Initialization------%
        z   = z0;
        dz  = dz0;
        i   = 1;
        ps_ref   = cvx(zeros(1,Tf/dt));
        dps_ref  = cvx(zeros(1,Tf/dt));
        ddps_ref = cvx(zeros(1,Tf/dt));

    %------Iteration of Dynamic Model------%
    for t=dt:dt:Tf
        s       = L0+r+u(i)+dh-z;%spring deformation
        Fs      = Ks*s;%spring force 
        ddz     = Fs/m-g;
        %-----update-----%
        dz      = dz+dt*ddz;
        z       = z+dt*dz;
        ps_ref(1,i)  = z;
        dps_ref(1,i) = dz;
        ddps_ref(1,i)= ddz;
        i       = i+1;
    end
        J  =  1/2*[z-zf,dz-dzf]*[z-zf;dz-dzf];%final cost only, no running cost
        minimize(J)
        subject to
    %-----State Constraint-----%
        ps_ref <= Z_U;
        ps_ref >= Z_L;
        dps_ref<= dZ_U;
        dps_ref>= dZ_L;
    %-----Control Constraint-----%
        u <= U_U;
        u >= U_L;
    cvx_end
%     ps_ref   = 0.85;%relative position in {s}
%     dps_ref  = 0;
%     ddps_ref = 0;