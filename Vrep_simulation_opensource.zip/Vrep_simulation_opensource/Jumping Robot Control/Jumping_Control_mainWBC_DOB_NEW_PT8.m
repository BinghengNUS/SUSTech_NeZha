%*************************************************************************
%         Balance and Jumping Control for a Wheeled Bipedal Robot
%*********************By Bingheng WANG, May.07,2020***********************
%% Configuration codes
% Control inputs: two hip joint torques, two knee joint torques, two wheel
% joint torques.
% Control objective: In stance phase: make the c.o.m of base track the
% trajectory optimized online by the SLIP model; In flight phase, make the
% foot track the desired trajectories manually designed offline.
% Methdology: the control is achieved by task-space quadratic programming
% {s}: inertial frame
% {b}: body frame fixed on the floating base
% {f}: body frame fixed on the foot
clear all

jointNum=6;
torqueLimit=[60;60;60;60;10;10];
jointName=["LeftHip_joint","RightHip_joint","LeftKnee_joint","RightKnee_joint","LeftWheel_joint","RightWheel_joint"];  

displayOn=true;
torque=zeros(jointNum,1); 

%% Connect to the Vrep
% 1. load api library
vrep=remApi('remoteApi'); % using the prototype file (remoteApiProto.m)
% 2. close all the potential link
vrep.simxFinish(-1);   
% 3. wait for connecting vrep, detect every 0.2s
while true
    clientID=vrep.simxStart('127.0.0.1',19997,true,true,5000,5);
    if clientID>-1 
        break;
    else
        pause(0.002);
        disp('please run the simulation on vrep...')
    end
end
disp('Connection success!')
% 4. set the simulation time step
tstep = 0.002;  % 1ms per simulation pass
vrep.simxSetFloatingParameter(clientID,vrep.sim_floatparam_simulation_time_step,tstep,vrep.simx_opmode_oneshot);
% 5. open the synchronous mode to control the objects in vrep
vrep.simxSynchronous(clientID,true);

%% Simulation Initialization
vrep.simxStartSimulation(clientID,vrep.simx_opmode_oneshot);
% get the handles
jointHandle=zeros(jointNum,1); 
for i=1:jointNum  % handles of the left and right arms
    [~,returnHandle]=vrep.simxGetObjectHandle(clientID,char(jointName(i)),vrep.simx_opmode_blocking);
    jointHandle(i)=returnHandle;
end
% set the target velocity to 0.1 and torque to 0
for i=1:jointNum
    vrep.simxSetJointForce(clientID,jointHandle(i),0,vrep.simx_opmode_oneshot);
    vrep.simxSetJointTargetVelocity(clientID,jointHandle(i),0.1,vrep.simx_opmode_oneshot);
end
baseName='Body_link_visual';
wheelName='RightWheel_link_visual';
wheelleft='LeftWheel_link_visual';
Shankleft='LeftShank_link_visual';
Shankright='RightShank_link_visual';
LeftHip='LeftHip_joint';
RightHip='RightHip_joint';
[~,baseHandle]=vrep.simxGetObjectHandle(clientID,baseName,vrep.simx_opmode_blocking);  
[~,wheelHandle]=vrep.simxGetObjectHandle(clientID,wheelName,vrep.simx_opmode_blocking);  
[~,wheelleftHandle]=vrep.simxGetObjectHandle(clientID,wheelleft,vrep.simx_opmode_blocking);  
[~,ShankleftHandle]=vrep.simxGetObjectHandle(clientID,Shankleft,vrep.simx_opmode_blocking);  
[~,ShankrightHandle]=vrep.simxGetObjectHandle(clientID,Shankright,vrep.simx_opmode_blocking);  
[~,LeftHipHandle]=vrep.simxGetObjectHandle(clientID,LeftHip,vrep.simx_opmode_blocking);  
[~,RightHipHandle]=vrep.simxGetObjectHandle(clientID,RightHip,vrep.simx_opmode_blocking);  
vrep.simxSynchronousTrigger(clientID);
disp('Handles available!')
% first call to read the joints' configuration and end-effector pose, the mode is chosen to be simx_opmode_streaming
jointConfig=zeros(jointNum,1);  
JointTorque=zeros(jointNum,1);
% get current joint position
for i=1:jointNum
    [~,jpos]=vrep.simxGetJointPosition(clientID,jointHandle(i),vrep.simx_opmode_streaming); 
        jointConfig(i)=jpos;
        [~,jtorq]=vrep.simxGetJointForce(clientID,jointHandle(i),vrep.simx_opmode_streaming); 
        JointTorque(i)=jtorq;  
end

% get simulation time
currCmdTime=vrep.simxGetLastCmdTime(clientID);

lastCmdTime=currCmdTime;
% [~,pingTime]=vrep.simxGetPingTime(clientID);
% jointConfig0=jointConfig;
% jointConfigLast=zeros(jointNum,1);
% jointConfigLast=jointConfig+[0;0;0;0;43.9823;43.9823;0;0];;
[~,baseposition0]=vrep.simxGetObjectPosition(clientID,baseHandle,-1,vrep.simx_opmode_streaming);% defined in inertial frame
[~,basevelocity0]=vrep.simxGetObjectVelocity(clientID,baseHandle,vrep.simx_opmode_streaming);
[~,wheelposition0]=vrep.simxGetObjectPosition(clientID,wheelHandle,-1,vrep.simx_opmode_streaming);
[~,wheelvelocity0]=vrep.simxGetObjectVelocity(clientID,wheelHandle,vrep.simx_opmode_streaming);
[~,wheelleftposition0]=vrep.simxGetObjectPosition(clientID,wheelleftHandle,-1,vrep.simx_opmode_streaming); 
[~,wheelleftvelocity0]=vrep.simxGetObjectVelocity(clientID,wheelleftHandle,vrep.simx_opmode_streaming); 
[~,Shankleftposition0]=vrep.simxGetObjectPosition(clientID,ShankleftHandle,-1,vrep.simx_opmode_streaming);  
[~,Shankrightposition0]=vrep.simxGetObjectPosition(clientID,ShankrightHandle,-1,vrep.simx_opmode_streaming);  
[~,baseorientation0]=vrep.simxGetObjectOrientation(clientID,baseHandle,-1,vrep.simx_opmode_streaming);% defined in inertial frame
[~,LeftHipposition0]=vrep.simxGetObjectPosition(clientID,LeftHipHandle,-1,vrep.simx_opmode_streaming);  
 pause(0.1)
 for i=1:jointNum
    [~,jpos]=vrep.simxGetJointPosition(clientID,jointHandle(i),vrep.simx_opmode_streaming); 
        jointConfig(i)=jpos;
         [~,jtorq]=vrep.simxGetJointForce(clientID,jointHandle(i),vrep.simx_opmode_streaming); 
        JointTorque(i)=jtorq;
end
[~,baseposition0]=vrep.simxGetObjectPosition(clientID,baseHandle,-1,vrep.simx_opmode_buffer);% defined in inertial frame
[~,basevelocity0]=vrep.simxGetObjectVelocity(clientID,baseHandle,vrep.simx_opmode_buffer);
[~,wheelposition0]=vrep.simxGetObjectPosition(clientID,wheelHandle,-1,vrep.simx_opmode_buffer);
[~,wheelvelocity0]=vrep.simxGetObjectVelocity(clientID,wheelHandle,vrep.simx_opmode_buffer);
[~,wheelleftposition0]=vrep.simxGetObjectPosition(clientID,wheelleftHandle,-1,vrep.simx_opmode_buffer);
[~,wheelleftvelocity0]=vrep.simxGetObjectVelocity(clientID,wheelleftHandle,vrep.simx_opmode_buffer);
[~,Shankleftposition0]=vrep.simxGetObjectPosition(clientID,ShankleftHandle,-1,vrep.simx_opmode_buffer);  
[~,Shankrightposition0]=vrep.simxGetObjectPosition(clientID,ShankrightHandle,-1,vrep.simx_opmode_buffer);  
[~,baseorientation0]=vrep.simxGetObjectOrientation(clientID,baseHandle,-1,vrep.simx_opmode_streaming);% defined in inertial frame
[~,LeftHipposition0]=vrep.simxGetObjectPosition(clientID,LeftHipHandle,-1,vrep.simx_opmode_streaming);  
% jointConfig=jointConfig;%+[0;0;0;0;43.9823;43.9823;0;0];
%-----------------%
%System Parameters
%-----------------%
r     = 0.1;%radius of wheel
d     = 0.175;%distance from the wheel to the center of body
g     = 9.8;
Lg    = 0.429;%length of Thighlink
Ltcom = -0.05;%z position of Thigh_link C.O.M in link frame
Lscom = -0.35;%z position of Shank_link C.O.M in link frame
dh    = 0.0474+0.02;% height of C.O.M of the main body relative to the hip joint
dhs   = 0;%-2.003e-02;%height of C.O.M of the main body in shape frame of bounding box
mfb   = 5.5;%mass of the floating base
mtl   = 2;%mass of the thigh leg
msl   = 1.05;%mass of the shank leg
mw    = 0.55;%mass of the wheel
m     = mfb+2*mtl;
mb    = 2*(msl+mw);%mass of shank link and wheel
kL    = m/(m+mb);
psym  = [r,d,g,Lg,Ltcom,Lscom,dh,dhs,mfb,mtl,msl,mw];%system parameter vector
%--------------%
%Initial states
%--------------%
jointLAST = jointConfig;
dqLast    = zeros(6,1);
rollb0    = baseorientation0(1);
pitchb0   = baseorientation0(2);
yawb0     = baseorientation0(3);
Rs2b0     = Rzyx(rollb0,pitchb0,yawb0);
bposition0= baseposition0.'+Rs2b0.'*[6.285e-03;2.496e-07;dhs];
state0 = [bposition0;baseorientation0.';jointLAST(1);jointLAST(3);jointLAST(5);jointLAST(2);jointLAST(4);jointLAST(6)];
dstate0= zeros(12,1);
bpositionLast    = bposition0;
orientationLast  = baseorientation0.';
deulerLast       = zeros(3,1);
wbLast           = zeros(3,1);
deltawheel0      = wheelposition0-wheelleftposition0;
yaw0 = atan(deltawheel0(1)/deltawheel0(2));% yaw angle of the whole robot
deltaposition0 = bposition0-wheelposition0.'; % relative position between base and left wheel in {S}
deltap_b0      = Rotzs2b(yaw0)*deltaposition0;
theta0         = atan(deltap_b0(1)/(deltap_b0(3)));%pitch angle of pendulum
dtheta0        = 0;
deltap_b0 = Rotzs2b(yaw0)*deltaposition0;
LlqrLast  = sqrt((deltap_b0(1))^2+(deltap_b0(3))^2);%pendulum length
thetaLast = atan(deltap_b0(1)/(deltap_b0(3)));
dthetaLast= 0;
dyaw0     = 0;
positionswleft0 =Shankleftposition0-wheelleftposition0;
positionswright0=Shankrightposition0-wheelposition0;
wheelLx0         = wheelleftposition0(1);
wheelLy0         = wheelleftposition0(2);
wheelRx0         = wheelposition0(1);
wheelRy0         = wheelposition0(2);
wheelRz0         = wheelposition0(3);
wheelLxLast      = wheelLx0;
wheelLyLast      = wheelLy0;
wheelRxLast      = wheelRx0;
wheelRyLast      = wheelRy0;
wheelzpositionLast = wheelRz0;
pwleft0_b = Rotzs2b(yaw0)*positionswleft0.';
pwright0_b= Rotzs2b(yaw0)*positionswright0.';
yawLast   = yaw0;
theta0l0    = atan(pwleft0_b(1)/pwleft0_b(3));%tilting angle of Shankleft
theta0r0    = atan(pwright0_b(1)/pwright0_b(3));%tilting angle of Shankright
theta0lLast = theta0l0;
theta0rLast = theta0r0;
shanktilt0  = [theta0lLast;theta0rLast];
dtheta0lLast= 0;
dtheta0rLast= 0;
dshanktilt0 = [dtheta0lLast;dtheta0rLast];
thetas0     = theta0l0-theta0;%tilting angle of {s} w.r.t {p}
vLast       = 0;
[Ats0,ps,dps,Atf0,pf,dpf] = TaskSpacePD2(state0,dstate0,psym);
AtsLast     = Ats0;
AtfLast     = Atf0;
vrep.simxSynchronousTrigger(clientID);         % every calls this function, verp is triggered, 50ms by default

%% Simulation Start
t=0;  % start the simulation
k=1;
kfly     = 1;
kstance  = 1;
kLanding = 1;
kt       = 0.97;%time scaling
kjt      = 1;
H_ob     = 0.5;
Lds      = 0.72;%desired length between wheel center and base CoM
L0       = 2*Lg+dh;
LTO      = Lds+dh;
Tstable  = 6;
theta_LO = 18/180*pi;%desired landing attitude
zmax     = 1;%kL*(Lds+dh)+H_ob+r;%maximum height of jump of system CoM
tr       = sqrt(2*(zmax-r-kL*LTO*cos(theta_LO))/g);%rising time
td       = sqrt(2*(zmax-r-kL*LTO)/g);%descending time
Tf       = tr+td;%flight time
theta_TD   = 0/180*pi;
dtheta_LO  = (theta_TD-theta_LO)/Tf;
f_plan     = 25;%frequency of planning 
f_planland = 25;%25;
f_planfly  = 1;
kj         = 0;
%Parameters for LQR
Q        = diag([1,1,1,1]);
R        = diag([0.2,0.2]);%0.2
vd       = 1;
dyaw_ref = 0;

%Parameters of state machine
  %stance phase
  kpx    = 120;%500
  kpz    = 120;%500
  Kps    = diag([kpx,kpz,kpx,kpz]);
  kdx    = 75;%280,300
  kdz    = 75;%280,350
  Kds    = diag([kdx,kdz,kdx,kdz]);
  %flight phase 
  kpx    = 100;%300,unstable oscillation is caused by small damping coefficients
  kpz    = 100;
  kpw    = 0;%no control for wheel joint angle
  Kpf    = diag([kpx,kpz,kpw,kpx,kpz,kpw]);
  kdx    = 50;%210
  kdz    = 50;
  kdw    = 15;
  Kdf    = diag([kdx,kdz,kdw,kdx,kdz,kdw]);
%spring stiffness
thekmin  = -140/180*pi;
thekmax  = -60/180*pi;
Lmin     = Lg*cos(thekmax/2);
Lmax     = Lg*cos(thekmin/2);
kp       = 30;%50
kpn      = 30;
Ksmax    = kp/(Lmin^2);
Ksmin    = kp/(Lmax^2);
Ks       = 1/2*(Ksmax+Ksmin);
Ts       = 2*pi*sqrt(m/Ks);%estimate of the spring period
%Parameters of disturbance observer
  K1j    = [115;55;115;55];%[145;65;145;65]
  K2j    = [5.0;7.0;5.0;7.0];%[5.0;7.0;5.0;7.0]
  K1w    = [15;50;15];%[15;50;15]
  K2w    = [2;2;2];%[2;2;2]
flagjump = 0;%no jump, 1 for a jump that already happened
flagland = 0;%no landing 
z_joint  = [dstate0(7);dstate0(8);dstate0(10);dstate0(11)];
z_wip    = [vLast;dyaw0;dtheta0];
tanh_joint = zeros(4,1);
tanh_wip   = zeros(3,1);
klandplan  = 1;
kjumpplan  = 1;
%time setting for trajectory polynomial
dt     = 0.002;
betadx = velocityRef(dt,Tstable,Lds,dh);
T_ploy = 0;
while (vrep.simxGetConnectionId(clientID) ~= -1)  % vrep connection is still active
    % time update
%   vrep.simxSetJointPosition(clientID,LeftHipHandle,tbased,vrep.simx_opmode_oneshot);
%   vrep.simxSetJointPosition(clientID,RightHipHandle,tbased,vrep.simx_opmode_oneshot);
    currCmdTime=vrep.simxGetLastCmdTime(clientID);
    dt=(currCmdTime-lastCmdTime)/1000;              % simulation step, unit: s 
    % read the joints' and tips' configuration (position and velocity)
%     [~,pingTime]=vrep.simxGetPingTime(clientID);
%     Delay(k)=pingTime;
    pause(0.002);
    for i=1:jointNum
        [~,jpos]=vrep.simxGetJointPosition(clientID,jointHandle(i),vrep.simx_opmode_buffer);     
               jointConfig(i)=jpos;
               [~,jpos]=vrep.simxGetJointPosition(clientID,jointHandle(i),vrep.simx_opmode_buffer);     
               jointConfig(i)=jpos;
               [~,jpos]=vrep.simxGetJointPosition(clientID,jointHandle(i),vrep.simx_opmode_buffer);     
               jointConfig(i)=jpos;
               [~,jpos]=vrep.simxGetJointPosition(clientID,jointHandle(i),vrep.simx_opmode_buffer);     
               jointConfig(i)=jpos;
              
               [~,jtorq]=vrep.simxGetJointForce(clientID,jointHandle(i),vrep.simx_opmode_streaming); 
               JointTorque(i)=jtorq;
    end
    %---------------------------%
    %System variables processing
    %---------------------------%
    gapl  = jointLAST(5)-jointConfig(5);
    gapr  = jointLAST(6)-jointConfig(6);
    if gapl<=-42
        Gapl=0;
    else
        Gapl=gapl;
    end
    if gapr<=-42
        Gapr=0;
    else
        Gapr=gapr;
    end
    
    if Gapl>=6 %remove the gap between two wheel angles, moving forward
        jointConfig(5)=jointConfig(5)+round(abs(Gapl)/(2*pi))*2*pi;
    end
    if Gapr>=6
        jointConfig(6)=jointConfig(6)+round(abs(Gapr)/(2*pi))*2*pi;
    end
    if Gapl<=-6 %remove the gap between two wheel angles, moving backward
        jointConfig(5)=jointConfig(5)-round(abs(Gapl)/(2*pi))*2*pi;
    end
    if Gapr<=-6
        jointConfig(6)=jointConfig(6)-round(abs(Gapr)/(2*pi))*2*pi;
    end
    Jointangle(:,k)=jointConfig;
    JointTORQUE(:,k)=JointTorque;
    q=jointConfig;
    dQ=(q-jointLAST)./dt;  % column vector
    if k==1
        dq=zeros(jointNum,1);
    else
       if norm(dQ(1),2)>=2e2%avoid dQ being very large
        dq=zeros(jointNum,1);
       else
        dq=dQ;
       end 
    end
    
    Qdot(:,k)=dq;
    ddq = (dq-dqLast)/dt;%acceleration of joint variables
%     jointConfig=jointConfig;%+[0;0;0;0;43.9823;43.9823;0;0];
    [~,baseposition]=vrep.simxGetObjectPosition(clientID,baseHandle,-1,vrep.simx_opmode_buffer);% defined in inertial frame
    [~,basevelocity]=vrep.simxGetObjectVelocity(clientID,baseHandle,vrep.simx_opmode_buffer);
    [~,wheelposition]=vrep.simxGetObjectPosition(clientID,wheelHandle,-1,vrep.simx_opmode_buffer);%right wheel
    [~,wheelvelocity]=vrep.simxGetObjectVelocity(clientID,wheelHandle,vrep.simx_opmode_buffer);
    [~,wheelleftposition]=vrep.simxGetObjectPosition(clientID,wheelleftHandle,-1,vrep.simx_opmode_buffer); 
    [~,wheelleftvelocity]=vrep.simxGetObjectVelocity(clientID,wheelleftHandle,vrep.simx_opmode_buffer);
    [~,Shankleftposition]=vrep.simxGetObjectPosition(clientID,ShankleftHandle,-1,vrep.simx_opmode_buffer);  
    [~,Shankrightposition]=vrep.simxGetObjectPosition(clientID,ShankrightHandle,-1,vrep.simx_opmode_buffer);  
    [~,baseorientation]=vrep.simxGetObjectOrientation(clientID,baseHandle,-1,vrep.simx_opmode_streaming);% defined in inertial frame
    [~,LeftHipposition]=vrep.simxGetObjectPosition(clientID,LeftHipHandle,-1,vrep.simx_opmode_streaming);  
    [~,RightHipposition]=vrep.simxGetObjectPosition(clientID,RightHipHandle,-1,vrep.simx_opmode_streaming);
    
     [~,baseposition]=vrep.simxGetObjectPosition(clientID,baseHandle,-1,vrep.simx_opmode_buffer);% defined in inertial frame
    [~,basevelocity]=vrep.simxGetObjectVelocity(clientID,baseHandle,vrep.simx_opmode_buffer);
    [~,wheelposition]=vrep.simxGetObjectPosition(clientID,wheelHandle,-1,vrep.simx_opmode_buffer);%right wheel
    [~,wheelvelocity]=vrep.simxGetObjectVelocity(clientID,wheelHandle,vrep.simx_opmode_buffer);
    [~,wheelleftposition]=vrep.simxGetObjectPosition(clientID,wheelleftHandle,-1,vrep.simx_opmode_buffer); 
    [~,wheelleftvelocity]=vrep.simxGetObjectVelocity(clientID,wheelleftHandle,vrep.simx_opmode_buffer);
    [~,Shankleftposition]=vrep.simxGetObjectPosition(clientID,ShankleftHandle,-1,vrep.simx_opmode_buffer);  
    [~,Shankrightposition]=vrep.simxGetObjectPosition(clientID,ShankrightHandle,-1,vrep.simx_opmode_buffer);  
    [~,baseorientation]=vrep.simxGetObjectOrientation(clientID,baseHandle,-1,vrep.simx_opmode_streaming);% defined in inertial frame
    [~,LeftHipposition]=vrep.simxGetObjectPosition(clientID,LeftHipHandle,-1,vrep.simx_opmode_streaming);  
    [~,RightHipposition]=vrep.simxGetObjectPosition(clientID,RightHipHandle,-1,vrep.simx_opmode_streaming);
    
     [~,baseposition]=vrep.simxGetObjectPosition(clientID,baseHandle,-1,vrep.simx_opmode_buffer);% defined in inertial frame
    [~,basevelocity]=vrep.simxGetObjectVelocity(clientID,baseHandle,vrep.simx_opmode_buffer);
    [~,wheelposition]=vrep.simxGetObjectPosition(clientID,wheelHandle,-1,vrep.simx_opmode_buffer);%right wheel
    [~,wheelvelocity]=vrep.simxGetObjectVelocity(clientID,wheelHandle,vrep.simx_opmode_buffer);
    [~,wheelleftposition]=vrep.simxGetObjectPosition(clientID,wheelleftHandle,-1,vrep.simx_opmode_buffer); 
    [~,wheelleftvelocity]=vrep.simxGetObjectVelocity(clientID,wheelleftHandle,vrep.simx_opmode_buffer);
    [~,Shankleftposition]=vrep.simxGetObjectPosition(clientID,ShankleftHandle,-1,vrep.simx_opmode_buffer);  
    [~,Shankrightposition]=vrep.simxGetObjectPosition(clientID,ShankrightHandle,-1,vrep.simx_opmode_buffer);  
    [~,baseorientation]=vrep.simxGetObjectOrientation(clientID,baseHandle,-1,vrep.simx_opmode_streaming);% defined in inertial frame
    [~,LeftHipposition]=vrep.simxGetObjectPosition(clientID,LeftHipHandle,-1,vrep.simx_opmode_streaming);  
    [~,RightHipposition]=vrep.simxGetObjectPosition(clientID,RightHipHandle,-1,vrep.simx_opmode_streaming);
    
     [~,baseposition]=vrep.simxGetObjectPosition(clientID,baseHandle,-1,vrep.simx_opmode_buffer);% defined in inertial frame
    [~,basevelocity]=vrep.simxGetObjectVelocity(clientID,baseHandle,vrep.simx_opmode_buffer);
    [~,wheelposition]=vrep.simxGetObjectPosition(clientID,wheelHandle,-1,vrep.simx_opmode_buffer);%right wheel
    [~,wheelvelocity]=vrep.simxGetObjectVelocity(clientID,wheelHandle,vrep.simx_opmode_buffer);
    [~,wheelleftposition]=vrep.simxGetObjectPosition(clientID,wheelleftHandle,-1,vrep.simx_opmode_buffer); 
    [~,wheelleftvelocity]=vrep.simxGetObjectVelocity(clientID,wheelleftHandle,vrep.simx_opmode_buffer);
    [~,Shankleftposition]=vrep.simxGetObjectPosition(clientID,ShankleftHandle,-1,vrep.simx_opmode_buffer);  
    [~,Shankrightposition]=vrep.simxGetObjectPosition(clientID,ShankrightHandle,-1,vrep.simx_opmode_buffer);  
    [~,baseorientation]=vrep.simxGetObjectOrientation(clientID,baseHandle,-1,vrep.simx_opmode_streaming);% defined in inertial frame
    [~,LeftHipposition]=vrep.simxGetObjectPosition(clientID,LeftHipHandle,-1,vrep.simx_opmode_streaming);  
    [~,RightHipposition]=vrep.simxGetObjectPosition(clientID,RightHipHandle,-1,vrep.simx_opmode_streaming);
   
    
    
    rollb     = baseorientation(1);
    pitchb    = baseorientation(2);
    yawb      = baseorientation(3);
    Rs2b      = Rzyx(rollb,pitchb,yawb);
    bposition = baseposition.'+Rs2b.'*[0;0;dhs];
    BaseX(k)  = bposition(1);
    BaseZ(k)  = bposition(3);
    state     = [bposition;baseorientation.';q(1);q(3);q(5);q(2);q(4);q(6)];
    vbase     = [basevelocity(1);basevelocity(2);basevelocity(3)];%(bposition-bpositionLast)./dt;
    dEuler    = (baseorientation.'-orientationLast)./dt;
    if k==1
        deuler=zeros(3,1);
    else
        deuler=dEuler;
    end
    ddeuler   = (deuler-deulerLast)./dt;
    dstate    = [vbase;deuler;dq(1);dq(3);dq(5);dq(2);dq(4);dq(6)];
    deltawheel= wheelposition-wheelleftposition;
%     yaw       = atan(deltawheel(1)/deltawheel(2));% yaw angle of the whole robot
    yaw       = psym(1)*(q(6)-q(5))/(2*psym(2));
    Yaw(k)    = yaw;
%     dyaw      = (yaw-yawLast)./dt;

    % attitude of the base 
    Orientation(:,k)=[baseorientation(1);baseorientation(2);baseorientation(3)];
    % tilt angle of the pendulum
    Wheelzposition(k)    = wheelposition(3);
    WheelZ               = wheelposition(3);
%     figure(1)
%     plot(0,0);
%     text(0,0,num2str(WheelZ))
%     axis off
    wheelzposition       = wheelposition(3);
    Wheelzleftposition(k)= wheelleftposition(3);
    deltaposition  = bposition-wheelposition.'; % position of pendulum relative to the wheel
    deltap_b       = Rotzs2b(yaw)*deltaposition;
    Llqr           = sqrt((deltap_b(1))^2+(deltap_b(3))^2);%length of the pendulum
    LLqr(k)        = Llqr;
    vzb            = vbase(3);
    vxb            = vbase(1);
    theta          = atan(deltap_b(1)/(deltap_b(3)));
    Tiltangle(k)   = theta;
    
    vzw            = wheelvelocity(3);%(wheelzposition-wheelzpositionLast)./dt;
    wheelLx        = wheelleftposition(1);
    wheelLy        = wheelleftposition(2);
    wheelRx        = wheelposition(1);
    WheelRX(k)     = wheelRx;
    wheelRy        = wheelposition(2);
    vwLx           = wheelleftvelocity(1);%(wheelLx-wheelLxLast)./dt;
    vwLy           = wheelleftvelocity(2);%(wheelLy-wheelLyLast)./dt;
    vwRx           = wheelvelocity(1);%(wheelRx-wheelRxLast)./dt;
    vwRy           = wheelvelocity(2);%(wheelRy-wheelRyLast)./dt;
    v              = (vwLx*cos(yaw)+vwLy*sin(yaw)+vwRx*cos(yaw)+vwRy*sin(yaw))/2;
    Vzw(k)         = vzw;
    Mv             = [sin(theta),cos(theta);
                      cos(theta)/Llqr,-sin(theta)/Llqr];
    if wheelzposition<=0.102 && wheelzpositionLast<=0.102
        dstatep    = Mv^(-1)*[vxb-v;
                              vzb];
    else
        dstatep    = Mv^(-1)*[vxb-v;
                              vzb-vzw];
    end
    dLlqr          = dstatep(1);% length velocity of pendulum
    DLLqr(k)       = dLlqr;
    dtheta         = dstatep(2);
    Dtheta(k)      = dtheta;
    ddtheta        = (dtheta-dthetaLast)/dt;
    dv             = (v-vLast)/dt;
    dyaw           = r*(dq(6)-dq(5))/(2*d);%+dtheta0R-dtheta0L
    Vfw(k) = v;
    
    
    %----------------------%
    %Task-space formulation
    %----------------------%
    [Ats,ps,dps,Atf,pf,dpf] = TaskSpacePD2(state,dstate,psym);
    dAts   = (Ats-AtsLast)./dt;
    dAtf   = (Atf-AtfLast)./dt;
    
    %--------------%
    %Task reference
    %--------------%
    drollb  = deuler(1);
    dpitchb = deuler(2);
    [T_e2w,dT_e2w] = Te2w(rollb,pitchb,drollb,dpitchb);
    wb     = T_e2w*deuler;%angular velocity of base in {b}
    dwb    = dT_e2w*deuler+T_e2w*ddeuler;
    dx        = 2*mtl*Ltcom*sin((q(1)+q(2))/2)/(2*mtl+mfb);%offset in x axis of c.o.m of base and thigh legs
    the_off   = atan(-dx/Llqr);
    if wheelzposition<=0.102 || wheelleftposition(3)<=0.102
        
        
       if t<Tstable
           bs_ref = (Lds+dh)/4*cos(2*pi/Tstable*t)+3*(Lds+dh)/4;
           dbs_ref=-(Lds+dh)/2*pi/Tstable*sin(2*pi/Tstable*t);
           ddbs_ref=-(Lds+dh)*(pi/Tstable)^2*cos(2*pi/Tstable*t);
           theta_ref=0.2*sin(2*pi/(Tstable)*t);
           dtheta_ref=0.2*2*pi/(Tstable)*cos(2*pi/(Tstable)*t);
           ddtheta_ref=-0.2*(2*pi/(Tstable))^2*sin(2*pi/(Tstable)*t);
           L_ref      = bs_ref;
           ddx_ref    = -(r*m*sin(theta_ref)*ddbs_ref+(m*L_ref^2+r*m*cos(theta_ref)*L_ref)*ddtheta_ref+...
                         (2*m*L_ref+2*r*m*cos(theta_ref))*dbs_ref*dtheta_ref-m*g*L_ref*sin(theta_ref)-2*m*r*sin(theta_ref)*L_ref*dtheta_ref^2)/(m*L_ref*cos(theta_ref)+r*(m+mb));
           F_ref      = (m+mb)*ddx_ref+m*L_ref*cos(theta_ref)*ddtheta_ref+...
                          m*ddbs_ref*sin(theta_ref)+2*m*cos(theta_ref)*dbs_ref*dtheta_ref-m*sin(theta_ref)*L_ref*dtheta_ref^2;
           [P1,P2,P3] = poly(T_ploy);
           v_ref      = P1*betadx;
           T_ploy     = T_ploy+dt;
       elseif t<Tstable+3
           bs_ref     = Lds+dh;
           dbs_ref    = 0;
           ddbs_ref   = 0;
           theta_ref  = the_off+0.02;
           dtheta_ref = 0;
           ddtheta_ref= 0;
           v_ref      = 1;
       else
           Time_plan = 1/f_plan;%period of planning
           ratioj    = Time_plan/dt;          
           ks_rem  = rem(kstance,ratioj);
           Time_planland=1/f_planland;%period of landing planning
           ratiol    = Time_planland/dt;
           ks_remland = rem(kLanding,ratiol);
           %---Planning for thrust phase---%
           if kstance<=1%plan for the first time
               tc = 0;%time that has been spent on planning
               [alpha,beta,betadx,dLd,ddLd,xs,T] = Optimal_Trajectory4(psym,kp,kpn,tc,Llqr,dLlqr,theta,dtheta,v,flagjump,zmax,theta_LO,dtheta_LO,vd,Lds,the_off);
               T_poly = 0;
           elseif flagjump == 0
               if t<=Tstable+kjt*Ts
               if ks_rem ==0
                   tc = t-Tstable;%time that has been spent on planning
                   [alpha,beta,betadx,dLd,ddLd,xs,T] = Optimal_Trajectory4(psym,kp,kpn,tc,Llqr,dLlqr,theta,dtheta,v,flagjump,zmax,theta_LO,dtheta_LO,vd,Lds,the_off);
                   T_poly = 0;
                   
                   kjumpplan = kjumpplan+1;
               end
               end
           end
           %---Planning for landing phase---%
           
           if flagjump == 1 && flagland == 0 
               T_land = t;
               tc     = 0;
               [alpha,beta,betadx,dLd,ddLd,xs,T] = Optimal_Trajectory4(psym,kp,kpn,tc,Llqr,dLlqr,theta,dtheta,v,flagjump,zmax,theta_LO,dtheta_LO,vd,Lds,the_off);
               flagland = 1;
               Theta_TD = theta*180/pi;
               T_poly = 0;
               %update the stats of disturbance observer
               z_joint  = [dstate(7);dstate(8);dstate(10);dstate(11)];
               z_wip    = [v;dyaw;dtheta];
               tanh_joint = zeros(4,1);
               tanh_wip   = zeros(3,1);
           elseif flagland == 1 %&& t>=T_land+Ts
               if t<=T_land+Ts
                   if ks_remland ==0
                       tc = t-T_land;%time that has been spent on planning
                       [alpha,beta,betadx,dLd,ddLd,xs,T] = Optimal_Trajectory4(psym,kp,kpn,tc,Llqr,dLlqr,theta,dtheta,v,flagjump,zmax,theta_LO,dtheta_LO,vd,Lds,the_off);
                       T_poly = 0;
                       klandplan = klandplan+1;
                   end
               else
%                elseif flagland == 1 && t>=T_land+1.5*Ts
                   alpha = [0;0;0;0;0;0;0;0;0;Lds+dh];
                   beta  = zeros(10,1);
                   betadx= [0;0;0;0;0;0;0;0;0;vd];
                   T_poly = 0;
               end
           end
           
           %polynomial trajectories in stance
           [P1,P2,P3] = poly(T_poly);
           L_ref      = P1*alpha;
           dL_ref     = P2*alpha;
           ddL_ref    = P3*alpha;
%            if l_ref >Lds+dh
%                L_ref   = Lds+dh;
%                dL_ref  = dLd;
%                ddL_ref = ddLd;
%            else
%                L_ref   = l_ref;
%                dL_ref  = dl_ref;
%                ddL_ref = ddl_ref;
%            end
           bs_ref     = L_ref;
           dbs_ref    = dL_ref;
           ddbs_ref   = ddL_ref;
           LT_jref(kstance)=bs_ref;
           LT_ref(kLanding)=bs_ref;
           TS(kstance)=T;
           dLT_jref(kstance)=dbs_ref;
           
           v_ref      = P1*betadx;
           V_REF(kstance) = v_ref;
           V_REFL(kLanding) = v_ref;
           theta_ref  = P1*beta+the_off;
           Theta_REF(kstance) = theta_ref;
           Theta_REFL(kLanding)=theta_ref;
           dtheta_ref = P2*beta;
           dTheta_REF(kstance) = dtheta_ref;
           ddtheta_ref= P3*beta;
           Alpha(:,kLanding)=alpha;
           Beta(:,kLanding)=beta;
           BetadX(:,kLanding)=betadx;
%            ddx_ref    = -(L_ref*ddtheta_ref+2*dbs_ref*dtheta_ref-g*sin(theta_ref))/cos(theta_ref);
%            F_ref      = (m+mb)*ddx_ref+m*sin(theta_ref)*ddbs_ref+m*cos(theta_ref)*L_ref*ddtheta_ref...
%                +2*m*cos(theta_ref)*dbs_ref*dtheta_ref-m*sin(theta_ref)*L_ref*dtheta_ref^2;
           ddx_ref    = -(r*m*sin(theta_ref)*ddbs_ref+(m*L_ref^2+r*m*cos(theta_ref)*L_ref)*ddtheta_ref+...
                         (2*m*L_ref+2*r*m*cos(theta_ref))*dbs_ref*dtheta_ref-m*g*L_ref*sin(theta_ref)-m*r*sin(theta_ref)*L_ref*dtheta_ref^2)/(m*L_ref*cos(theta_ref)+r*(m+mb));
           F_ref      = (m+mb)*ddx_ref+m*L_ref*cos(theta_ref)*ddtheta_ref+...
                          m*ddbs_ref*sin(theta_ref)+2*m*cos(theta_ref)*dbs_ref*dtheta_ref-m*sin(theta_ref)*L_ref*dtheta_ref^2;
           t_poly     = T_poly+dt;
           if t_poly<0
               T_poly = 0;
           else
               T_poly = t_poly;
           end
       end
       [ps_ref,dps_ref,ddps_ref] = StanceTaskReference3(bs_ref,dbs_ref,ddbs_ref); 
       Bs_sref(k)=bs_ref;
       Theta_sref(k)=theta_ref;
       V_sref(k)=v_ref;
    else%reference in flight calculated online
        if t<Tstable+0.3 || t>=Tstable+2
           L_fd       = Lds+dh;
           dL_fd      = 0;
           ddL_fd     = 0;
           [pf_ref,dpf_ref,ddpf_ref] = FlightTaskReference_DF4(psym,v_ref,L_fd,dL_fd,ddL_fd,dtheta_LO);
        elseif t<Tstable+2
            Time_planfly = 1/f_planfly;%period of planning
            ratiojfly    = Time_planfly/dt;          
            ks_remfly    = rem(kfly,ratiojfly);
            if flagjump == 0
               flagjump = 1;
               Theta_LO = theta*180/pi;
               ThetaDot_LO = dtheta*180/pi;
               dthetaLO    = ThetaDot_LO/180*pi;
               vcomz_LO = kL*vzb;
               LlqrLO   = Llqr;
               vLO      = v;
               vxbLO    = vxb;
               vzbLO    = vzb;
               Vzw_LO   = vzw;
               Vcom_LO  = kL*vxb+(1-kL)*v;
               v_ref  = Vcom_LO-kL*LTO*(ThetaDot_LO/180*pi);
               T_fly    = t;
               tc       = 0;
               [alpha_f,beta_f,L,z2,x2,Theta] = optimalfly3(psym,theta_TD,theta,dtheta,v,vzb,vzw,Llqr,vxb,theta,H_ob,ThetaDot_LO);
               T_poly = 0;
%             elseif flagjump==1
%                 if t<=T_fly+Tsfly
%                     if ks_remfly ==0
%                         tc = t-T_fly;%time that has been spent on planning
%                         [alpha_f,beta_f,L,z2,x2,Theta] = optimalfly3(psym,theta_TD,theta,dtheta,v,vzb,vzw,Llqr,vxb,theta,H_ob);
%                         T_poly = 0;
%                     end
%                 end    
            end
            [P1,P2,P3] = poly(T_poly);
            L_fd       = P1*alpha_f;
            L_FD(kfly) = L_fd;
            dL_fd      = P2*alpha_f;
            ddL_fd     = P3*alpha_f;
            Theta_FD(kfly)=P1*beta_f;
%             dtheta_fd  = P2*beta_f;
%             ddtheta_fd = P3*beta_f;
            [pf_ref,dpf_ref,ddpf_ref] = FlightTaskReference_DF4(psym,v_ref,L_fd,dL_fd,ddL_fd,dtheta_LO); 
           
            t_poly     = T_poly+kt*dt;
           if t_poly<0
               T_poly = 0;
           else
               T_poly = t_poly;
           end
            kfly = kfly+1;
        end
        Pf_ref(:,kfly)  = pf_ref;
        dPf_ref(:,kfly) = dpf_ref;
        ddPf_ref(:,kfly)= ddpf_ref;
        
    end
    
    %-------------------------------%
    %Behavior specific state machine
    %-------------------------------%
    if wheelzposition<=0.102 || wheelleftposition(3)<=0.102
%        [ddhkd,dhkd,hkd,thehd,thekd]=desiredangle2_DF(bs_ref,dbs_ref,ddbs_ref,Lg);
%         ps_ref  = [hkd;hkd];%hkd:hip angle, followed by knee angle
%         dps_ref = [dhkd;dhkd];
%         ddps_ref= [ddhkd;ddhkd];
%         Thehd(kstance)=thehd;
        ddxtsc = StanceStateMachine(ps_ref,dps_ref,ddps_ref,ps,dps,Kps,Kds);
    else
        ddxtfc = FlightStateMachine(pf_ref,dpf_ref,ddpf_ref,pf,dpf,Kpf,Kdf);
    end
    
    %---------------------------%
    %Control in different phases
    %---------------------------%
    %States for LQR
%     v      = r/2*(dq(5)+dq(6));%forward velocity+dtheta0L+dtheta0R   
    Yawrate(k)= dyaw;
    xlqr      = [theta;v;dyaw;dtheta];
    xref      = [theta_ref;v_ref;dyaw_ref;dtheta_ref];
    K         = LQRcontrol_NewPara(Llqr,theta_ref,dtheta_ref,v_ref,F_ref,Q,R);
    delxlqr   = xlqr-xref;
    lqrtorq   = -K*delxlqr;%additional control torque obtained by LQR for wheel motors 
    torqn  = [F_ref/2*r;F_ref/2*r]+lqrtorq;
     if wheelzposition<=0.102 || wheelleftposition(3)<=0.102
         [D_joint,D_wip,dz_joint,dz_wip,dtanh_joint,dtanh_wip,Xi_j,Xi_w,Md,Gd] = Disturbance_ObserverWBCPD3(K1j,K2j,...
             K1w,K2w,torque,state,dstate,delxlqr,z_joint,z_wip,tanh_joint,tanh_wip,pitchb,psym,F_ref,bs_ref,theta_ref,dtheta_ref,v_ref);
         z_joint    = z_joint+dt*dz_joint;
         z_wip      = z_wip+dt*dz_wip;
         tanh_joint = tanh_joint+dt*dtanh_joint;
         tanh_wip   = tanh_wip+dt*dtanh_wip;
%          D_joint    = zeros(4,1);
%          D_wip      = zeros(2,1);
         D_J(:,k)   = D_joint;
         D_W(:,k)   = D_wip;
         XI_J(:,k)  = Xi_j;
         XI_W(:,k)  = Xi_w;
         torque = StanceJointTorqueWBCPD4_DOB(Ats,dAts,dstate,ddxtsc,torqn,D_joint,D_wip,Md,Gd,torqueLimit);
         if flagjump == 0 && t>Tstable
             kstance= kstance+1;
         elseif flagjump == 1
             kLanding  = kLanding+1;
         end
     else
         torque = FlightJointTorques(Atf,dAtf,state,dstate,ddxtfc,psym,torqueLimit);
         if t>Tstable+0.3
             
             if flagjump == 1&& kj ==0
                 
                 kj = 1;
             end
         else
             flagjump = 0;
         end
     end
     k=k+1;
     
    %   3.3 set the torque in vrep way
    for i=1:jointNum
        if sign(torque(i))<0
            setVel=-9999; % set a trememdous large velocity for the screwy operation 
            if torque(i)<-torqueLimit(i)
                setTu=-torqueLimit(i);
            else
                setTu=-torque(i);
            end
        else
            setVel=9999;
            if torque(i)>torqueLimit(i)
                setTu=torqueLimit(i);
            else
                setTu=torque(i);
            end
        end
        vrep.simxSetJointTargetVelocity(clientID,jointHandle(i),setVel,vrep.simx_opmode_oneshot);
        vrep.simxSetJointForce(clientID,jointHandle(i),setTu,vrep.simx_opmode_oneshot);
        Torque(i,k)=setTu; 
    end

    % 4. update vrep(the server side)
    lastCmdTime     = currCmdTime;
    jointLAST       = jointConfig;   
    bpositionLast   = bposition;
    orientationLast = baseorientation.';
    deulerLast      = deuler;
    wbLast          = wb;
    vLast           = v;
    thetaLast       = theta;
    dthetaLast      = dtheta;
    yawLast         = yaw;
    dqLast          = dq;
    LlqrLast        = Llqr;
    vbaseLast       = vbase;
    AtsLast         = Ats;
    AtfLast         = Atf;
    wheelLxLast     = wheelLx;
    wheelLyLast     = wheelLy;
    wheelRxLast     = wheelRx;
    wheelRyLast     = wheelRy;
    wheelzpositionLast = wheelzposition;
    vrep.simxSynchronousTrigger(clientID);
    t=t+dt; % updata simulation time
    Time(k)=t;
end
vrep.simxFinish(-1);  % close the link
vrep.delete();        % destroy the 'vrep' class

%%
% figure(1); hold off;
% subplot(411); plot(E(1,:),'r'); hold on; plot(E(2,:),'b'); title('error')
% subplot(412); plot(Q(1,:),'r'); hold on; plot(Q(2,:),'b');  plot(QD(1,:),'k'); hold on; plot(QD(2,:),'k'); title('trajectory')
% subplot(413); plot(DQ(1,:),'r'); hold on; plot(DQ(2,:),'b');  plot(DQD(1,:),'k'); hold on; plot(DQD(2,:),'k'); title('velocity')
% subplot(414); plot(TAU(1,:),'r'); hold on; plot(TAU(2,:),'b'); title('torque')

