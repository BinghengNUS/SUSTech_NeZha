clear all;clc;close all;

global sys Disind
sys.g = 9.81;           sys.l0 = 1;             sys.k = 11e3;
sys.m = 80;             sys.dt = 1e-3;
sys.f.umax = 10;         sys.f.umin = 0;
sys.N = 9;
Disind = 1;


% initial & desired state specification
Trajall.t = [];
Trajall.z = [];
Trajall.U = [];
Trajall.W = [];
Trajall.fp = [];



zd = [ 0.499419386500801; 4.5 ; 0; 0.866360361735909; 1.73532068572530; -sys.g ];

inivx = 3.5;
inihy = 1.3;

Errvx(1:length(inivx),1:length(inihy)) = nan;
Errhy(1:length(inivx),1:length(inihy)) = nan;
maxLine(1:length(inivx),1:length(inihy)) = nan;
maxTorque(1:length(inivx),1:length(inihy)) = nan;
ErrTransVx(1:length(inivx),1:length(inihy)) = nan;
ErrTransHy(1:length(inivx),1:length(inihy)) = nan;
ind1 = 1;
ind2 = 1;
iter = 0;

while ind1 <= length(inivx)
    while ind2 <= length(inihy)
        iter = iter+1
        tic
        Trajall.U = [];

        errTvx = 0;
        errThy = 0;
        t0 = 0;
        
        the0 = deg2rad(90);
        z0 = [0;inivx(ind1);inihy(ind2);0];
        Disind = 1;
        for pr = 1:8
            [td,~,~,~] = flightPlan(z0,zd,the0);
            
            trajf = simuFlight(t0,z0,td);
            %
            zp0 = trajf.z(:,end) - [trajf.fp(1);0;0;0];
            [Ust,Tst] = stancePlan(zp0,zd);
            
            t0 = trajf.t(end);
            z0 = trajf.z(:,end);
            fp0 = trajf.fp;
            trajs = simuStance(t0,z0,fp0,Ust,[0;0],Tst);
            
            t0 = trajs.t(end);
            z0 = trajs.z(:,end);
            

            Trajall.U = [Trajall.U zeros(2,length(trajf.t)) Ust(:,1:length(trajs.t))];

            the0 = atan2(z0(3),z0(1)-fp0(1));
            
            vxc(Disind,ind1,ind2) = max(trajf.z(2,:));
            hyc(Disind,ind1,ind2) = max(trajf.z(3,:));
            
            
            errTvx = errTvx + (vxc(Disind,ind1,ind2) - 4.5);
            errThy = errThy + (hyc(Disind,ind1,ind2) - 1.02);
            Disind = Disind+1;
            
        end
        
        Errvx(ind1,ind2) = (vxc(end,ind1,ind2) - 4.5)/4.5;
        Errhy(ind1,ind2) = (hyc(end,ind1,ind2) - 1.02)/1.02;
        maxLine(ind1,ind2) = max(abs(Trajall.U(1,:)));
        maxTorque(ind1,ind2) = max(abs(Trajall.U(2,:)));
        ErrTransVx(ind1,ind2) = errTvx;
        ErrTransHy(ind1,ind2) = errThy;
        toc
        
        if maxTorque(ind1,ind2) >=500 || maxLine(ind1,ind2)>=0.3
            Errvx(ind1,ind2) = nan;
            Errhy(ind1,ind2) = nan;
            maxLine(ind1,ind2) = nan;
            maxTorque(ind1,ind2) = nan;
            ErrTransVx(ind1,ind2) = nan;
            ErrTransHy(ind1,ind2) = nan;
            
            ind1 = ind1+1;
            ind2 = 1;
            break
        else
            ind2 = ind2+1;
        end
        
    end
    if ind2 >= length(inihy)
        ind1 = ind1+1;
        ind2 = 1;
    end

end

