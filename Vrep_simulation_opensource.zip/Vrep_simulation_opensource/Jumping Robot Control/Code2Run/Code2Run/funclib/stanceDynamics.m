function dz = stanceDynamics(t,z,u,d,fp)
global sys
if size(u,2) ~=1
    u = u(:,ceil(t/sys.dt)+1);
end


l = [z(1);z(3)] - fp;
normvec = l/norm(l);
torquevec = [-normvec(2);normvec(1)];
f = l/norm(l)* sys.k*(sys.l0 - norm(l)+u(1)) + torquevec*u(2)/norm(l) + d;
accel = 1/sys.m * f + [0 ; -sys.g];
dz = [z(2) ; accel(1) ; z(4); accel(2)];
end