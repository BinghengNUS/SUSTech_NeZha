function traj =  simuStance(t0,z0,fp0,u,d,Tsp)
global sys

if nargin==5
    Tsp = 0:sys.dt:10;
end
stanceOptions = odeset('Events',@(t,z) takeoffEvent(t,z,fp0),'AbsTol',1e-12,'RelTol',1e-9);
[ts,xs] = ode45(@(t,z) stanceDynamics(t,z,u,d,fp0),Tsp,z0,stanceOptions);
ts = ts';
xs = xs';
traj.t = t0+ts;
traj.z = xs;
traj.fp = fp0;
end