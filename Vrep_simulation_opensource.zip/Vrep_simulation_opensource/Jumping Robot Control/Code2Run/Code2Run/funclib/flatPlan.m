function [p,J,T] = flatPlan(z0,zd)
global sys
N = sys.N;

Trajs = simuStance(0,z0,[0;0],[0;0],[0;0]);
T = Trajs.t;
z1 = Trajs.z(1,:);
z2 = Trajs.z(3,:);

px1 = polyfit(T,z1,N);
px2 = polyfit(T,z2,N);
pref = [px1(end:-1:1) px2(end:-1:1)]';

acc0 = accel(z0,[0;0],[0;0]);
z0 = [z0(1:2); acc0(1); z0(3:4); acc0(2)];

[H,c,c0,A,b,Aineq,bineq] = computeQPmat(T(end),z0,zd,N,pref);

[coe,Jc] =  cplexqp(H,c,Aineq,bineq,A,b);

J = Jc+c0;
p = coe;

end