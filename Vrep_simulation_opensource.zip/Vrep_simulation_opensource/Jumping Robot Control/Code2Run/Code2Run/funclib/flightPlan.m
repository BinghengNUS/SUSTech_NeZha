function [td,W,Ustance,Tstance] = flightPlan(z0,zd,the0)

Theta = deg2rad(100):deg2rad(1):deg2rad(145); % gridding desired target
%     Theta = deg2rad(120);
Jtheta = inf(size(Theta));
U = cell(1,length(Theta));
Tc =  zeros(size(Theta));
for ind = 1:length(Theta)
    
    tta = Theta(ind);
    [zs0,Tsp] = computeTD(z0,tta);
    
    if isreal(Tsp)
        
        %         [~,Jt,~] = flatPlan(zs0,zd);
        
        [Uxx{ind},Txx{ind},Jt] = stancePlan(zs0,zd);
        
        [U{ind},Jtheta(ind)] = FlightPlanning(the0,tta,Jt,Tsp);
    end
    Tc(ind) = Tsp;
    
end

[~,indopt] = min(Jtheta);
Topt = Tc(indopt);
W = U{indopt};
td = the0 +W(1)*Topt;
Ustance = Uxx{indopt};
Tstance = Txx{indopt};
end

function [U,Jtheta] = FlightPlanning(the0,thed,Jt,Tsp)
global sys
Ndis = ceil(Tsp/sys.dt); % overall discretized timesteps
umax = sys.f.umax;
umin = sys.f.umin;

b = thed- the0; % theta_f - theta_0

Uc = b/(sys.dt*Ndis);
Ux = min(umax,max(umin,Uc));
U  = repmat(Ux,Ndis,1);
Jc = 0;

U = U';
Jtheta = Jc+Jt;


end