function dz = flightDynamics(t,z)
global sys

dz = [ z(2) ; 0 ; z(4); -sys.g];
end