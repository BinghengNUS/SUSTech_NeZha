function [value, isterminal, direction] = balanceEvent(t,z)
value = z(4);
isterminal = 1;	direction = 1;
end