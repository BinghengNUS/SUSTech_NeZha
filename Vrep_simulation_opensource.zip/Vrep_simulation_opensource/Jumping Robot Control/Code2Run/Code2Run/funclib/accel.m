function acc = accel(z,u,d)
global sys
l = [z(1);z(3)];
normvec = l/norm(l);
torquevec = [-normvec(2);normvec(1)];
f = l/norm(l)* sys.k*(sys.l0 - norm(l)+u(1)) + torquevec*u(2)/norm(l) + d;
acc = 1/sys.m * f + [0 ; -sys.g];

end