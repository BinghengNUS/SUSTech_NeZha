function y = computefp(z,ind,w,the0,fp0)
global sys
theta = the0 + [0 cumsum(sys.dt*w)];

for i=1:length(z)
    if ind(i)==0
        y(:,i) = [z(1,i)-cos(theta(i));z(3,i)-sin(theta(i))];
    else
        y(:,i) = fp0;
    end
end


end