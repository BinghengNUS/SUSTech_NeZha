function [H,c,c0,A,b,Aineq,bineq] = computeQPmat(Ts,y0,yf,N,pref)
global sys Disind
if isempty(Disind)
    pw = 3;
else
    pw = Disind+2;
end
gamma = min(10^pw,1e6);
Phi0 = phipoly(N,2,0);
PhiT = phipoly(N,2,Ts);

%% equality cons for initial and terminal acc
Aini = blkdiag(Phi0,Phi0); % A for initial condition
bini = reshape(y0,[],1);
Ater = blkdiag(PhiT(3,:),PhiT(3,:));
bter = [0;-sys.g];

%% inequality cons for terminal upward speed
Aineq = -[zeros(1,N+1) PhiT(2,:)];
bineq = 0;


%% cost for passiveSLIP 0.5*x'*H*x+c*x+c0

H1 = blkdiag(eye(N+1),eye(N+1));
H2 = blkdiag(PhiT'*PhiT,PhiT'*PhiT);
H = H1+ gamma*H2;
H = (H+H');

c0 = reshape(yf,[],1)'*gamma*reshape(yf,[],1) + pref'*pref;
c =  -2*gamma*reshape(yf,[],1)'*blkdiag(PhiT,PhiT) -2*pref' ;


A = [Aini;Ater];
b = [bini;bter];
end

