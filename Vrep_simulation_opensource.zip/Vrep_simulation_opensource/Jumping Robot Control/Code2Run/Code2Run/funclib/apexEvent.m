function [value, isterminal, direction] = apexEvent(t,z,sys)
value = z(4);
isterminal = 1;	direction = -1;
end
