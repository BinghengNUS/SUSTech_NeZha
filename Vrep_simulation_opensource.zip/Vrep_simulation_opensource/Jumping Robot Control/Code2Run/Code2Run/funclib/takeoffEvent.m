function [value, isterminal, direction] = takeoffEvent(t,z,fp)
global sys
len = norm([z(1);z(3)]-fp);
value = len-sys.l0;
isterminal = 1;	direction = +1;
end
