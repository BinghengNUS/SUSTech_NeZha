function [xT,Tspan] = computeTD(x0,theta_d)
% in local frame
global sys
%x0 is flight state
xT = zeros(4,1);

pcoeff = [0.5*sys.g -x0(4) sys.l0*sin(theta_d)-x0(3)];

t = max(roots(pcoeff));

xT(1) = sys.l0*cos(theta_d);
xT(2) = x0(2);
xT(3) = sys.l0*sin(theta_d);
xT(4) = x0(4)-sys.g*t;

Tspan = t;
end