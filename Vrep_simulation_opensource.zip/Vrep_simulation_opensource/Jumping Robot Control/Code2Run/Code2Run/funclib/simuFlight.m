function traj = simuFlight(t0,z0,td,Tsp)
global sys

if nargin==3
    Tsp = 0:sys.dt:10;
end

flightOptions = odeset('Events',@(t,z) touchdownEvent(t,z,td),'AbsTol',1e-12,'RelTol',1e-9);
[tf,xf] = ode45(@flightDynamics,Tsp,z0,flightOptions);
tf = tf';
xf = xf';

traj.t = t0+tf;
traj.z = xf;
traj.fp = [xf(1,end)-sys.l0*cos(td) ; 0 ];
traj.td = td;
end

