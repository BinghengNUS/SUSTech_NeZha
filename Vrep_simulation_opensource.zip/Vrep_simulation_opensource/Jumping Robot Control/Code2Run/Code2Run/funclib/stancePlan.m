function [U,Tsp,Jc] = stancePlan(z0,zd)
% z0,zd both in local frame
global sys

if nargin == 2
    uc = [0;0];
end

N = sys.N;

[pcoe,Jc,Tsp] = flatPlan(z0,zd);
p1 = pcoe(N+1:-1:1);
p2 = pcoe(end:-1:N+2);

Y(1,:) = polyval(p1,Tsp);
Y(2,:) = polyval(polyder(p1),Tsp);
Y(3,:) = polyval(polyder(polyder(p1)),Tsp);
Y(4,:) = polyval(p2,Tsp);
Y(5,:) = polyval(polyder(p2),Tsp);
Y(6,:) = polyval(polyder(polyder(p2)),Tsp);
U= flat2input(Y);

end