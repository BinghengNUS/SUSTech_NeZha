function [U,X] = flat2input(Y)
global sys
g = sys.g;
m = sys.m;
r0 = sys.l0;
k = sys.k;

y1 = Y(1,:);
% dy1 = Y(2,:);
ddy1 = Y(3,:);
y2 = Y(4,:);
% dy2 = Y(5,:);
ddy2 = Y(6,:);

X = [Y(1:2,:); Y(4:5,:)];

for i = 1:size(Y,2)
U(1,i) = sqrt(y1(i)^2+y2(i)^2) - r0 + (m*y1(i)*ddy1(i))/(k*sqrt(y1(i)^2+y2(i)^2))+(m*y2(i)*ddy2(i))/(k*sqrt(y1(i)^2+y2(i)^2))+(m*g*y2(i))/(k*sqrt(y1(i)^2+y2(i)^2));
U(2,i) = m*(g*y1(i)+y1(i)*ddy2(i) - y2(i)*ddy1(i));
end

