function J_i2b = Rzyx(x,y,z)
C_x  = [1,      0,     0;
        0, cos(x),sin(x);
        0,-sin(x),cos(x)];
C_y  = [cos(y), 0, -sin(y);
             0, 1,       0;
        sin(y), 0,  cos(y)];
C_z  = [ cos(z), sin(z), 0;
        -sin(z), cos(z), 0;
              0,      0, 1];
J_i2b= C_x*C_y*C_z;