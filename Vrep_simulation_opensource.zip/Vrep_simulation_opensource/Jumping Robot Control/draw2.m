 N=1000;
delt=Ts/N;
k=1;
for t=0:delt:Ts
[P0,~,~]=poly(t);
L_1(k)=P0*alpha;
k=k+1;
end
t=0:delt:Ts;
plot(t,L_1)