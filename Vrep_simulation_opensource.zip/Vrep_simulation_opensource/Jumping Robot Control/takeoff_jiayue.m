function[L,dL,ddL,theta,dtheta,ddtheta] = takeoff_jiayue(states, states_des, T_plan, deltaT)
%states: dx, dL, dtheta, x, L, theta
% tau = 0.01; % delta T which can change
T = 1;
solution = load('nn_param_takeoff.txt');
shapes = [18 12; 12 12; 12 12; 12 10]; % shapes of newral network
leng = size(shapes, 1);
pointer = 1;
for i = 1:leng
    w_shape = shapes(i,:);
    b_shape = shapes(i,2);
    s_w(i) = w_shape(1)*w_shape(2);
    s(i) = s_w(i) + b_shape;
end
% weights and bias for NN
weights = cell(1,4);
bias = cell(1,4);

for j = 1:leng
    for k = 1:shapes(j,1)
        s = shapes(j,2);
        weights{1,j}(k,:) = solution(pointer:pointer+s-1);
        pointer = pointer + s;
    end
    s = shapes(j,2);
    bias{1,j} = solution(pointer:pointer+s-1);
    pointer = pointer + s;
end

states_error = [0,0,0,0,0,0];
states_error(1) = states(1) - states_des(1);
states_error(2) = states(2) - states_des(2);
states_error(3) = states(3) - states_des(3);
states_error(4) = states(4) - states_des(4);
states_error(5) = states(5) - states_des(5);
states_error(6) = states(6) - states_des(6);
inputs_nn = cat(2,states, states_des, states_error);
h = inputs_nn;
for i = 1:leng
	w = weights{1,i};
	b = bias{1,i};
	h = h*w + b';
	if i < 4
        h = max(h,0);
    end
end
theta = 1 ./ (1 + exp(-h));
upplim_L = 0.8;
lowlim_L = 0.4;
upplim_theta = 0.785;
lowlim_theta = -0.785;
L_to = 0.76;
theta_to = 0.0873;
dtheta_to = 0.01;
ddL_to=-14.5;
dL_to= 4.367708639618923;
ddtheta_to= -0.1149397010426032;
theta_L = zeros(1,10);
theta_theta = zeros(1,10);
theta_L(10) = L_to;
theta_L(9) = theta_L(10) - dL_to*T/9;
theta_L(8) = ddL_to*T*T/72 - theta_L(10) + 2*theta_L(9);

theta_theta(10) = theta_to;
theta_theta(9) = theta_theta(10) - dtheta_to*T/9;
theta_theta(8) = ddtheta_to*T*T/72 - theta_theta(10) + 2*theta_theta(9);

theta_L(3:7)=((upplim_L - lowlim_L).*theta(1:5)) + lowlim_L;
theta_theta(3:7)=((upplim_theta - lowlim_theta).*theta(6:10)) + lowlim_theta;
x1 = weights0_1(theta_L(3:10) ,T_plan, T, states(5), states(2));
theta_L(1)=x1(1);
theta_L(2)=x1(2);
x2 = weights0_1(theta_theta(3:10) ,T_plan, T, states(5), states(2));
theta_theta(1)=x2(1);
theta_theta(2)=x2(2);
L = bezier(theta_L,T_plan + deltaT);
dL = dbezier(theta_L,T_plan +deltaT);
ddL = ddbezier(theta_L,T_plan +deltaT);
theta = bezier(theta_theta,T_plan +deltaT);
dtheta = dbezier(theta_theta,T_plan +deltaT);
ddtheta = ddbezier(theta_theta,T_plan +deltaT);
% [Fx,deltaL] = inverse_action_s(theta_L, theta_theta);
% Fx = clip(Fx, -100, 100);
% deltaL = clip(deltaL, -0.5, 0.5);
% actions = [Fx, deltaL];
% [diff1, diff2,diff3,diff4,diff5,diff6] = dmove_s(states, actions);
% states_des = states + [diff1*tau, diff2*tau,diff3*tau,diff4*tau,diff5*tau,diff6*tau]; % output desired states after tau = 0.01

    function output = clip(num, minimum_num, maximum_num)
        if num < minimum_num
            output = minimum_num;
        elseif num > maximum_num
            output = maximum_num;
        else
            output = num; 
        end
    end

    function output = bezier(weights,tau)
        % output = 0;
        tau_aux = 1 - tau ; 
        output = power(tau_aux,5)*weights(1) + 5*power(tau_aux,4)*tau*weights(2) + 10*power(tau_aux,3)*power(tau,2)*weights(3) + 10*power(tau_aux,2)*power(tau,3)*weights(4) + 5*tau_aux*power(tau,4)*weights(5) + power(tau,5)*weights(6);
       
    end

    function out_aux= dbezier(weights,tau)
        % doutput = 0;
        tau_aux = 1 - tau;  
        out_aux= 5*power(tau_aux,4)*(weights(2)-weights(1)) + 20*power(tau_aux,3)*tau*(weights(3)-weights(2)) + 30*power(tau_aux,2)*power(tau,2)*(weights(4)-weights(3)) + 20*tau_aux*power(tau,3)*(weights(5)-weights(4)) + 5*power(tau,4)*(weights(6)-weights(5));
        % doutput = out_aux/(p[1]-p[0]); %very important       
    end

    function out_aux = ddbezier(weights, tau)
        % doutput = 0;
        tau_aux = 1 - tau;
        out_aux= -20*(weights(2)-weights(1))*power(tau_aux,3) + 20*(weights(3)-weights(2))*(-3*power(tau_aux,2)*tau + power(tau_aux,3)) ...
                + 30*(weights(4)-weights(3))*(-2*tau_aux*power(tau,2)+ 2*power(tau_aux,2)*tau) ...
                + 20*(weights(5)-weights(4))*(-power(tau,3)+ 3*power(tau,2)*tau_aux) + 20*(weights(6)-weights(5))*power(tau,3);
        % doutput = out_aux/(p[1]-p[0]); % very important

    end

    function x = weights0_1(weights2_9,T_pass, T, x, dx)
        tau1 = T_pass/T;
        v = num2cell(weights2_9);
        [weights2,weights3,weights4,weights5,weights6,weights7,weights8,weights9] = deal(v{:});
        a11 = (1-tau1)^9;
        a12 = 9*(1-tau1)^8*tau1;
        b1 = 36*(1-tau1)^7*tau1^2*weights2 ...
            + 84*(1-tau1)^6*tau1^3*weights3 + 126*(1-tau1)^5*tau1^4*weights4 + 126*(1-tau1)^4*tau1^5*weights5 + 84*(1-tau1)^3*tau1^6*weights6 ...
            + 36*(1-tau1)^2*tau1^7*weights7 + 9*(1-tau1)^1*tau1^8*weights8 + tau1^9*weights9 - x;


        b2 = -9*tau1^8*weights8 + 9*tau1^8*weights9 + 36*tau1^7*weights7*(2*tau1 - 2) + 8*tau1^7*weights8*(9 - 9*tau1) ...
            - 252*tau1^6*weights6*(1 - tau1)^2 + 252*tau1^6*weights7*(1 - tau1)^2 - 504*tau1^5*weights5*(1 - tau1)^3 ...
            + 504*tau1^5*weights6*(1 - tau1)^3 - 630*tau1^4*weights4*(1 - tau1)^4 + 630*tau1^4*weights5*(1 - tau1)^4 ...
            - 504*tau1^3*weights3*(1 - tau1)^5 + 504*tau1^3*weights4*(1 - tau1)^5 - 252*tau1^2*weights2*(1 - tau1)^6 ...
            + 252*tau1^2*weights3*(1 - tau1)^6 + 72*tau1*weights2*(1 - tau1)^7 - dx*T;

        a21 = - 9*(1 - tau1)^8;
        a22 = 9*(1 - tau1)^8 - 72*tau1*(1 - tau1)^7;

        a = [[a11,a12];[a21,a22]];
        b = [-b1;-b2];
        x = a\b;
    end

    function [Fx, deltaL] = inverse_action_s(weights_L, weights_theta)
        mb = 6.68;
        mw = 2.88;
        L0 = 0.92;
        Ks = 697.1917;
        g = 9.81;
        r = 0.1;
        deltaT = 0.01;      
        
        L = bezier(weights_L,deltaT);
        dL = dbezier(weights_L,deltaT);
        ddL = ddbezier(weights_L,deltaT);
        theta = bezier(weights_theta,deltaT);
        dtheta = dbezier(weights_theta,deltaT);
        ddtheta = ddbezier(weights_theta,deltaT);

        ddx = -mb*(L^2*ddtheta + 2*L*dL*dtheta + L*ddtheta*r*cos(theta) - 2*L*dtheta^2*r*sin(theta) ...
            - L*g*sin(theta) + 2*dL*dtheta*r*cos(theta) + ddL*r*sin(theta))/(L*mb*cos(theta)+ mb*r + mw*r);
        deltaL = (-mb^2*(L^2*ddtheta + 2*L*dL*dtheta + L*ddtheta*r*cos(theta) ...
            - 2*L*dtheta^2*r*sin(theta) - L*g*sin(theta) + 2*dL*dtheta*r*cos(theta) ...
            + ddL*r*sin(theta))*sin(theta) + (L*mb*cos(theta) + mb*r + mw*r)*(Ks*L - Ks*L0 ...
            - L*dtheta^2*mb + ddL*mb + g*mb*cos(theta)))/(Ks*(L*mb*cos(theta) + mb*r + mw*r));
        Fx = (mb+mw)*ddx + mb*sin(theta)*ddL + mb*cos(theta)*L*ddtheta + 2*mb*cos(theta)*dL*dtheta ...
            - mb*sin(theta)*L*dtheta^2;
    end

    function[ddx, ddL, ddtheta, dx, dL, dtheta] = dmove_s(states, actions)
        Fx = actions(1);
        deltaL = actions(2);
        dx = states(1);
        dL = states(2);
        dtheta = states(3);
        x = states(4);
        L = states(5);
        theta = states(6);
        mb = 6.68;
        mw = 2.88;
        L0 = 0.92;
        Ks = 697.1917;
        g = 9.81;
        r = 0.1;
        ddx = (Fx*L + Fx*r*cos(theta) + Ks*L^2*sin(theta) - Ks*L*L0*sin(theta) ...
            - Ks*L*deltaL*sin(theta))/(L*mw);
        ddL = -Fx*sin(theta)/mw - Fx*r*sin(2*theta)/(2*L*mw) + Ks*L*cos(2*theta)/(2*mw) ...
            - Ks*L/(2*mw) - Ks*L/mb - Ks*L0*cos(2*theta)/(2*mw) + Ks*L0/(2*mw) + Ks*L0/mb ...
            - Ks*deltaL*cos(2*theta)/(2*mw) + Ks*deltaL/(2*mw) ...
            + Ks*deltaL/mb + L*dtheta^2 - g*cos(theta);
        ddtheta = -Fx*cos(theta)/(L*mw) - Fx*r*cos(2*theta)/(2*L^2*mw) - Fx*r/(2*L^2*mw) ...
            - Fx*r/(L^2*mb) - Ks*sin(2*theta)/(2*mw) + Ks*L0*sin(2*theta)/(2*L*mw) ...
            + Ks*deltaL*sin(2*theta)/(2*L*mw) - 2*dL*dtheta/L + g*sin(theta)/L;
    end

end
            