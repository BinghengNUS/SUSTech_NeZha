function tau = StanceJointTorquePD3_DOB(ddxtsc,torq_lqr,psym,D_joint,D_wip)
%This function returns the joint torques needed for the robot base c.o.m to
%track the desired c.o.m trajectory. The control law is PD plus gravity
%compensation.
%psym  = [r,d,g,Lg,Ltcom,Lscom,dh,dhs,mfb,mtl,msl,mw,mur,mus];
%****************By Bingheng WANG, on Mar.19 2020*************************
dh       = psym(7);
Lg       = psym(4);
Ltcom    = psym(5);
mfb      = psym(9);
mtl      = psym(10);
Iyyb     = 0.0249232975683053;
Iyyt     = 0.022309557436881;
Mhip     = 1/2*(mfb*dh^2+Iyyb);
Mknee    = mtl*(Lg+Ltcom)^2+Iyyt;
hiptorqL = Mhip*(ddxtsc(1)-D_joint(1));
hiptorqR = Mhip*(ddxtsc(3)-D_joint(3));
kneetorqL= Mknee*(ddxtsc(2)-D_joint(2));
kneetorqR= Mknee*(ddxtsc(4)-D_joint(4));
torqL = torq_lqr(1)-D_wip(1);
torqR = torq_lqr(2)-D_wip(2);
 tau = [hiptorqL;hiptorqR;kneetorqL;kneetorqR;torqL;torqR];