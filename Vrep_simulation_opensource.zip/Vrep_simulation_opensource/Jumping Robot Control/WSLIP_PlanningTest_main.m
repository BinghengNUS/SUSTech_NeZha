clear all
%*************************************************************************
% Planning Test based on 3DoF W-SLIP model
%**********************By Bingheng WANG,on 2 July, 2020*******************
r     = 0.1;%radius of wheel
d     = 0.175;%distance from the wheel to the center of body
g     = 9.8;
Lg    = 0.429;%length of Thighlink
Ltcom = -0.05;%z position of Thigh_link C.O.M in link frame
Lscom = -0.35;%z position of Shank_link C.O.M in link frame
dh    = 0.0474+0.02;% height of C.O.M of the main body relative to the hip joint
dhs   = 0;%-2.003e-02;%height of C.O.M of the main body in shape frame of bounding box
mfb   = 5.5;%mass of the floating base
mtl   = 2;%mass of the thigh leg
msl   = 1.05;%mass of the shank leg
mw    = 0.55;%mass of the wheel
psym  = [r,d,g,Lg,Ltcom,Lscom,dh,dhs,mfb,mtl,msl,mw];%system parameter vector
m     = psym(9)+2*(psym(10));%total upper mass
mb    = 2*(psym(11)+psym(12));%mass of shank link and wheel
Lds   = 0.72;
%spring stiffness
thekmin  = -140/180*pi;
thekmax  = -60/180*pi;
Lmin     = -Lg*sin(thekmax/2);
Lmax     = -Lg*sin(thekmin/2);
kp       = 30;%50
kpn      = 30;
Ksmax    = kp/(Lmin^2);
Ksmin    = kp/(Lmax^2);
Ks       = 1/2*(Ksmax+Ksmin);
Ts       = 2*pi*sqrt(m/Ks);%estimate of the spring period
dt       = 0.002;
N        = round(Ts/dt);
kp       = 30;
State    = zeros(6,N+2);
Time     = zeros(1,N+2);
Inter    = 1;
%Initialization
x0       = 0;
L0       = Lds+dh;
dL0      = 0;
dtheta0  = 0;

fplan    = 25;
Tplan    = 1/fplan;
%Target condition
theta_LO = 15/180*pi;
zmax     = 1;%kL*(Lds+dh)+H_ob+r;%maximum height of jump of system CoM
kL       = m/(m+mb);
LTO      = Lds+dh;
tr       = sqrt(2*(zmax-r-kL*LTO*cos(theta_LO))/g);%rising time
td       = sqrt(2*(zmax-r-kL*LTO)/g);%descending time
Tf       = tr+td;%flight time
theta_TD = 0/180*pi;
dtheta_LO= (theta_TD-theta_LO)/Tf;
vd       = 1;
i        = 2;
j        = 1;
kplan    = 1;
iv       = 1;
jt       = 1;
ki       = 1;
FS       = zeros(21,21);
% for v0=0:0.1:2
%     for theta0=-30/180*pi:3/180*pi:30/180*pi
%         Control  = zeros(1,N+2);
%         X0       = [x0;L0;theta0;v0;dL0;dtheta0];
%         State(:,1)=X0;
%         for t=0:dt:Ts
%         trem = rem(t,Tplan);
%         if trem==0
%         tc  = t;
%         [alpha,beta] = Optimal_Trajectory5_plantest(psym,kp,tc,X0,zmax,theta_LO,dtheta_LO,vd,Lds);
%         Tpoly = 0;
%         kplan = kplan+1;
%         end
%         U_ref = feedforwardCtrl(Tpoly,alpha,beta,kp,psym);
%         Tpoly = Tpoly+dt;
%         %4th-order Runge-kutta algorithm
%         K1    = WSLIPmodel_RK4(t,X0,U_ref,kp,psym);
%         K2    = WSLIPmodel_RK4(t+dt/2,X0+dt*K1/2,U_ref,kp,psym);
%         K3    = WSLIPmodel_RK4(t+dt/2,X0+dt*K2/2,U_ref,kp,psym);
%         K4    = WSLIPmodel_RK4(t+dt,X0+dt*K3,U_ref,kp,psym);
%         X1    = X0+dt/6*(K1+2*K2+2*K3+K4);
%         dx    = 1/6*(K1+2*K2+2*K3+K4);
%         %update
%         X0    = X1;
%         State(:,i)=X0;
%         Control(:,i)=U_ref(1);%Fx
%         i     = i+1;
%         end
%         Traj.x{Inter} = State;
%         Traj.c{Inter} = Control;
%         if max(Control)>200||min(Control)<-200
%             FS(iv,jt) = 1;
%         else
%             FS(iv,jt) = 0;
%         end
%         jt = jt+1;
%         ki = ki+1
%         Inter=Inter+1;
%     end
%     jt = 1;
%     iv = iv+1;
% end
% v0      = 0:0.1:2;
% theta0  = -30:3:30;
% [X,Y]=meshgrid(theta0,v0);
% figure(1)
% surf(X,Y,FS);
% % colorbar
% ylabel('Initial Velocity [m/s]');
% xlabel('Initial Pitch Angle [deg]');
% zlabel('Flag');
kg       = 1.25;
v0       = 1.8;
theta0   = -9/180*pi;
X0       = [x0;L0;theta0;v0;dL0;dtheta0];
Control(:,1)=[0;(m+mb)*g*cos(X0(3))];
State(:,1)=X0;
thed   = theta_LO;
dthed  = dtheta_LO;
Ld     = Lds+dh;
dLd    = (kL^(-1)*sqrt(2*g*(zmax-kL*Ld*cos(thed)-r))+Ld*sin(thed)*dthed)/cos(thed);
Accd   = [-(1+mb/m)*kg*g+2*dLd*sin(thed)*dthed+Ld*cos(thed)*dthed^2;
          -mb/m*kg*g*tan(thed)-kg*g*tan(thed)-2*dLd*cos(thed)*dthed+Ld*sin(thed)*dthed^2];
Mcc    = [cos(thed),  sin(thed);
          -sin(thed)/Ld,cos(thed)/Ld];
accd   = Mcc^(-1)*Accd;
ddthed = accd(2);
dLd    = (kL^(-1)*sqrt(2*g*(zmax-kL*Ld*cos(thed)-r))+Ld*sin(thed)*dthed)/cos(thed);
ddLd   = accd(1);
      
%legend('Success','Failure');
        for t=0:dt:Ts
        trem = rem(t,Tplan);
        if trem==0
        tc  = t;
        [alpha,beta] = Optimal_Trajectory5_plantest(psym,kp,tc,X0,zmax,theta_LO,dtheta_LO,vd,Lds);
        Tpoly = 0;
        kplan = kplan+1;
        end
        U_ref = feedforwardCtrl(Tpoly,alpha,beta,kp,psym);
        Tpoly = Tpoly+dt;
        %4th-order Runge-kutta algorithm
        K1    = WSLIPmodel_RK4(t,X0,U_ref,kp,psym);
        K2    = WSLIPmodel_RK4(t+dt/2,X0+dt*K1/2,U_ref,kp,psym);
        K3    = WSLIPmodel_RK4(t+dt/2,X0+dt*K2/2,U_ref,kp,psym);
        K4    = WSLIPmodel_RK4(t+dt,X0+dt*K3,U_ref,kp,psym);
        X1    = X0+dt/6*(K1+2*K2+2*K3+K4);
        dx    = 1/6*(K1+2*K2+2*K3+K4);
        %update
        X0    = X1;
        State(:,i)=X0;
        Control(:,i)=[U_ref(1);(m+mb)*g+m*dx(5)*cos(X0(3))-m*X0(2)*sin(X0(3))*dx(6)-2*m*X0(5)*sin(X0(3))*X0(6)-m*X0(2)*cos(X0(3))*X0(6)^2];
        i     = i+1;
        Time(:,j)=t;
        j=j+1;
        end
        Time(:,475)=0.9469;

