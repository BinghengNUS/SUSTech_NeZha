function [ps_ref,dps_ref,ddps_ref,ts_ref,dts_ref] = SLIPtrajectory_DF(psym,Llqr,dLlqr,theta,dtheta,flagjump,zmax,thetad) 
%This function returns the reference for task-space. In stance phase, the
%reference is for the base c.o.m. The reference of base c.o.m is optimized by a
%one-dimensional SLIP model online using quadratic programming. The wheel
%center reference is temporarily constant in {s}
%state=[x;y;z;roll;pitch;yaw;thetahl;thetakl;thetawl;thetahr;thetakr;thetawr]
%shanktilt=[theta0l;theta0r]
%psym  = [r,d,g,Lg,Ltcom,Lscom,dh,dhs,mfb,mtl,msl,mw,mur,mus];%system parameter vector
%*********************By Bingheng WANG, on Mar.8 2020*********************
    
%--------------------------------------------%
%Base c.o.m trajecotory based on a SLIP model
%--------------------------------------------%
%------------------%
%Parameters Setting
%------------------%
    g    = psym(3);
    m    = psym(8)+2*(psym(10)+psym(11)+psym(12));%total mass
    dt   = 0.001;%sampling time
    r    = psym(1);%radius of wheel
    Lg   = psym(4);%length of leg (Thigh link and Shank link)
    dh   = psym(7);%height of base c.o.m relative to the hip joint
    Ib   = 0.0249232975683053;
    It   = 0.022309557436881;
    Is   = 0.0177210394041728;
%---------------------------------------%
%Initial States and Desired Final States
%---------------------------------------%
    y10  = double(Llqr);
    dy10 = double(dLlqr);
    y20  = double(theta);
    dy20 = double(dtheta);
%calculate the desired final height and velocity
    if flagjump==0%no jump
        y1d  = 0.7+dh;
        y2d  = thetad;
        A    = [cos(y2d),-y1d*sin(y2d);
               (It-Is)/(Ib+2*(It+Is)*Lg*sin(acos(y1d/(2*Lg)))),-1];
        B    = [sqrt(2*g*(zmax-r-(y1d+dh)*cos(y2d)));0];
        xd   = A^(-1)*B;
        dy1d = sqrt(2*g*(zmax-r-(y1d+dh)*cos(y2d)))/cos(y2d);%xd(1);
        dy2d = 0;%xd(2);
        Yd   = double([y1d;dy1d;y2d;dy2d]);
    else%landing
        y1d  = 0.7+dh;
        y2d  = thetad;
        dy1d = 0;
        dy2d = 0;
        Yd   = double([y1d;dy1d;y2d;dy2d]);
    end
    timef    = 0.8;
    ps_ref   = zeros(1,timef/dt);
    dps_ref  = zeros(1,timef/dt);
    ddps_ref = zeros(1,timef/dt);
    ts_ref   = zeros(1,timef/dt);
    dts_ref  = zeros(1,timef/dt);
    k   = 1;
    J   = 0;
    Qf  = 100*eye(4);
    t   = timef;
 cvx_begin
    variable a(8,1);%coefficient of length
    variable b(8,1);%coefficient of angle 
    P0   = [1,t,t^2,t^3,t^4,t^5,t^6,t^7];
    P1   = [0,1,2*t,3*t^2,4*t^3,5*t^4,6*t^5,7*t^6];
    P    = [P0;P1];
    Phat = blkdiag(P,P);
    gamma= [a;b];    
    J    = J+(Phat*gamma-Yd).'*Qf*(Phat*gamma-Yd);%results are better with terminal cost only
    minimize(J)
    subject to
    [1,0,0,0,0,0,0,0]*a==y10;
    [0,1,0,0,0,0,0,0]*a==dy10;
    [1,0,0,0,0,0,0,0]*b==y20;
    [0,1,0,0,0,0,0,0]*b==dy20;
    cvx_end
    for t=0:dt:timef
        P0   = [1,t,t^2,t^3,t^4,t^5,t^6,t^7];
        P1   = [0,1,2*t,3*t^2,4*t^3,5*t^4,6*t^5,7*t^6];
        P2   = [0,0,2,6*t,12*t^2,20*t^3,30*t^4,42*t^5];
        y1   = P0*a;%pendulum length
        y2   = P0*b;%pendulum tilting angle
        dy1  = P1*a;
        dy2  = P1*b;
        ddy1 = P2*a;
        ps_ref(k)  = y1;
        dps_ref(k) = dy1;
        ddps_ref(k)= ddy1;
        ts_ref(k)  = y2;
        dts_ref(k) = dy2;
        k      = k+1;
    end