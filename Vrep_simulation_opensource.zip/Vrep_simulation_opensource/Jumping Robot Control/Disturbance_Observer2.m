function [D_joint,D_wip,dz_joint,dz_wip,dtanh_joint,dtanh_wip,Xi_j,Xi_w,M_theta,C_theta] = Disturbance_Observer2(K1j,K2j,K1w,K2w,torque,state,dstate,x,z_joint,z_wip,tanh_joint,tanh_wip,Llqr,psym)
%This function returns the estimated disturbance via super-twisting
%algorithm(STA). The disturbance consists of the dynamics coupling between
%joints and the nonlinearity that was ignored by linearization in LQR. The
%real-time estimation is guaranteed.
%psym  = [r,d,g,Lg,Ltcom,Lscom,dh,dhs,mfb,mtl,msl,mw,mur,mus];
%**************By Bingheng WANG, on Mar.30, 2020**************************
% Mhip        = 1/2*(mfb*dh^2+Iyyb);
% Mknee       = mtl*(Lg+Ltcom)^2+Iyyt;
%---STA-based disturbance estimation for joints---%
ep          = 100;%parameter in tanh function
Xi_j        = z_joint-[dstate(7);dstate(8);dstate(10);dstate(11)];%estimate error
D_jhL       = -K1j(1)*sqrt(abs(Xi_j(1)))*tanh(ep*Xi_j(1))-K2j(1)*tanh_joint(1);
D_jkL       = -K1j(2)*sqrt(abs(Xi_j(2)))*tanh(ep*Xi_j(2))-K2j(2)*tanh_joint(2);
D_jhR       = -K1j(3)*sqrt(abs(Xi_j(3)))*tanh(ep*Xi_j(3))-K2j(3)*tanh_joint(3);
D_jkR       = -K1j(4)*sqrt(abs(Xi_j(4)))*tanh(ep*Xi_j(4))-K2j(4)*tanh_joint(4);
D_joint     = [D_jhL;D_jkL;D_jhR;D_jkR];
dtanh_joint = [tanh(ep*Xi_j(1));tanh(ep*Xi_j(2));tanh(ep*Xi_j(3));tanh(ep*Xi_j(4))];
% Md          = diag([Mhip,Mknee,Mhip,Mknee]);
tau_joint   = [torque(1);torque(3);torque(2);torque(4)];
    %Rigid body modeling using Roy Featherstone package
    handle.NB = 5;
    handle.parent = [0 1 2 1 4];%left part first, then right part
    handle.jtype = {'Ry', 'Ry', 'Ry', 'Ry','Ry'};
    handle.Xtree{1} = eye(6);%from {s} to base frame {b} (at base c.o.m) 
    handle.Xtree{2} = xlt([0,0.0762,-psym(7)]);%Adjoint Matrix from {parent i} Link frame to {i}
    handle.Xtree{3} = xlt([0,0.0385,-psym(4)]);
    handle.Xtree{4} = xlt([0,-0.0762,-psym(7)]);%from {b} to hip joint frame {h}, expressed in {h}
    handle.Xtree{5} = xlt([0,-0.0385,-psym(4)]);
    mass = psym(9);%
    CoM = [0,0,0];
    Icm =  diag([0.0261376195979353,0.0249232975683053,0.0143828822217345]);
    handle.I{1} = mcI( mass, CoM, Icm );
    mass = psym(10);%Thigh link
    CoM = [0,0.0637001804791891,psym(5)];
    Icm =  diag([0.0223883715246182,0.022309557436881,0.00172727939342223]);
    handle.I{2} = mcI( mass, CoM, Icm );
    mass = psym(11);%Shank link
    CoM = [0,0.0364494458894979,psym(6)];
    Icm = diag([0.0175958448813304,0.0177210394041728,0.000378821101531682]);
    handle.I{3} = mcI( mass, CoM, Icm );
    mass = psym(10);%Thigh link
    CoM = [0,-0.0637001804791891,psym(5)];
    Icm =  diag([0.0223883715246182,0.022309557436881,0.00172727939342223]);
    handle.I{4} = mcI( mass, CoM, Icm );
    mass = psym(11);%Shank link
    CoM = [0,-0.036449445889498,psym(6)];
    Icm = diag([0.0175958448813304,0.0177210394041728,0.000378821101531682]);
    handle.I{5} = mcI( mass, CoM, Icm );
    states      = [state(1);state(2);state(3);state(4);state(5);state(6);state(7);state(8);state(10);state(11)];
    dstates     = [dstate(1);dstate(2);dstate(3);dstate(4);dstate(5);dstate(6);dstate(7);dstate(8);dstate(10);dstate(11)];
    handle_fb   = floatbase(handle);
    [Ms,Cs]     = HandC(handle_fb, states, dstates, []); 
    S_theta     = [zeros(6,4);eye(4)];
    M_st     = S_theta.'*Ms*S_theta;
    M_theta  = diag([M_st(1,1),M_st(2,2),M_st(3,3),M_st(4,4)]);
%     M_theta  = M_st;
    C_theta     = S_theta.'*Cs;
dz_joint    = M_theta^(-1)*tau_joint-M_theta^(-1)*C_theta+D_joint;
%---STA-based disturbance estimation for WIP---%
A   =[0,          0,     0,     1;
      -49539/925,    0,     0,     0;
      0,          0,     0,     0;
      58604/(925*Llqr),0,     0,     0];
B   =[0,                                                                     0;
      25/(37*Llqr) + 250/37,                             25/(37*Llqr) + 250/37;
      -17470/453,                                                    17470/453;
      -(50*(5055*Llqr + 598))/(37407*Llqr^2),-(50*(5055*Llqr + 598))/(37407*Llqr^2)];
Xi_w        = z_wip-[x(2);x(3);x(4)];%estimate error
Ar          = [A(2,1)*x(1);0;A(4,1)*x(1)];
Br          = [B(2,1),B(2,1);B(3,1),B(3,2);B(4,1),B(4,2)];
tau_wheel   = [torque(5);torque(6)];
d_wv        = -K1w(1)*sqrt(abs(Xi_w(1)))*tanh(ep*Xi_w(1))-K2w(1)*tanh_wip(1);
d_wp        = -K1w(2)*sqrt(abs(Xi_w(2)))*tanh(ep*Xi_w(2))-K2w(2)*tanh_wip(2);
d_wt        = -K1w(3)*sqrt(abs(Xi_w(3)))*tanh(ep*Xi_w(3))-K2w(3)*tanh_wip(3);
d_wip       = [d_wv;d_wp;d_wt];
dtanh_wip   = [tanh(ep*Xi_w(1));tanh(ep*Xi_w(2));tanh(ep*Xi_w(3))];
dz_wip      = Ar+Br*tau_wheel+d_wip;
D_wip       = pinv(Br)*d_wip;
