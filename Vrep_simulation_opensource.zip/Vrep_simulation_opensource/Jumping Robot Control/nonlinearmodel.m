function dxs = nonlinearmodel(t,xs,alphaDL,betax,g,m,mb,r,Ks,L0)
% xs = [length,theta,dlength,dtheta]
[P0,~,P2]=poly(t);
delL     = P0*alphaDL;
ddx      = P2*betax;

dlength  = xs(3);
dtheta   = xs(4);

M        = [m,0;
            r*m*sin(xs(2)),m*xs(1)^2+r*m*cos(xs(2))*xs(1)];
C        = [-m*xs(1)*xs(4)^2+m*g*cos(xs(2))-Ks*(L0-xs(1));
            (2*m*xs(1)+2*r*m*cos(xs(2)))*xs(3)*xs(4)-m*g*xs(1)*sin(xs(2))-m*r*sin(xs(2))*xs(1)*xs(4)^2];
S        = [-m*sin(xs(2)),Ks;
            -m*xs(1)*cos(xs(2))-r*(m+mb),0];
U        = [ddx;
            delL];
ddxs     = M^(-1)*(S*U-C);
dxs      = [dlength;dtheta;ddxs];