function [ps_ref,dps_ref,ddps_ref,pf_ref,dpf_ref,ddpf_ref] = TaskReference(orientation,wb,dwb,psym,zbL,zbR,dzbL,dzbR,pf,dpf,wheelzposition,vref,flagjump) 
%This function returns the reference for task-space. In stance phase, the
%reference is for the base c.o.m while in the flight phase the reference is
%for the wheel center in {b}. The reference of base c.o.m is optimized by a
%one-dimensional SLIP model online using quadratic programming. The wheel
%center reference is temporarily constant in {s}
%state=[x;y;z;roll;pitch;yaw;thetahl;thetakl;thetawl;thetahr;thetakr;thetawr]
%shanktilt=[theta0l;theta0r]
%psym  = [r,d,g,Lg,Ltcom,Lscom,dh,dhs,mfb,mtl,msl,mw,mu];%system parameter vector
%*********************By Bingheng WANG, on Mar.8 2020*********************
if wheelzposition<=0.102
    
%--------------------------------------------%
%Base c.o.m trajecotory based on a SLIP model
%--------------------------------------------%
%------------------%
%Parameters Setting
%------------------%
%     g    = psym(3);
%     m    = psym(8)+2*(psym(10)+psym(11)+psym(12));%total mass
%     kp   = 100;%proportional coefficient of knee torque
%     dt   = 0.002;%sampling time
%     r    = psym(1);%radius of wheel
%     Lg   = psym(4);%length of leg (Thigh link and Shank link)
%     dh   = psym(7);%height of base c.o.m relative to the hip joint
% %---------------------------------------%
% %Initial States and Desired Final States
% %---------------------------------------%
%     L0   = 2*Lg;%initial resting length of the spring excluding r and dh
%     z0   = 1/2*(zbL+zbR);%initial actual length of the spring including r and dh
%     dz0  = 1/2*(dzbL+dzbR);%initial velocity of actual length
%     Tf   = 1;%final time
% %calculate the desired final height and velocity
%     if flagjump==0%no jump
%         zdes = 1.2;%desired peak in flight
%         zf   = z0;%final height
%         dzf  = sqrt((zdes-zf)*2*g);%final velocity
%     else%landing
%         zf   = 0.9;
%         dzf  = 0;
%     end
% %-------------------%
% %Constraints Setting
% %-------------------%
%     Lmin = 0.2;
%     Lmax = 2*Lg;
%     Ksmax= 4*kp/(Lmin^2);
%     Ksmin= 4*kp/(Lmax^2);
%     zmin = Lmin+r+dh;
%     zmax = z0;
%     Z_L  = zmin*ones(Tf/dt,1);%lower bound vector
%     Z_U  = zmax*ones(Tf/dt,1);%upper bound vector
%     dzmin= -4;
%     dzmax= 2*dzf;
%     dZ_L = dzmin*ones(Tf/dt,1);
%     dZ_U = dzmax*ones(Tf/dt,1);
%     Ks   = 1/2*(Ksmax+Ksmin);%spring constant stiffness
%     umax = (L0+r-zmin)*(Ksmax-Ks)/Ks;
%     umin = (L0+r-zmin)*(Ksmin-Ks)/Ks;
%     U_L  = umin*ones(Tf/dt,1);
%     U_U  = umax*ones(Tf/dt,1);
%     cvx_begin
%         variable u(Tf/dt,1);%Stiffness
%     %------Initialization------%
%         z   = z0;
%         dz  = dz0;
%         i   = 1;
%         ps_ref   = cvx(zeros(Tf/dt,1));
%         dps_ref  = cvx(zeros(Tf/dt,1));
%         ddps_ref = cvx(zeros(Tf/dt,1));
%     %------Iteration of Dynamic Model------%
%     for t=dt:dt:Tf
%         s       = L0+r+dh+u(i)-z;%spring deformation
%         Fs      = Ks*s;%spring force 
%         ddz     = Fs/m-g;
%         %-----update-----%
%         dz      = dz+dt*ddz;
%         z       = z+dt*dz;
%         ps_ref(i,1)  = z;
%         dps_ref(i,1) = dz;
%         ddps_ref(i,1)= ddz;
%         i       = i+1;
%     end
%         J  =  1/2*[z-zf,dz-dzf]*[z-zf;dz-dzf];%final cost only, no running cost
%         minimize(J)
%         subject to
%     %-----State Constraint-----%
%         ps_ref <= Z_U;
%         ps_ref >= Z_L;
%         dps_ref<= dZ_U;
%         dps_ref>= dZ_L;
%     %-----Control Constraint-----%
%         u <= U_U;
%         u >= U_L;
%     cvx_end
    ps_ref  = 0.9;
    dps_ref =0;
    ddps_ref=0;
else
    rollb   = orientation(1);
    pitchb  = orientation(2);
    yawb    = orientation(3);
    Rs2b    = Rzyx(rollb,pitchb,yawb);
    pfds    = [0;0;-0.7];%desired wheel position w.r.t base c.o.m in {s}
    pfdd    = Rs2b*pfds;%transfered to {b}
    pf_ref  = [pfdd(1);pfdd(3);0;pfdd(1);pfdd(3);0];%desired x, z position of wheel in {b} and wheel joint angle
    dpfdd   = -skew(wb)*Rs2b*pfds;%desired velocity of wheel center in {b}
    dpf_ref = [dpfdd(1);dpfdd(3);vref/psym(1);dpfdd(1);dpfdd(3);vref/psym(1)];
    ddpfdd  = -skew(dwb)*Rs2b*pfds+skew(wb)^2*Rs2b*pfds;%desired acceleration of wheel center in {b}
    ddpf_ref= [ddpfdd(1);ddpfdd(3);0;ddpfdd(1);ddpfdd(3);0];
end