function [alpha_f,beta_f,L,z2,x2,Theta] = optimalfly(psym,Lds,dLlqr,theta,v,vzb,Llqr,vxb,dtheta,zmax,theta_LO,H_ob)
% Similar to the optimization in stance phase, this function takes two
% stpes to generate the trajectories in fly. First, plan the open-loop
% trajectories provided dtheta = 0 and the top mass m_1 follows a ballistic
% trajectory. Second, optimize the trajectory that respects the linear
% nonholonomic constraint based on the open-loop trajectory
%*********************By Bingheng WANG, on May 18, 2020********************
%------------------%
%Parameters Setting
%------------------%
Lg       = psym(4);%length of leg (Thigh link and Shank link)
g        = psym(3);
r        = psym(1);%radius of wheel
dh       = psym(7);%height of base c.o.m relative to the hip joint
L0       = 2*Lg+dh;
z1max    = zmax;
k1       = 4.5;%
k2       = 0.5;%reducing this value also leads to good results
kt       = 1;%time scaling
z2max    = zmax-H_ob+k1*r;
L_0      = Llqr;
theta_0  = theta;
dtheta_0 = dtheta;
vz1_0    = vzb;%sqrt(2*g*(z1max-L_0*cos(theta_0)-r));
dz2_0    = vzb;%this is a planned velocity bbut not the true measurement
dL_0     = dLlqr;%(sqrt(2*g*(zmax-L_0*cos(theta_0)-r))+L_0*sin(theta_0)*dtheta_0)/cos(theta_0);%(vz1_0-dz2_0+L_0*sin(theta_0)*dtheta_0)/cos(theta_0);
vx2_0    = v;
vx1_0    = vxb;%vx2_0+dL_0*sin(theta_0)+L_0*cos(theta_0)*dtheta_0;
T        = kt*2*vz1_0/g;
T_top    = T/2;

    %---A: z2 planning via QP---%
    %initialization
    x1_0   = L_0*sin(theta_0);
    z1_0   = L_0*cos(theta_0)+r;
    z2_0   = r;
    
    ddz2_0 = 0;
    %constraints
    z2_T   = r;
    dz2_T  = -vz1_0;
    ddz2_T = 0;
    x1_top = x1_0+T_top*vx1_0;
    x2_top = x1_top-(z1max-z2max)*tan(theta_LO*k2);
    %QP formulation
    Q1     = 1;
    [P0_0,P1_0,P2_0] = poly(0);
    [P0_T_top,P1_T_top,~] = poly(T_top);
    [P0_T,P1_T,P2_T] = poly(T);
    H1     = P0_T_top.'*Q1*P0_T_top+P1_T_top.'*Q1*P1_T_top;
    f1     = -P0_T_top.'*Q1*z2max;
    Aeq1   = [P0_0;P1_0;P2_0;P0_T;P1_T;P2_T];
    beq1   = [z2_0;dz2_0;ddz2_0;z2_T;dz2_T;ddz2_T];
    N      = 30;
    delt   = T/N;
    A1     = zeros(2*(N+1),10);
    b1     = zeros(2*(N+1),1);
    k      = 1;
    for t=0:delt:T
        dz1       = vz1_0-g*t;
        Z1        = z1_0+(dz1^2-vz1_0^2)/(-2*g);
        [P0,P1,P2]= poly(t);
        A1(k,:)   = P0;
        b1(k,:)   = Z1-H_ob+k1*r;
        A1(k+N+1,:)= -P0;
        b1(k+N+1,:)= -Z1+L0*cos(theta_LO);
        k         = k+1;
    end
    H1      = double(H1);
    f1      = double(f1);
    A1      = double(A1);
    b1      = double(b1);
    Aeq1    = double(Aeq1);
    beq1    = double(beq1);
    alphaz2 = quadprog(H1,f1,A1,b1,Aeq1,beq1);
  %---B: x2 planning via QP---%
    %initialization
    x2_0   = 0;
    dx2_0  = vx2_0;
    ddx2_0 = g*tan(theta_LO);
    %constraints
    x2_T   = T*vx1_0+x1_0;
    dx2_T  = vx1_0;%-(-vz1_0-dz2_T)*tan(theta_LO);
    ddx2_T = 0;
    %QP formulation
    Q2     = 1;
    H2     = P0_T_top.'*Q2*P0_T_top;
    f2     = -P0_T_top.'*Q2*x2_top;
    Aeq2   = [P0_0;P1_0;P2_0;P0_T;P1_T;P2_T];
    beq2   = [x2_0;dx2_0;ddx2_0;x2_T;dx2_T;ddx2_T];
    H2     = double(H2);
    f2     = double(f2);
    Aeq2   = double(Aeq2);
    beq2   = double(beq2);
    betax2 = quadprog(H2,f2,[],[],Aeq2,beq2);

 N      = 200;
 delt   = T/N;
 ts     = 0:delt:T;
 L      = zeros(size(ts,2),1);
 Theta  = zeros(size(ts,2),1);
 x2     = zeros(size(ts,2),1);
 z2     = zeros(size(ts,2),1);
 k      = 1;
 for t = 0:delt:T
     X1        = x1_0+vx1_0*t;
     dz1       = vz1_0-g*t;
     Z1        = z1_0+(dz1^2-vz1_0^2)/(-2*g);
     [P0,~,~]= poly(t);
     X2        = P0*betax2;
     x2(k)     = X2;
     Z2        = P0*alphaz2;
     z2(k)     = Z2;
     l         = sqrt((X1-X2)^2+(Z1-Z2)^2);
     theta_f   = acos((Z1-Z2)/l);
     L(k)      = l;
     Theta(k)  = theta_f;
     k         = k+1;
 end
    t = 0:delt:T;
    alphaL     = polyfit(t,L.',9);
    betat      = polyfit(t,Theta.',9);
    alpha_f    = alphaL.';
    beta_f     = betat.';