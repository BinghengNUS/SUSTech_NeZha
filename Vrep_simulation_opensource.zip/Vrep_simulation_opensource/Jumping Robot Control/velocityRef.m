function betadx = velocityRef(dt,Tstable,Lds,dh)
g  = 9.8;
  opts   = odeset('RelTol',1e-12,'AbsTol',1e-13);
  dx0    = 0;
  tspan  = [0:dt:Tstable];
  [t,dx]  = ode45(@(t,dx)acceleration3 (t,dx,g,Lds,dh,Tstable),tspan,dx0,opts);
  betadx = polyfit(t,dx,9);
  betadx = betadx.';