function tau = StanceJointTorquePD4_DOB(Ats,dAts,dstate,ddxtsc,torq_lqr,psym,D_joint,D_wip,M_theta,C_theta,torqueLimit)
%This function returns the joint torques needed for the robot base c.o.m to
%track the desired c.o.m trajectory. The control law is PD plus gravity
%compensation.
%psym  = [r,d,g,Lg,Ltcom,Lscom,dh,dhs,mfb,mtl,msl,mw,mur,mus];
%****************By Bingheng WANG, on Mar.19 2020*************************
dh       = psym(7);
Lg       = psym(4);
Ltcom    = psym(5);
mfb      = psym(9);
mtl      = psym(10);
% Iyyb     = 0.0249232975683053;
% Iyyt     = 0.022309557436881;
% Mhip     = 1/2*(mfb*dh^2+Iyyb);
% Mknee    = mtl*(Lg+Ltcom)^2+Iyyt;
% hiptorqL = Mhip*(ddxtsc(1)-D_joint(1));
% hiptorqR = Mhip*(ddxtsc(3)-D_joint(3));
% kneetorqL= Mknee*(ddxtsc(2)-D_joint(2));
% kneetorqR= Mknee*(ddxtsc(4)-D_joint(4));
 %---------------------------------%
    %Quadratic programming formulation
    %---------------------------------%
    dstates = [dstate(7);dstate(8);dstate(10);dstate(11)];
    Hs    = Ats.'*Ats;
    fs    = Ats.'*(dAts*dstates-ddxtsc);
    Hsqp  = blkdiag(Hs,zeros(4,4));
    fsqp  = [fs;zeros(4,1)];
    Aeqs  = [M_theta,-eye(4)];
    beqs  = -C_theta+M_theta*D_joint;%
    Hsqp  = double(Hsqp);
    fsqp  = double(fsqp);
    Aeqs  = double(Aeqs);
    beqs  = double(beqs);
    usmin   = -[torqueLimit(1);torqueLimit(3);torqueLimit(2);torqueLimit(4)];
    usmax   = [torqueLimit(1);torqueLimit(3);torqueLimit(2);torqueLimit(4)];
    lb    = [-Inf(4,1);usmin];
    ub    = [Inf(4,1);usmax];
    [slns,optC] = quadprog(Hsqp,fsqp,[],[],Aeqs,beqs,lb,ub);%hip, knee, followed by right side
    hiptorqL   = slns(5);
    kneetorqL  = slns(6);
    hiptorqR   = slns(7);
    kneetorqR  = slns(8);
% torqj = M_theta*(ddxtsc-D_joint)+C_theta;%
% hiptorqL = torqj(1);
% hiptorqR = torqj(3);
% kneetorqL= torqj(2);
% kneetorqR= torqj(4);
torqL = torq_lqr(1)-D_wip(1);
torqR = torq_lqr(2)-D_wip(2);
 tau = [hiptorqL;hiptorqR;kneetorqL;kneetorqR;torqL;torqR];