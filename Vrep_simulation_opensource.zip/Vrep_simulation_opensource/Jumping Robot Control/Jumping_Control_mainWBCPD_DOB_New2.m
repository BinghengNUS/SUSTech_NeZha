%*************************************************************************
%         Balance and Jumping Control for a Wheeled Bipedal Robot
%*********************By Bingheng WANG, May.07,2020***********************
%% Configuration codes
% Control inputs: two hip joint torques, two knee joint torques, two wheel
% joint torques.
% Control objective: In stance phase: make the c.o.m of base track the
% trajectory optimized online by the SLIP model; In flight phase, make the
% foot track the desired trajectories manually designed offline.
% Methdology: the control is achieved by task-space quadratic programming
% {s}: inertial frame
% {b}: body frame fixed on the floating base
% {f}: body frame fixed on the foot
clear all

jointNum=6;
torqueLimit=[50;50;50;50;5;5];
jointName=["LeftHip_joint","RightHip_joint","LeftKnee_joint","RightKnee_joint","LeftWheel_joint","RightWheel_joint"];  

displayOn=true;
torque=zeros(jointNum,1); 

%% Connect to the Vrep
% 1. load api library
vrep=remApi('remoteApi'); % using the prototype file (remoteApiProto.m)
% 2. close all the potential link
vrep.simxFinish(-1);   
% 3. wait for connecting vrep, detect every 0.2s
while true
    clientID=vrep.simxStart('127.0.0.1',19997,true,true,5000,5);
    if clientID>-1 
        break;
    else
        pause(0.2);
        disp('please run the simulation on vrep...')
    end
end
disp('Connection success!')
% 4. set the simulation time step
tstep = 0.001;  % 1ms per simulation pass
vrep.simxSetFloatingParameter(clientID,vrep.sim_floatparam_simulation_time_step,tstep,vrep.simx_opmode_oneshot);
% 5. open the synchronous mode to control the objects in vrep
vrep.simxSynchronous(clientID,true);

%% Simulation Initialization
vrep.simxStartSimulation(clientID,vrep.simx_opmode_oneshot);
% get the handles
jointHandle=zeros(jointNum,1); 
for i=1:jointNum  % handles of the left and right arms
    [~,returnHandle]=vrep.simxGetObjectHandle(clientID,char(jointName(i)),vrep.simx_opmode_blocking);
    jointHandle(i)=returnHandle;
end
% set the target velocity to 0.1 and torque to 0
for i=1:jointNum
    vrep.simxSetJointForce(clientID,jointHandle(i),0,vrep.simx_opmode_oneshot);
    vrep.simxSetJointTargetVelocity(clientID,jointHandle(i),0.1,vrep.simx_opmode_oneshot);
end
baseName='Body_link_visual';
wheelName='RightWheel_link_visual';
wheelleft='LeftWheel_link_visual';
Shankleft='LeftShank_link_visual';
Shankright='RightShank_link_visual';
LeftHip='LeftHip_joint';
RightHip='RightHip_joint';
[~,baseHandle]=vrep.simxGetObjectHandle(clientID,baseName,vrep.simx_opmode_blocking);  
[~,wheelHandle]=vrep.simxGetObjectHandle(clientID,wheelName,vrep.simx_opmode_blocking);  
[~,wheelleftHandle]=vrep.simxGetObjectHandle(clientID,wheelleft,vrep.simx_opmode_blocking);  
[~,ShankleftHandle]=vrep.simxGetObjectHandle(clientID,Shankleft,vrep.simx_opmode_blocking);  
[~,ShankrightHandle]=vrep.simxGetObjectHandle(clientID,Shankright,vrep.simx_opmode_blocking);  
[~,LeftHipHandle]=vrep.simxGetObjectHandle(clientID,LeftHip,vrep.simx_opmode_blocking);  
[~,RightHipHandle]=vrep.simxGetObjectHandle(clientID,RightHip,vrep.simx_opmode_blocking);  
vrep.simxSynchronousTrigger(clientID);
disp('Handles available!')
% first call to read the joints' configuration and end-effector pose, the mode is chosen to be simx_opmode_streaming
jointConfig=zeros(jointNum,1); 
% get current joint position
for i=1:jointNum
    [~,jpos]=vrep.simxGetJointPosition(clientID,jointHandle(i),vrep.simx_opmode_streaming); 
        jointConfig(i)=jpos;
end

% get simulation time
currCmdTime=vrep.simxGetLastCmdTime(clientID);

lastCmdTime=currCmdTime;
% jointConfig0=jointConfig;
% jointConfigLast=zeros(jointNum,1);
% jointConfigLast=jointConfig+[0;0;0;0;43.9823;43.9823;0;0];;
[~,baseposition0]=vrep.simxGetObjectPosition(clientID,baseHandle,-1,vrep.simx_opmode_streaming);% defined in inertial frame
[~,wheelposition0]=vrep.simxGetObjectPosition(clientID,wheelHandle,-1,vrep.simx_opmode_streaming);
[~,wheelleftposition0]=vrep.simxGetObjectPosition(clientID,wheelleftHandle,-1,vrep.simx_opmode_streaming);  
[~,Shankleftposition0]=vrep.simxGetObjectPosition(clientID,ShankleftHandle,-1,vrep.simx_opmode_streaming);  
[~,Shankrightposition0]=vrep.simxGetObjectPosition(clientID,ShankrightHandle,-1,vrep.simx_opmode_streaming);  
[~,baseorientation0]=vrep.simxGetObjectOrientation(clientID,baseHandle,-1,vrep.simx_opmode_streaming);% defined in inertial frame
[~,LeftHipposition0]=vrep.simxGetObjectPosition(clientID,LeftHipHandle,-1,vrep.simx_opmode_streaming);  
 pause(0.1)
 for i=1:jointNum
    [~,jpos]=vrep.simxGetJointPosition(clientID,jointHandle(i),vrep.simx_opmode_streaming); 
        jointConfig(i)=jpos;
end
[~,baseposition0]=vrep.simxGetObjectPosition(clientID,baseHandle,-1,vrep.simx_opmode_buffer);% defined in inertial frame
[~,wheelposition0]=vrep.simxGetObjectPosition(clientID,wheelHandle,-1,vrep.simx_opmode_buffer);
[~,wheelleftposition0]=vrep.simxGetObjectPosition(clientID,wheelleftHandle,-1,vrep.simx_opmode_buffer);  
[~,Shankleftposition0]=vrep.simxGetObjectPosition(clientID,ShankleftHandle,-1,vrep.simx_opmode_buffer);  
[~,Shankrightposition0]=vrep.simxGetObjectPosition(clientID,ShankrightHandle,-1,vrep.simx_opmode_buffer);  
[~,baseorientation0]=vrep.simxGetObjectOrientation(clientID,baseHandle,-1,vrep.simx_opmode_streaming);% defined in inertial frame
[~,LeftHipposition0]=vrep.simxGetObjectPosition(clientID,LeftHipHandle,-1,vrep.simx_opmode_streaming);  
% jointConfig=jointConfig;%+[0;0;0;0;43.9823;43.9823;0;0];
%-----------------%
%System Parameters
%-----------------%
r     = 0.1;%radius of wheel
d     = 0.175;%distance from the wheel to the center of body
g     = 9.8;
Lg    = 0.429;%length of Thighlink
Ltcom = -0.0894;%z position of Thigh_link C.O.M in link frame
Lscom = -0.29;%z position of Shank_link C.O.M in link frame
dh    = 0.0474;% height of C.O.M of the main body relative to the hip joint
dhs   = -2.003e-02;%height of C.O.M of the main body in shape frame of bounding box
mfb   = 3.83;%mass of the floating base
mtl   = 1.429;%mass of the thigh leg
msl   = 0.7;%mass of the shank leg
mw    = 0.74;%mass of the wheel
mur   = 0.0005;%rotational friction coefficient
mus   = 0.1;%static friction coefficient 
m     = mfb+2*mtl;
mb    = 2*(msl+mw);%mass of shank link and wheel
psym  = [r,d,g,Lg,Ltcom,Lscom,dh,dhs,mfb,mtl,msl,mw,mur,mus];%system parameter vector
%--------------%
%Initial states
%--------------%
jointLAST = jointConfig;
dqLast    = zeros(6,1);
rollb0    = baseorientation0(1);
pitchb0   = baseorientation0(2);
yawb0     = baseorientation0(3);
Rs2b0     = Rzyx(rollb0,pitchb0,yawb0);
bposition0= baseposition0.'+Rs2b0.'*[6.285e-03;2.496e-07;dhs];
state0 = [bposition0;baseorientation0.';jointLAST(1);jointLAST(3);jointLAST(5);jointLAST(2);jointLAST(4);jointLAST(6)];
dstate0= zeros(12,1);
bpositionLast    = bposition0;
orientationLast  = baseorientation0.';
deulerLast       = zeros(3,1);
wbLast           = zeros(3,1);
deltawheel0      = wheelposition0-wheelleftposition0;
yaw0 = atan(deltawheel0(1)/deltawheel0(2));% yaw angle of the whole robot
deltaposition0 = bposition0-wheelposition0.'; % relative position between base and left wheel in {S}
deltap_b0      = Rotzs2b(yaw0)*deltaposition0;
theta0         = atan(deltap_b0(1)/(deltap_b0(3)));
dtheta0        = 0;
deltap_b0 = Rotzs2b(yaw0)*deltaposition0;
LlqrLast  = sqrt((deltap_b0(1))^2+(deltap_b0(3))^2);
thetaLast = atan(deltap_b0(1)/(deltap_b0(3)));
dthetaLast= 0;
dyaw0     = 0;
positionswleft0 =Shankleftposition0-wheelleftposition0;
positionswright0=Shankrightposition0-wheelposition0;
wheelLx0         = wheelleftposition0(1);
wheelLy0         = wheelleftposition0(2);
wheelRx0         = wheelposition0(1);
wheelRy0         = wheelposition0(2);
wheelRz0         = wheelposition0(3);
wheelLxLast      = wheelLx0;
wheelLyLast      = wheelLy0;
wheelRxLast      = wheelRx0;
wheelRyLast      = wheelRy0;
wheelzpositionLast = wheelRz0;
pwleft0_b = Rotzs2b(yaw0)*positionswleft0.';
pwright0_b= Rotzs2b(yaw0)*positionswright0.';
yawLast   = yaw0;
theta0l0    = atan(pwleft0_b(1)/pwleft0_b(3));%tilting angle of Shankleft
theta0r0    = atan(pwright0_b(1)/pwright0_b(3));%tilting angle of Shankright
theta0lLast = theta0l0;
theta0rLast = theta0r0;
shanktilt0  = [theta0lLast;theta0rLast];
dtheta0lLast= 0;
dtheta0rLast= 0;
dshanktilt0 = [dtheta0lLast;dtheta0rLast];
thetas0     = theta0l0-theta0;%tilting angle of {s} w.r.t {p}
vLast       = 0;
[Ats0,AtF,Gs0,ps,dps,Atf0,pf,dpf] = TaskSpacePD(state0,dstate0,thetas0,psym);
GsLast      = Gs0;
AtsLast     = Ats0;
AtfLast     = Atf0;
vrep.simxSynchronousTrigger(clientID);         % every calls this function, verp is triggered, 50ms by default

%% Simulation Start
t=0;  % start the simulation
k=1;
kfly     = 1;
kstance  = 1;
kLanding = 1;
H_ob     = 0.5;
Lds      = 0.72;%desired length between wheel center and base CoM
L0       = 2*Lg+dh;
Tstable    = 1.55;
theta_LO   = 20/180*pi;%desired landing attitude
f_plan     = 100;%frequency of planning 1 Hz
f_planland = 100;
kj         = 0;
%Parameters for LQR
Q        = diag([1,1,1,1]);
R        = diag([0.2,0.2]);
vd       = 1;
dyaw_ref = 0;
zmax     = L0+H_ob+r;%maximum height of jump
%Parameters of state machine
  %stance phase
  kph    = 350;%500
  kpk    = 400;%500
  Kps    = diag([kph,kpk,kph,kpk]);
  kdh    = 280;%280,300
  kdk    = 300;%280,350
  Kds    = diag([kdh,kdk,kdh,kdk]);
  %flight phase 
  kpx    = 250;%300,unstable oscillation is caused by small damping coefficients
  kpz    = 250;
  kpw    = 0;%no control for wheel joint angle
  Kpf    = diag([kpx,kpz,kpw,kpx,kpz,kpw]);
  kdx    = 250;%210
  kdz    = 250;
  kdw    = 10;
  Kdf    = diag([kdx,kdz,kdw,kdx,kdz,kdw]);
%spring stiffness
thekmin  = -130/180*pi;
thekmax  = -60/180*pi;
Lmin     = -Lg*sin(thekmax/2);
Lmax     = -Lg*sin(thekmin/2);
kp       = 50;
Ksmax    = kp/(Lmin^2);
Ksmin    = kp/(Lmax^2);
Ks       = 1/2*(Ksmax+Ksmin);
Ts       = 2*pi*sqrt(m/Ks);%estimate of the spring period
%Parameters of disturbance observer
  K1j    = [10;80;10;80];%[7;80;7;80];for diagonal mass matrix
  K2j    = [50;90;50;90];%%1zeros(4,1);[50;90;50;90]for diagonal mass matrix
  K1w    = [15;50;15];%zeros(3,1);
  K2w    = [2;2;2];%%1zeros(3,1);
flagjump = 0;%no jump, 1 for a jump that already happened
flagland = 0;%no landing 
z_joint  = [dstate0(7);dstate0(8);dstate0(10);dstate0(11)];
z_wip    = [vLast;dyaw0;dtheta0];
tanh_joint = zeros(4,1);
tanh_wip   = zeros(3,1);

%time setting for trajectory polynomial
T_poly = 0;
while (vrep.simxGetConnectionId(clientID) ~= -1)  % vrep connection is still active
    % time update
%   vrep.simxSetJointPosition(clientID,LeftHipHandle,tbased,vrep.simx_opmode_oneshot);
%   vrep.simxSetJointPosition(clientID,RightHipHandle,tbased,vrep.simx_opmode_oneshot);
    currCmdTime=vrep.simxGetLastCmdTime(clientID);
    dt=(currCmdTime-lastCmdTime)/1000;              % simulation step, unit: s 
    % read the joints' and tips' configuration (position and velocity)
    for i=1:jointNum
        [~,jpos]=vrep.simxGetJointPosition(clientID,jointHandle(i),vrep.simx_opmode_buffer);     
               jointConfig(i)=jpos;
    end
    %---------------------------%
    %System variables processing
    %---------------------------%
    gapl  = jointLAST(5)-jointConfig(5);
    gapr  = jointLAST(6)-jointConfig(6);
    if gapl<=-42
        Gapl=0;
    else
        Gapl=gapl;
    end
    if gapr<=-42
        Gapr=0;
    else
        Gapr=gapr;
    end
    
    if Gapl>=6 %remove the gap between two wheel angles, moving forward
        jointConfig(5)=jointConfig(5)+round(abs(Gapl)/(2*pi))*2*pi;
    end
    if Gapr>=6
        jointConfig(6)=jointConfig(6)+round(abs(Gapr)/(2*pi))*2*pi;
    end
    if Gapl<=-6 %remove the gap between two wheel angles, moving backward
        jointConfig(5)=jointConfig(5)-round(abs(Gapl)/(2*pi))*2*pi;
    end
    if Gapr<=-6
        jointConfig(6)=jointConfig(6)-round(abs(Gapr)/(2*pi))*2*pi;
    end
    Jointangle(:,k)=jointConfig;
    q=jointConfig;
    dQ=(q-jointLAST)./dt;  % column vector
    if k==1
        dq=zeros(jointNum,1);
    else
       if norm(dQ(1),2)>=2e2%avoid dQ being very large
        dq=zeros(jointNum,1);
       else
        dq=dQ;
       end 
    end
    
    Qdot(:,k)=dq;
    ddq = (dq-dqLast)/dt;%acceleration of joint variables
%     jointConfig=jointConfig;%+[0;0;0;0;43.9823;43.9823;0;0];
    [~,baseposition]=vrep.simxGetObjectPosition(clientID,baseHandle,-1,vrep.simx_opmode_buffer);% defined in inertial frame
    [~,wheelposition]=vrep.simxGetObjectPosition(clientID,wheelHandle,-1,vrep.simx_opmode_buffer);
    [~,wheelleftposition]=vrep.simxGetObjectPosition(clientID,wheelleftHandle,-1,vrep.simx_opmode_buffer);  
    [~,Shankleftposition]=vrep.simxGetObjectPosition(clientID,ShankleftHandle,-1,vrep.simx_opmode_buffer);  
    [~,Shankrightposition]=vrep.simxGetObjectPosition(clientID,ShankrightHandle,-1,vrep.simx_opmode_buffer);  
    [~,baseorientation]=vrep.simxGetObjectOrientation(clientID,baseHandle,-1,vrep.simx_opmode_streaming);% defined in inertial frame
    [~,LeftHipposition]=vrep.simxGetObjectPosition(clientID,LeftHipHandle,-1,vrep.simx_opmode_streaming);  
    [~,RightHipposition]=vrep.simxGetObjectPosition(clientID,RightHipHandle,-1,vrep.simx_opmode_streaming);  
    rollb     = baseorientation(1);
    pitchb    = baseorientation(2);
    yawb      = baseorientation(3);
    Rs2b      = Rzyx(rollb,pitchb,yawb);
    bposition = baseposition.'+Rs2b.'*[6.285e-03;2.496e-07;dhs];
    state     = [bposition;baseorientation.';q(1);q(3);q(5);q(2);q(4);q(6)];
    vbase     = (bposition-bpositionLast)./dt;
    dEuler    = (baseorientation.'-orientationLast)./dt;
    if k==1
        deuler=zeros(3,1);
    else
        deuler=dEuler;
    end
    ddeuler   = (deuler-deulerLast)./dt;
    dstate    = [vbase;deuler;dq(1);dq(3);dq(5);dq(2);dq(4);dq(6)];
    deltawheel= wheelposition-wheelleftposition;
%     yaw       = atan(deltawheel(1)/deltawheel(2));% yaw angle of the whole robot
    yaw       = psym(1)*(q(6)-q(5))/(2*psym(2));
    Yaw(k)    = yaw;
%     dyaw      = (yaw-yawLast)./dt;

    % attitude of the base 
    Orientation(:,k)=[baseorientation(1);baseorientation(2);baseorientation(3)];
    % tilt angle of the pendulum
    Wheelzposition(k)    = wheelposition(3);
    wheelzposition       = wheelposition(3);
    Wheelzleftposition(k)= wheelleftposition(3);
    deltaposition  = bposition-wheelposition.'; % position of pendulum relative to the wheel
    deltap_b       = Rotzs2b(yaw)*deltaposition;
    Llqr           = sqrt((deltap_b(1))^2+(deltap_b(3))^2);%length of the pendulum
    LLqr(k)        = Llqr;
    vzb            = vbase(3);
    theta          = atan(deltap_b(1)/(deltap_b(3)));
    Tiltangle(k)   = theta;
    dtheta         = (theta-thetaLast)/dt;
    ddtheta        = (dtheta-dthetaLast)/dt;
    vzw            = (wheelzposition-wheelzpositionLast)./dt;
    if wheelzposition<=0.104 && wheelzpositionLast<=0.104
        dLlqr          = (vzb+Llqr*sin(theta)*dtheta)/cos(theta);%(Llqr-LlqrLast)/dt;
    else
        dLlqr          = (vzb-vzw+Llqr*sin(theta)*dtheta)/cos(theta);%(Llqr-LlqrLast)/dt
    end 
    DLLqr(k)       = dLlqr;
    positionswleft = Shankleftposition-wheelleftposition;
    positionswright= Shankrightposition-wheelposition;
    wheelLx        = wheelleftposition(1);
    wheelLy        = wheelleftposition(2);
    wheelRx        = wheelposition(1);
    wheelRy        = wheelposition(2);
    vwLx           = (wheelLx-wheelLxLast)./dt;
    vwLy           = (wheelLy-wheelLyLast)./dt;
    vwL            = sqrt(vwLx^2+vwLy^2);
    vwRx           = (wheelRx-wheelRxLast)./dt;
    vwRy           = (wheelRy-wheelRyLast)./dt;
    vwR            = sqrt(vwRx^2+vwRy^2);
    v              = (vwLx*cos(yaw)+vwLy*sin(yaw)+vwRx*cos(yaw)+vwRy*sin(yaw))/2;
    dv             = (v-vLast)/dt;
    dyaw           = r*(dq(6)-dq(5))/(2*d);%+dtheta0R-dtheta0L
    Vfw(k) = v;
    pwleft_b       = Rotzs2b(yaw)*positionswleft.';
    pwright_b      = Rotzs2b(yaw)*positionswright.';
    theta0l        = atan(pwleft_b(1)/pwleft_b(3));%tilting angle of Shankleft
    theta0r        = atan(pwright_b(1)/pwright_b(3));%tilting angle of Shankright
    thetas         = theta0l-theta;%tilting angle of {s} w.r.t {p}
    shanktilt      = [theta0l;theta0r];
    dtheta0L       = (theta0l-theta0lLast)/dt;
    dtheta0R       = (theta0r-theta0rLast)/dt;
    dthetas        = dtheta0L-dtheta;
    dshanktilt     = [dtheta0L;dtheta0R];
    ddtheta0l      = (dtheta0L-dtheta0lLast)/dt;
    ddtheta0r      = (dtheta0R-dtheta0rLast)/dt;
    ddshanktilt    = [ddtheta0l;ddtheta0r];
    
    %----------------------%
    %Task-space formulation
    %----------------------%
    [Ats,AtF,Gs,ps,dps,Atf,pf,dpf] = TaskSpacePD(state,dstate,thetas,psym);
    dGs    = (Gs-GsLast)./dt;
    dAts   = (Ats-AtsLast)./dt;
    dAtf   = (Atf-AtfLast)./dt;
    
    %--------------%
    %Task reference
    %--------------%
    drollb  = deuler(1);
    dpitchb = deuler(2);
    [T_e2w,dT_e2w] = Te2w(rollb,pitchb,drollb,dpitchb);
    wb     = T_e2w*deuler;%angular velocity of base in {b}
    dwb    = dT_e2w*deuler+T_e2w*ddeuler;

    if wheelzposition<=0.104 && wheelzpositionLast<=0.104
       if t<Tstable
           bs_ref    = Lds;
           dbs_ref   = 0;
           ddbs_ref  = 0;
           v_ref     = vd;
           dx        = 2*mtl*Ltcom*sin((q(1)+q(2))/2)/(2*mtl+mfb);%offset in x axis of c.o.m of base and thigh legs
           the_off   = atan(-dx/Llqr);
           theta_ref = the_off;%atan(-dx/Llqr);
           dtheta_ref= 0;
           F_ref     = 0;%feedforward force
       else
           Time_plan = 1/f_plan;%period of planning
           Time_rem  = rem(t,Time_plan);
           Time_planland=1/f_planland;%period of landing planning
           Time_remland = rem(t,Time_planland);
           %---Planning for thrust phase---%
           if kstance<=1%plan for the first time
               tc = t-Tstable;%time that has been spent on planning
               [alpha,beta,betadx] = Optimal_Trajectory(psym,kp,tc,Llqr...
                   ,dLlqr,theta,dtheta,v,dv,flagjump,zmax,theta_LO,vd,Lds,torqueLimit,the_off);
               T_poly = 0;
           elseif flagjump == 0
               if Time_rem == 0
                   tc = t-Tstable;%time that has been spent on planning
                   [alpha,beta,betadx] = Optimal_Trajectory(psym,kp,tc,Llqr...
                       ,dLlqr,theta,dtheta,v,dv,flagjump,zmax,theta_LO,vd,Lds,torqueLimit,the_off);
                   T_poly = 0;
               end
           end
           %---Planning for landing phase---%
           
           if flagjump == 1 && flagland == 0 
               T_land = t;
               tc     = t-T_land;
               [alpha,beta,betadx] = Optimal_Trajectory(psym,kp,tc,Llqr...
                   ,dLlqr,theta,dtheta,v,dv,flagjump,zmax,theta_LO,vd,Lds,torqueLimit,the_off);
               flagland = 1;
               T_poly = 0;
               %update the stats of disturbance observer
               z_joint  = [dstate(7);dstate(8);dstate(10);dstate(11)];
               z_wip    = [v;dyaw;dtheta];
               tanh_joint = zeros(4,1);
               tanh_wip   = zeros(3,1);
           elseif flagland == 1 %&& t>=T_land+Ts
               if t<=T_land+1*Ts
                   if Time_remland == 0
                       tc = t-T_land;%time that has been spent on planning
                       [alpha,beta,betadx] = Optimal_Trajectory(psym,kp,tc,Llqr...
                           ,dLlqr,theta,dtheta,v,dv,flagjump,zmax,theta_LO,vd,Lds,torqueLimit,the_off);
                       T_poly = 0;
                   end
               else
%                elseif flagland == 1 && t>=T_land+1.5*Ts
                   alpha = [0;0;0;0;0;0;0;0;0;Lds+dh];
                   beta  = zeros(10,1);
                   betadx= [0;0;0;0;0;0;0;0;0;vd];
                   T_poly = 0;
               end
           end
           
           %polynomial trajectories in stance
           [P1,P2,P3] = poly(T_poly);
           L_ref      = P1*alpha;
           bs_ref     = L_ref-dh;
           LT_jref(kstance)=bs_ref;
           LT_ref(kLanding)=bs_ref;
           dbs_ref    = P2*alpha;
           ddbs_ref   = P3*alpha;
           v_ref      = P1*betadx;
           V_REF(kstance) = v_ref;
           V_REFL(kLanding) = v_ref;
           theta_ref  = P1*beta;
           dtheta_ref = P2*beta;
           ddtheta_ref= P3*beta;
           ddx_ref    = -(L_ref*ddtheta_ref+2*dbs_ref*dtheta_ref-g*sin(theta_ref))/cos(theta_ref);
           F_ref      = (m+mb)*ddx_ref+m*sin(theta_ref)*ddbs_ref+m*cos(theta_ref)*L_ref*ddtheta_ref...
               +2*m*cos(theta_ref)*dbs_ref*dtheta_ref-m*sin(theta_ref)*L_ref*dtheta_ref^2;
           T_poly     = T_poly+dt;
       end
          
    else%reference in flight calculated online
        [pf_ref,dpf_ref,ddpf_ref] = FlightTaskReference_DF2(baseorientation,wb,dwb,psym,v_ref,Lds,theta_LO); 
        Pf_ref(:,kfly)  = pf_ref;
        dPf_ref(:,kfly) = dpf_ref;
        ddPf_ref(:,kfly)= ddpf_ref;
        kfly = kfly+1;
    end
    
    %-------------------------------%
    %Behavior specific state machine
    %-------------------------------%
    if wheelzposition<=0.104 && wheelzpositionLast<=0.104
       [ddhkd,dhkd,hkd,thehd,thekd]=desiredangle2_DF(bs_ref,dbs_ref,ddbs_ref,Lg);
        ps_ref  = [hkd;hkd];%hkd:hip angle, followed by knee angle
        dps_ref = [dhkd;dhkd];
        ddps_ref= [ddhkd;ddhkd];
        Thehd(kstance)=thehd;
        ddxtsc = StanceStateMachine(ps_ref,dps_ref,ddps_ref,ps,dps,Kps,Kds);
    else
        ddxtfc = FlightStateMachine(pf_ref,dpf_ref,ddpf_ref,pf,dpf,Kpf,Kdf);
    end
    
    %---------------------------%
    %Control in different phases
    %---------------------------%
    %States for LQR
%     v      = r/2*(dq(5)+dq(6));%forward velocity+dtheta0L+dtheta0R   
    Yawrate(k)= dyaw;
    xlqr      = [theta;v;dyaw;dtheta];
    xref      = [theta_ref;v_ref;dyaw_ref;dtheta_ref];
    K         = LQRcontrol_New(dh,bs_ref,theta_ref,dtheta_ref,v_ref,F_ref,Q,R);
    deltorq   = -K*(xlqr-xref);%additional control torque obtained by LQR for wheel motors 
    torq_lqr  = [F_ref/2*r;F_ref/2*r]+deltorq;
     if wheelzposition<=0.104 && wheelzpositionLast<=0.104
         [D_joint,D_wip,dz_joint,dz_wip,dtanh_joint,dtanh_wip,Xi_j,Xi_w,Md,Gd] = Disturbance_ObserverWBCPD2(K1j...
             ,K2j,K1w,K2w,torque,state,dstate,xlqr,z_joint,z_wip,tanh_joint,tanh_wip,Llqr,pitchb,psym);
         z_joint    = z_joint+dt*dz_joint;
         z_wip      = z_wip+dt*dz_wip;
         tanh_joint = tanh_joint+dt*dtanh_joint;
         tanh_wip   = tanh_wip+dt*dtanh_wip;
         D_J(:,k)   = D_joint;
         D_W(:,k)   = D_wip;
         XI_J(:,k)  = Xi_j;
         XI_W(:,k)  = Xi_w;
         torque = StanceJointTorqueWBCPD4_DOB(Ats,dAts,dstate,ddxtsc,torq_lqr,D_joint,D_wip,Md,Gd,torqueLimit);
         if flagjump == 0 && t>Tstable
             kstance= kstance+1;
         elseif flagjump == 1
             kLanding  = kLanding+1;
         end
     else
         torque = FlightJointTorques(Atf,dAtf,state,dstate,ddxtfc,psym,torqueLimit);
         if t>Tstable+Ts
             flagjump = 1;
             if flagjump == 1&& kj ==0
                 theta_LO = theta;
                 kj = 1;
             end
         else
             flagjump = 0;
         end
     end
     k=k+1;
     
    %   3.3 set the torque in vrep way
    for i=1:jointNum
        if sign(torque(i))<0
            setVel=-9999; % set a trememdous large velocity for the screwy operation 
            if torque(i)<-torqueLimit(i)
                setTu=-torqueLimit(i);
            else
                setTu=-torque(i);
            end
        else
            setVel=9999;
            if torque(i)>torqueLimit(i)
                setTu=torqueLimit(i);
            else
                setTu=torque(i);
            end
        end
        vrep.simxSetJointTargetVelocity(clientID,jointHandle(i),setVel,vrep.simx_opmode_oneshot);
        vrep.simxSetJointForce(clientID,jointHandle(i),setTu,vrep.simx_opmode_oneshot);
        Torque(i,k)=setTu; 
    end

    % 4. update vrep(the server side)
    lastCmdTime     = currCmdTime;
    jointLAST       = jointConfig;   
    bpositionLast   = bposition;
    orientationLast = baseorientation.';
    deulerLast      = deuler;
    wbLast          = wb;
    vLast           = v;
    thetaLast       = theta;
    dthetaLast      = dtheta;
    yawLast         = yaw;
    dqLast          = dq;
    dtheta0lLast    = dtheta0L;
    dtheta0rLast    = dtheta0R;
    LlqrLast        = Llqr;
    vbaseLast       = vbase;
    GsLast          = Gs;
    AtsLast         = Ats;
    AtfLast         = Atf;
    wheelLxLast     = wheelLx;
    wheelLyLast     = wheelLy;
    wheelRxLast     = wheelRx;
    wheelRyLast     = wheelRy;
    wheelzpositionLast = wheelzposition;
    vrep.simxSynchronousTrigger(clientID);
    t=t+dt; % updata simulation time
    Time(k)=t;
end
vrep.simxFinish(-1);  % close the link
vrep.delete();        % destroy the 'vrep' class

%%
% figure(1); hold off;
% subplot(411); plot(E(1,:),'r'); hold on; plot(E(2,:),'b'); title('error')
% subplot(412); plot(Q(1,:),'r'); hold on; plot(Q(2,:),'b');  plot(QD(1,:),'k'); hold on; plot(QD(2,:),'k'); title('trajectory')
% subplot(413); plot(DQ(1,:),'r'); hold on; plot(DQ(2,:),'b');  plot(DQD(1,:),'k'); hold on; plot(DQD(2,:),'k'); title('velocity')
% subplot(414); plot(TAU(1,:),'r'); hold on; plot(TAU(2,:),'b'); title('torque')

