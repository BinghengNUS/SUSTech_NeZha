function [Ats,Jc,ps,dps,Atf,pf,dpf] = TaskSpace(state,dstate,baseorientation,yaw,psym)
%This function returns the matrices needed for task-space formulation given
%the system states,e.g. dot x_t = At*dot q
%state=[x;y;z;roll;pitch;yaw;thetahl;thetakl;thetawl;thetahr;thetakr;thetawr]
%shanktilt=[theta0l;theta0r]
%psym  = [r,d,g,Lg,Ltcom,Lscom,dh,dhs,mfb,mtl,msl,mu];%system parameter vector
%****************By Bingheng WANG, on Mar.8.2020**************************
%-----------------------------------------------------------------------%
%Stance phase, wheel center is the task-space, space frame is body frame
%Difference: wheel frame is not needed
%states =[baseposition;orientation;thetahipL;thetakneeL;thetahipR;thetakneeR]
%-----------------------------------------------------------------------%
      MsL         = [1,0,0,0;
                     0,1,0,psym(2);
                     0,0,1,-2*psym(4)-psym(7);
                     0,0,0,1];%the home configuration (position and orientation) of end-effector frame {e} in {b}
      MsR         = [1,0,0,0;
                     0,1,0,-psym(2);
                     0,0,1,-2*psym(4)-psym(7);
                     0,0,0,1];
      Slists      = [[0;1;0;psym(7);0;0],[0;1;0;psym(4)+psym(7);0;0],[0;1;0;2*psym(4)+psym(7);0;0]];
      thetalistsL = [state(7);state(8)];
      thetalistsR = [state(10);state(11)];
      TsL         = FKinSpace(MsL, Slists, thetalistsL);%left side
      [RsL, psL]  = TransToRp(TsL);%rotation matrix from {e} to {b} and position of {e} in {b}
      TsR         = FKinSpace(MsR, Slists, thetalistsR);%right side
      [RsR, psR]  = TransToRp(TsR);%rotation matrix from {e} to {b} and position of {e} in {b}
      JssL        = JacobianSpace(Slists, thetalistsL);%velocity Jacobian in {b}
      JssR        = JacobianSpace(Slists, thetalistsR);%right side
      TsLinv      = TransInv(TsL);
      TsRinv      = TransInv(TsR);
      Xb2eL       = Adjoint(TsLinv);%adjoint matrix of Tinv
      Xb2eR       = Adjoint(TsRinv);
      JbsL        = Xb2eL*JssL;%left body Jacobian
      JbsR        = Xb2eR*JssR;
      Selects     = [zeros(3,3),eye(3)];
      JshkL       = RsL*Selects*JbsL;%Jacobian matrix mapping dthetalistsL to velocity in {b}
      JshkR       = RsR*Selects*JbsR;
      JevL        = [ 0,sin(state(4))*psL(2)+cos(state(4))*psL(3),cos(state(5))*sin(state(1))*psL(3)-cos(state(5))*cos(state(4))*psL(2);
                     -psL(3),-sin(state(4))*psL(1), cos(state(5))*cos(state(4))*psL(1)+sin(state(5))*psL(3);
                      psL(2),-cos(state(4))*psL(1),-cos(state(5))*sin(state(4))*psL(1)-sin(state(5))*psL(2)];
      JevR        = [ 0,sin(state(4))*psR(2)+cos(state(4))*psR(3),cos(state(5))*sin(state(1))*psR(3)-cos(state(5))*cos(state(4))*psR(2);
                     -psR(3),-sin(state(4))*psR(1), cos(state(5))*cos(state(4))*psR(1)+sin(state(5))*psR(3);
                      psR(2),-cos(state(4))*psR(1),-cos(state(5))*sin(state(4))*psR(1)-sin(state(5))*psR(2)];            
      rollb       = baseorientation(1);
      pitchb      = baseorientation(2);
      yawb        = baseorientation(3);
      Rs2b        = Rzyx(rollb,pitchb,yawb);            
      JwcL        = [eye(3),Rs2b.'*JevL,Rs2b.'*JshkL,zeros(3,2)];
      JwcR        = [eye(3),Rs2b.'*JevR,zeros(3,2),Rs2b.'*JshkR];
      Ats         = [0,0,1,zeros(1,7);
                     zeros(3,3),eye(3),zeros(3,4)];%task-space matrix abstracting z and attitude in qs
      ps          = [state(3);state(4);state(5);state(6)];
      dps         = [dstate(3);dstate(4);dstate(5);dstate(6)];
      %Nonholonomic constraints formulation
      Jc          = [JwcL(3,:);
                     JwcR(3,:);
                     JwcL(2,:)*cos(yaw)-JwcL(1,:)*sin(yaw);
                     JwcR(2,:)*cos(yaw)-JwcR(1,:)*sin(yaw);
                     (JwcR(1,:)-JwcL(1,:))*cos(yaw)+(JwcR(2,:)-JwcL(2,:))*sin(yaw)];
%-----------------------------------------------------------------------%
%Flight phase, wheel center is the task-space, space frame is body frame
%statef = [baseposition;orientation;thetahipL;thetakneeL;thetawL;thetahipR;thetakneeR;thetawR]
%-----------------------------------------------------------------------%
      Mf          = [1,0,0,0;
                     0,1,0,0;
                     0,0,1,-2*psym(4)-psym(7);
                     0,0,0,1];%the home configuration (position and orientation) of wheel frame in {b}
      Slistf      = [[0;1;0;psym(7);0;0],[0;1;0;psym(4)+psym(7);0;0],[0;1;0;2*psym(4)+psym(7);0;0]];
      thetalistfL = [state(7);state(8);state(9)];%hip, knee and wheel joint angles
      thetalistfR = [state(10);state(11);state(12)];
      TfL         = FKinSpace(Mf, Slistf, thetalistfL);%left side
      [RfL, pfL]  = TransToRp(TfL);%rotation matrix from {w} to {b} and position of {w} in {b}
      TfR         = FKinSpace(Mf, Slistf, thetalistfR);%right side
      [RfR, pfR]  = TransToRp(TfR);
      pf          = [pfL(1);pfL(3);state(9);pfR(1);pfR(3);state(12)];
      JsfL        = JacobianSpace(Slistf, thetalistfL);%velocity Jacobian in {b}
      JsfR        = JacobianSpace(Slistf, thetalistfR);%right side
      TfLinv      = TransInv(TfL);
      TfRinv      = TransInv(TfR);
      Xb2wL       = Adjoint(TfLinv);%adjoint matrix of Tinv
      Xb2wR       = Adjoint(TfRinv);
      JbfL        = Xb2wL*JsfL;%left body Jacobian
      JbfR        = Xb2wR*JsfR;
      Selectf     = [1,0,0;
                     0,0,1];%select x and z velocities
      AtfL        = [Selectf*RfL*Selects*JbfL;
                     [0,0,1]];
      AtfR        = [Selectf*RfR*Selects*JbfR;
                     [0,0,1]];    
      Atf         = [zeros(6,6),blkdiag(AtfL,AtfR)];
      dpf         = Atf*dstate;