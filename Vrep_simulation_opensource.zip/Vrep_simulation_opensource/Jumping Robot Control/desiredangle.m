function [ddhkd,dhkd,hkd,thehd,thekd]=desiredangle(H_des,dH_des,ddH_des,dh,r,Lg)
thehd    = acos((H_des-dh-r)/(2*Lg));
thekd    = -2*thehd;
dthehd   = -1/sqrt(1-((H_des-dh-r)/(2*Lg))^2)*dH_des/(2*Lg);
dthekd   = -2*dthehd;
ddthehd  = -(H_des-dh-r)*dH_des^2/(8*Lg^3*(1-((H_des-dh-r)/(2*Lg))^2)^(3/2))-ddH_des/(2*Lg*sqrt(1-((H_des-dh-r)/(2*Lg))^2));
ddthekd  = -2*ddthehd;
ddhkd   = [ddthehd;ddthekd];
dhkd    = [dthehd;dthekd];
hkd     = [thehd;thekd];


