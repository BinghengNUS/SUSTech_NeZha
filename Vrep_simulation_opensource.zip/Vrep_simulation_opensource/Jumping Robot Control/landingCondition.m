function x = landingCondition(QL,RL,Llqr,zmax,vref,torqueLimit)
%*************************************************************************
% Landing Condition Optimization via fmincon
%*************By Bingheng WANG, on Apr 13,2020****************************
%------------------%
%Parameters Setting
%------------------%
g     = 9.8;
m     = 9.568;%total mass
r     = 0.1;
%------------------%
% LQR acceleration
%------------------%
A     = [0,1,0;
         g/Llqr,0,0;
         0,0,0];
B     = [0;-1/Llqr;1];
K     = lqr(A,B,QL,RL);
%------------------%
% Reference
%------------------%
t_ref = 0;
dt_ref= 0;
x_ref = [t_ref;dt_ref;vref];%reference for LQR
taumax= torqueLimit(5);
%------------------%
%fmincon
%------------------%
amax  = taumax/r/m;
fun   =@(x)(-K*([x(1);x(2);x(3)]-x_ref)-amax)^2;
x0    = [0;0;0;0];
% Al    = [K,0];
% bl    = K*x_ref;
lb    = [0;0;0;-sqrt(2*g*(zmax-Llqr))];
lb    = double(lb);
ub    = [pi/30;pi/6;vref;0];
nonlcon = @nonlinearcon;
x     = fmincon(fun,x0,[],[],[],[],lb,ub,nonlcon);