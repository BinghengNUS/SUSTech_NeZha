%*************************************************************************
%    Drawing Figures for Jumping Control by Vrep Simulation
%****************By Bingheng WANG, on May.29, 2020************************
% figure(1)
% plot(BaseX(1:3630),BaseZ(1:3630),'r');
% hold on;
% plot(WheelRX(1:3630),Wheelzposition(1:3630));
% hold on;
% plot(BaseX(1000:60:2500),BaseZ(1000:60:2500),'ro');
% hold on;
% plot(WheelRX(1000:60:2500),Wheelzposition(1000:60:2500),'bo');
% hold on;
% for i=1000:60:2500
%     plot([BaseX(i),WheelRX(i)],[BaseZ(i),Wheelzposition(i)],'k','linewidth',0.2);
%     hold on;
% end
% % plot(BaseX(1603),BaseZ(1603),'ro');
% % hold on;
% % plot(WheelRX(1603),Wheelzposition(1603),'bo');
% % hold on;
% % plot([BaseX(1603),WheelRX(1603)],[BaseZ(1603),Wheelzposition(1603)],'k','linewidth',0.2);
% % hold on;
% % plot(BaseX(1914),BaseZ(1914),'ro');
% % hold on;
% % plot(WheelRX(1914),Wheelzposition(1914),'bo');
% % hold on;
% % plot([BaseX(1914),WheelRX(1914)],[BaseZ(1914),Wheelzposition(1914)],'k','linewidth',0.2);
% set(gcf,'color','white'); set(gca,'XColor','k','YColor','k');
% legend('Base CoM','Wheel Center');
% xlabel('x [m]');
% ylabel('z [m]');
% axis equal;
% set(gca,'XLim',[-1 5.6]);
% set(gca,'YLim',[0 1.2]);

% figure(2)
% subplot(3,1,1)
% H1=plot(Time(1:3630),LLqr(1:3630),'linewidth',0.5);
% hold on;grid on;
% Lds = 0.72;
% dh  = 0.0674;
% L_0 = Lds+dh;
% L_d1= L_0*ones(1,1152);
% H2=plot(Time(1:1152),L_d1,'--r','linewidth',1.5);
% hold on;
% H3=plot(Time(1153:1171),LT_jref(1:19),'--r','linewidth',1.5);
% hold on;
% H4=plot(Time(1227:1628),LT_jref(20:421),'--r','linewidth',1.5);
% hold on;
% H5=plot(Time(1629:1901),L_FD(1:273),'--r','linewidth',1.5);
% hold on;
% H6=plot(Time(1902:3630),LT_ref(1:1729),'--r','linewidth',1.5);
% hold on;
% H7=plot(Time(1:1630),LLqr_No_DOB(1:1630),'color',[0.13 0.545 0.13],'linewidth',1);
% ylabel('Length [m]');
% legend([H1 H2 H7],{'Actual State','Optimal Ref.','No DOB'});
% subplot(3,1,2)
% plot(Time(1:3630),Tiltangle(1:3630)*180/pi,'linewidth',0.5);
% hold on;
% thetad = 0.0145*180/pi;
% thetaD =thetad*ones(1,1207);
% plot(Time(1:1207),thetaD,'--r','linewidth',1.5);
% hold on;grid on;
% plot(Time(1208:1628),Theta_REF(1:421)*180/pi,'--r','linewidth',1.5);
% hold on;
% plot(Time(1902:3630),Theta_REFL(1:1729)*180/pi,'--r','linewidth',1.5);
% hold on;
% plot(Time(1:1630),Tiltangle_No_DOB(1:1630)*180/pi,'color',[0.13 0.545 0.13],'linewidth',1);
% ylabel('Pitch Angle [deg]');
% subplot(3,1,3)
% plot(Time(1:3630),Vfw(1:3630),'linewidth',0.5);
% hold on;
% v_d1 = ones(1,1207);
% plot(Time(1:1207),v_d1,'--r','linewidth',1.5);
% hold on;grid on;
% plot(Time(1208:1628),V_REF(1:421),'--r','linewidth',1.5);
% hold on;
% plot(Time(1902:3630),V_REFL(1:1729),'--r','linewidth',1.5);
% hold on;
% plot(Time(1:1630),Vfw_No_DOB(1:1630),'color',[0.13 0.545 0.13],'linewidth',1);
% ylabel('Velocity [m/s]');
% xlabel('Time [s]');
% set(gcf,'color','white'); set(gca,'XColor','k','YColor','k');

figure(3)
subplot(3,1,1)
plot(Time(1:3630),LLqr(1:3630),'linewidth',0.5);
hold on;
Lds = 0.72;
dh  = 0.0674;
L_0 = Lds+dh;
L_d1= L_0*ones(1,1152);
plot(Time(1:1152),L_d1,'--r','linewidth',1.5);
hold on;grid on;
plot(Time(1153:1171),LT_jref(1:19),'--r','linewidth',1.5);
hold on;
plot(Time(1227:1628),LT_jref(20:421),'--r','linewidth',1.5);
hold on;
plot(Time(1629:1901),L_FD(1:273),'--r','linewidth',1.5);
hold on;
plot(Time(1902:3630),LT_ref(1:1729),'--r','linewidth',1.5);
ylabel('Length [m]');set(gca,'XLim',[2.3 4.7]);
legend('Actual State','Optimal Ref.');
subplot(3,1,2)
plot(Time(1:3630),Tiltangle(1:3630)*180/pi,'linewidth',0.5);
hold on;grid on;
thetad = 0.0145*180/pi;
thetaD =thetad*ones(1,1207);
plot(Time(1:1207),thetaD,'--r','linewidth',1.5);
hold on;
plot(Time(1208:1628),Theta_REF(1:421)*180/pi,'--r','linewidth',1.5);
hold on;
plot(Time(1902:3630),Theta_REFL(1:1729)*180/pi,'--r','linewidth',1.5);
ylabel('Pitch Angle [deg]');set(gca,'XLim',[2.3 4.7]);
subplot(3,1,3)
plot(Time(1:3630),Vfw(1:3630),'linewidth',0.5);
hold on;
v_d1 = ones(1,1207);
plot(Time(1:1207),v_d1,'--r','linewidth',1.5);
hold on;grid on;
plot(Time(1208:1628),V_REF(1:421),'--r','linewidth',1.5);
hold on;
plot(Time(1902:3630),V_REFL(1:1729),'--r','linewidth',1.5);
ylabel('Velocity [m/s]');set(gca,'XLim',[2.3 4.7]);
xlabel('Time [s]');
set(gcf,'color','white'); set(gca,'XColor','k','YColor','k');

% figure(4)
% subplot(3,1,1)
% plot(Time(1:3630),Torque(1,1:3630),'color',[0 0 0.5],'linewidth',0.5);
% hold on;set(gca,'XLim',[0 7.3]);
% plot(Time(1:3630),Torque(2,1:3630),'r','linewidth',0.1);
% legend('Left','Right');
% ylabel('Hip Torque [Nm]');grid on;
% subplot(3,1,2)
% plot(Time(1:3630),Torque(3,1:3630),'color',[0 0 0.5],'linewidth',0.5);
% hold on;set(gca,'XLim',[0 7.3]);
% plot(Time(1:3630),Torque(4,1:3630),'r','linewidth',0.1);
% ylabel('Knee Torque [Nm]');grid on;
% subplot(3,1,3)
% plot(Time(1:3630),Torque(5,1:3630),'color',[0 0 0.5],'linewidth',0.5);
% hold on;set(gca,'XLim',[0 7.3]);
% plot(Time(1:3630),Torque(6,1:3630),'r','linewidth',0.1);
% ylabel('Wheel Torque [Nm]');
% xlabel('Time [s]');grid on;