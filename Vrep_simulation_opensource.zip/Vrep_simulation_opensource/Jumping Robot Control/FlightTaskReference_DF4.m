function [pf_ref,dpf_ref,ddpf_ref] = FlightTaskReference_DF4(psym,v_ref,L_fd,dL_fd,ddL_fd,dtheta_LO) 
%This function returns the reference for task-space. In the flight phase the reference is
%for the wheel center in {b}. The reference of base c.o.m is optimized by a
%one-dimensional SLIP model online using quadratic programming. The wheel
%center reference is temporarily constant in {s}
%state=[x;y;z;roll;pitch;yaw;thetahl;thetakl;thetawl;thetahr;thetakr;thetawr]
%shanktilt=[theta0l;theta0r]
%psym  = [r,d,g,Lg,Ltcom,Lscom,dh,dhs,mfb,mtl,msl,mw,mu];%system parameter vector
%*********************By Bingheng WANG, on May.21 2020*********************
pf_ref  = [0;-L_fd;0;0;-L_fd;0];%desired x, z position of wheel in {b} and wheel joint angle
dpf_ref = [0;-dL_fd;v_ref/psym(1)-dtheta_LO;0;-dL_fd;v_ref/psym(1)-dtheta_LO];
ddpf_ref= [0;-ddL_fd;0;0;-ddL_fd;0];
