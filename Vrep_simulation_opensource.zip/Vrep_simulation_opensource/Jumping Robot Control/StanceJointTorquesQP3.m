function [tau,contorqL,contorqR,F] = StanceJointTorquesQP3(ddhkd,dhkd,hkd,Ats,ddxtsc,psym,state,dstate,ddq,Llqr,dLlqr,theta,dtheta,ddtheta,torq_lqr) 
%This function returns the joint torques for the task-space control, which
%includes two hip joint torques, two knee joint torques and two wheel joint
%torques. All torques are obtained by quadratic programming based on a full
%dynamic model
%psym  = [r,d,g,Lg,Ltcom,Lscom,dh,dhs,mfb,mtl,msl,mw,mur,mus];%system parameter vector
%optimal varibales: sln 23by1,ddq 12by1, tau 6by1, constraint force 5by1
%*********************By Bingheng WANG, on Mar.8 2020*********************

    %---------------------------------------%
    %model in stance (computing the force first then mapping to torques)
    %---------------------------------------%
    %control force is achieved via a wheeled pendulum model with a variable
    %length
    mup      = psym(9)+2*(psym(10)+psym(11));
    dh       = psym(7);
    r        = psym(1);
    Lg       = psym(4);
    mfb      = psym(9);
    mw       = psym(12);
    mup      = psym(9)+2*(psym(10)+psym(11));
    mur      = psym(13);
    g        = psym(3);
    ddthetaw = ddq(5);
    f        = -sin(theta)*r*(ddtheta+ddthetaw)+Llqr*dtheta^2-g*cos(theta);
    
    %---------------------------------%
    %Quadratic programming formulation
    %---------------------------------%
    Hsqp  = blkdiag(1,0);
    fsqp  = [-ddxtsc;0];
    Aeqs  = [1,-1/mup];
    beqs  = f;
    Hsqp  = double(Hsqp);
    fsqp  = double(fsqp);
    Aeqs  = double(Aeqs);
    beqs  = double(beqs);
    %limits of control torques
    usmin   = -3000;
    usmax   = 500;
    %limits of optimal variables
    lb    = [-Inf(1,1);usmin];
    ub    = [Inf(1,1);usmax];
    [slns,optC] = quadprog(Hsqp,fsqp,[],[],Aeqs,beqs,lb,ub);%hip, knee, followed by right side
    F     = slns(2);
    jointtorq   = Ats.'*F;
    hiptorqueL  = 1/2*jointtorq(2);
    kneetorqueL = 1/2*jointtorq(1);
    hiptorqueR  = 1/2*jointtorq(2);
    kneetorqueR = 1/2*jointtorq(1);
    mddlL = F-mup/2*g*cos(theta)+mup/2*Llqr*dtheta^2-mup/2*sin(theta)*r*(ddtheta+ddq(5));
    mddlR = F-mup/2*g*cos(theta)+mup/2*Llqr*dtheta^2-mup/2*sin(theta)*r*(ddtheta+ddq(6));
    MfriL = (F*cos(theta)+mw*g)*mur;
    MfriR = (F*cos(theta)+mw*g)*mur;
    contorqL = MfriL+mddlL*sin(theta)*r+mup*r*dLlqr*dtheta*cos(theta);
    contorqR = MfriR+mddlR*sin(theta)*r+mup*r*dLlqr*dtheta*cos(theta);
    wheeltorqueL = torq_lqr(1)+contorqL;
    wheeltorqueR = torq_lqr(2)+contorqR;
    kd    = 15;
    kp    = 20;
    Iyyb     = 0.5*0.0249232975683053;
    Iyyt     = 1*0.022309557436881;
    tau   = [-hiptorqueL+Iyyb*(kd*(dhkd(1)-dstate(7))+kp*(hkd(1)-state(7)));-hiptorqueR+Iyyb*(kd*(dhkd(1)-dstate(10))+kp*(hkd(1)-state(10)));-kneetorqueL+Iyyt*(kd*(dhkd(2)-dstate(8))+kp*(hkd(2)-state(8)));-kneetorqueR+.5*Iyyt*(kd*(dhkd(2)-dstate(10))+kp*(hkd(2)-state(10)));wheeltorqueL;wheeltorqueR];

