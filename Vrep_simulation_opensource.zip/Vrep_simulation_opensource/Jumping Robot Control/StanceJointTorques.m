function tau = StanceJointTorques(Ats,Jc,dAts,dJc,state,dstate,ddxtsc,ddwheelc,ddthetasL,ddthetasR,psym,torqueLimit) 
%This function returns the joint torques for the task-space control, which
%includes two hip joint torques, two knee joint torques and two wheel joint
%torques. All torques are obtained by quadratic programming based on a full
%dynamic model
%psym  = [r,d,g,Lg,Ltcom,Lscom,dh,dhs,mfb,mtl,msl,mw,mur,mus];%system parameter vector
%optimal varibales: sln 23by1,ddq 12by1, tau 6by1, constraint force 5by1
%*********************By Bingheng WANG, on Mar.8 2020*********************

    %---------------------------------------%
    %model in stance (excluding wheels)
    %---------------------------------------%
    %Rigid body modeling using Roy Featherstone package
    handle.NB = 7;
    handle.parent = [0 1 2 3 1 5 6];%left part first, then right part
    handle.jtype = {'Ry', 'Ry', 'Ry', 'Ry','Ry','Ry','Ry'};
    handle.Xtree{1} = eye(6);%from {s} to base frame {b} (at base c.o.m) 
    handle.Xtree{2} = xlt([0,0.0762,-psym(7)]);%Adjoint Matrix from {parent i} Link frame to {i}
    handle.Xtree{3} = xlt([0,0.0385,-psym(4)]);
    handle.Xtree{4} = xlt([0,0.0605,-psym(4)]);
    handle.Xtree{5} = xlt([0,-0.0762,-psym(7)]);%from {b} to hip joint frame {h}, expressed in {h}
    handle.Xtree{6} = xlt([0,-0.0385,-psym(4)]);
    handle.Xtree{7} = xlt([0,-0.0605,-psym(4)]);
    mass = psym(9);%half of base
    CoM = [0,0,0];
    Icm =  diag([0.0261376195979353,0.0249232975683053,0.0143828822217345]);
    handle.I{1} = mcI( mass, CoM, Icm );
    mass = psym(10);%Thigh link
    CoM = [0,0.0637001804791891,psym(5)];
    Icm =  diag([0.0223883715246182,0.022309557436881,0.00172727939342223]);
    handle.I{2} = mcI( mass, CoM, Icm );
    mass = psym(11);%Shank link
    CoM = [0,0.0364494458894979,psym(6)];
    Icm = diag([0.0175958448813304,0.0177210394041728,0.000378821101531682]);
    handle.I{3} = mcI( mass, CoM, Icm );
    mass = psym(12);%Wheel link
    CoM = [0,0.013,0];
    Icm = diag([0.00249269451196491,0.0049481769879587,0.00249269451196491]);
    handle.I{4} = mcI( mass, CoM, Icm );
    mass = psym(10);%Thigh link
    CoM = [0,-0.0637001804791891,psym(5)];
    Icm =  diag([0.0223883715246182,0.022309557436881,0.00172727939342223]);
    handle.I{5} = mcI( mass, CoM, Icm );
    mass = psym(11);%Shank link
    CoM = [0,-0.036449445889498,psym(6)];
    Icm = diag([0.0175958448813304,0.0177210394041728,0.000378821101531682]);
    handle.I{6} = mcI( mass, CoM, Icm );
    mass = psym(12);%Wheel link
    CoM = [0,-0.0129851806070332,0];
    Icm = diag([0.00249269451196491,0.0049481769879587,0.00249269451196491]);
    handle.I{7} = mcI( mass, CoM, Icm );
    handle_fb   = floatbase(handle);
    [Ms,Cs]     = HandC(handle_fb, state, dstate, []);   
    %---------------------------------%
    %Quadratic programming formulation
    %---------------------------------%
    Hs    = Ats.'*Ats;
    fs    = Ats.'*(dAts*dstate-ddxtsc);
    Hsqp  = blkdiag(Hs,zeros(11,11));
    fsqp  = [fs;zeros(11,1)];
    Ss    = [zeros(6,6);eye(6)];
    Sw    = [zeros(1,8),1,zeros(1,3);
             zeros(1,11),1];%wheel joint selection matrix
    Aeqs  = [Ms,-Ss,-Jc.';
             Jc,zeros(5,11);
             Sw,zeros(2,11)];
    beqs  = [-Cs;
             -dJc*dstate;
             ddwheelc-[ddthetasL;ddthetasR]];
    Hsqp  = double(Hsqp);
    fsqp  = double(fsqp);
    Aeqs  = double(Aeqs);
    beqs  = double(beqs);
    %limits of constraint forces
    fczmax  = torqueLimit(5)/psym(13);
    fcymax  = fczmax*psym(14);
    taucmax = 2*fcymax*psym(2);
    fcmin   = [0;0;-fcymax;-fcymax;-taucmax];
    fcmax   = [fczmax;fczmax;fcymax;fcymax;taucmax];
    %limits of control torques
    usmin   = -[torqueLimit(1);torqueLimit(3);torqueLimit(5);torqueLimit(2);torqueLimit(4);torqueLimit(6)];
    usmax   = [torqueLimit(1);torqueLimit(3);torqueLimit(5);torqueLimit(2);torqueLimit(4);torqueLimit(6)];
    %limits of optimal variables
    lb    = [-Inf(12,1);usmin;fcmin];
    ub    = [Inf(12,1);usmax;fcmax];
    [slns,optC] = quadprog(Hsqp,fsqp,[],[],Aeqs,beqs,lb,ub);%hip, knee, followed by right side
    hiptorqueL   = slns(13);
    kneetorqueL  = slns(14);
    wheeltorqueL = slns(15);
    hiptorqueR   = slns(16);
    kneetorqueR  = slns(17);
    wheeltorqueR = slns(18);
    tau   = [hiptorqueL;hiptorqueR;kneetorqueL;kneetorqueR;wheeltorqueL;wheeltorqueR];

