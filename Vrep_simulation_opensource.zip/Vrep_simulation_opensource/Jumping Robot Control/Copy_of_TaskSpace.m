function [AtsL,AtsR,Atf,zbL,zbR,dzbL,dzbR,pf,dpf] = TaskSpace(state,shanktilt,dstate,dshanktilt,psym)
%This function returns the matrices needed for task-space formulation given
%the system states,e.g. dot x_t = At*dot q
%state=[x;y;z;roll;pitch;yaw;thetahl;thetakl;thetawl;thetahr;thetakr;thetawr]
%shanktilt=[theta0l;theta0r]
%psym  = [r,d,g,Lg,Ltcom,Lscom,dh,dhs,mfb,mtl,msl,mu];%system parameter vector
%****************By Bingheng WANG, on Mar.8.2020**************************
%-------------------------------------------------------------------------%
%Stance phase, base c.o.m is the task space, space frame is inertial frame
%-------------------------------------------------------------------------%
      Ms          = [1,0,0,0;
                     0,1,0,0;
                     0,0,1,2*psym(4)+psym(7);
                     0,0,0,1];%the home configuration (position and orientation) of the base fixed body frame in {s}
      Slists      = [[0;1;0;0;0;0],[0;1;0;-psym(4);0;0],[0;1;0;-2*psym(4);0;0]];
      thetalistsL = [shanktilt(1);-state(8);-state(7)];%shank link tilting angle; knee angle; hip angle
      thetalistsR = [shanktilt(2);-state(11);-state(10)];%right side
      Tsl         = FKinSpace(Ms, Slists, thetalistsL);%left side
      [RsL, psL]  = TransToRp(Tsl);%rotation matrix from {b} to {s} and position of c.o.m in {s}
      zbL         = psL(3)+psym(1);%height of the base
      Tsr         = FKinSpace(Ms, Slists, thetalistsR);%right side
      [RsR, psR]  = TransToRp(Tsr);
      zbR         = psR(3)+psym(1);
      JssL        = JacobianSpace(Slists, thetalistsL);%velocity Jacobian in {s}
      JssR        = JacobianSpace(Slists, thetalistsR);%right side
      Tslinv      = TransInv(Tsl);
      Tsrinv      = TransInv(Tsr);
      Xs2bL       = Adjoint(Tslinv);%adjoint matrix of Tinv
      Xs2bR       = Adjoint(Tsrinv);
      JbsL        = Xs2bL*JssL;%left body Jacobian
      JbsR        = Xs2bR*JssR;
      Selects1    = [zeros(3,3),eye(3)];
      Selects2    = [0,0,1];
      AtsL        = Selects2*RsL*Selects1*JbsL;%left mapping matrix
      AtsR        = Selects2*RsR*Selects1*JbsR;%right mapping matrix
      dthetalistsL= [dshanktilt(1);dstate(8);dstate(7)];
      dthetalistsR= [dshanktilt(2);dstate(11);dstate(10)];
      dzbL        = AtsL*dthetalistsL;
      dzbR        = AtsR*dthetalistsR;
%-----------------------------------------------------------------------%
%Flight phase, wheel center is the task-space, space frame is body frame
%-----------------------------------------------------------------------%
      Mf          = [1,0,0,0;
                     0,1,0,0;
                     0,0,1,-2*psym(4)-psym(7);
                     0,0,0,1];%the home configuration (position and orientation) of wheel frame in {b}
      Slistf      = [[0;1;0;psym(7);0;0],[0;1;0;psym(4)+psym(7);0;0],[0;1;0;2*psym(4)+psym(7);0;0]];
      thetalistfL = [state(7);state(8);state(9)];%hip, knee and wheel joint angles
      thetalistfR = [state(10);state(11);state(12)];
      Tfl         = FKinSpace(Mf, Slistf, thetalistfL);%left side
      [RfL, pfL]  = TransToRp(Tfl);%rotation matrix from {w} to {b} and position of {w} in {b}
      Tfr         = FKinSpace(Mf, Slistf, thetalistfR);%right side
      [RfR, pfR]  = TransToRp(Tfr);
      pf          = [pfL(1);pfL(3);state(9);pfR(1);pfR(3);state(12)];
      JsfL        = JacobianSpace(Slistf, thetalistfL);%velocity Jacobian in {b}
      JsfR        = JacobianSpace(Slistf, thetalistfR);%right side
      Tflinv      = TransInv(Tfl);
      Tfrinv      = TransInv(Tfr);
      Xb2wL       = Adjoint(Tflinv);%adjoint matrix of Tinv
      Xb2wR       = Adjoint(Tfrinv);
      JbfL        = Xb2wL*JsfL;%left body Jacobian
      JbfR        = Xb2wR*JsfR;
      Selectf     = [1,0,0;
                     0,0,1];%select x and z velocities
      AtfL        = [Selectf*RfL*Selects1*JbfL;
                     [0,0,1]];
      AtfR        = [Selectf*RfR*Selects1*JbfR;
                     [0,0,1]];    
      Atf         = [zeros(6,6),blkdiag(AtfL,AtfR)];
      dpf         = Atf*dstate;