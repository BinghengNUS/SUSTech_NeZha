function [value,isterminal,direction]=takeoff(t,xs,alphaDL,betax,g,m,mb,r,Ksn,kL,L0,flagjump)
% xs = [length,theta,dlength,dtheta]
[P0,~,P2]=poly(t);
delL     = P0*alphaDL;
ddx      = P2*betax;
M        = [m,0;
            r*m*sin(xs(2)),m*xs(1)^2+r*m*cos(xs(2))*xs(1)];
C        = [-m*xs(1)*xs(4)^2+m*g*cos(xs(2))-Ksn*(L0-xs(1));
            (2*m*xs(1)+2*r*m*cos(xs(2)))*xs(3)*xs(4)-m*g*xs(1)*sin(xs(2))-2*m*r*sin(xs(2))*xs(1)*xs(4)^2];
S        = [-m*sin(xs(2)),Ksn;
            -m*xs(1)*cos(xs(2))-r*(m+mb),0];
U        = [ddx;
            delL];
ddxs     = M^(-1)*(S*U-C);
vzm      = kL*(xs(3)*cos(xs(2))-xs(1)*sin(xs(2))*xs(4));
azm      = kL*(ddxs(1)*cos(xs(2))-2*xs(3)*sin(xs(2))*xs(4)-xs(1)*cos(xs(2))*xs(4)^2-xs(1)*sin(xs(2))*ddxs(2));
value(1,1)=vzm;
value(2,1)=azm+g;


direction = [1;-1];