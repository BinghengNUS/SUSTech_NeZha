figure(1)
subplot(2,2,1)
plot(Time,State(2,:));
hold on;
plot(Time(475),Ld,'kx','linewidth',1.5);
ylabel('Length [m]');
xlabel('Time [s]');
subplot(2,2,2)
plot(Time,State(5,:));
hold on;
plot(Time(475),dLd,'kx','linewidth',1.5);
ylabel('Linear velocity [m/s]');
xlabel('Time [s]');
subplot(2,2,3)
plot(Time,State(3,:)*180/pi);
hold on;
plot(Time(475),thed*180/pi,'kx','linewidth',1.5);
xlabel('Time [s]');
ylabel('Pitch Angle [deg]');
subplot(2,2,4)
plot(Time,State(6,:)*180/pi);
hold on;
plot(Time(475),dthed*180/pi,'kx','linewidth',1.5);
xlabel('Time [s]');
ylabel('Angular velocity [deg/s]');
% figure(2)
% subplot(2,2,1)
% plot(Time,State_n9(2,:),'r');
% hold on;
% plot(Time,State_0(2,:),'color',[0.13 0.545 0.13]);
% hold on;
% plot(Time,State_p12(2,:),'color',[0 0 0.5]);
% hold on;
% plot(Time(475),Ld,'kx','linewidth',1.5);
% ylabel('Length [m]');
% xlabel('Time [s]');
% subplot(2,2,2)
% plot(Time,State_n9(5,:),'r');
% hold on;
% plot(Time,State_0(5,:),'color',[0.13 0.545 0.13]);
% hold on;
% plot(Time,State_p12(5,:),'color',[0 0 0.5]);
% hold on;
% plot(Time(475),dLd,'kx','linewidth',1.5);
% ylabel('Length Rate [m/s]');
% xlabel('Time [s]');
% subplot(2,2,3)
% plot(Time,State_n9(3,:)*180/pi,'r');
% hold on;
% plot(Time,State_0(3,:)*180/pi,'color',[0.13 0.545 0.13]);
% hold on;
% plot(Time,State_p12(3,:)*180/pi,'color',[0 0 0.5]);
% hold on;
% plot(Time(475),thed*180/pi,'kx','linewidth',1.5);
% ylabel('Angle [deg]');
% xlabel('Time [s]');
% subplot(2,2,4)
% plot(Time,State_n9(6,:)*180/pi,'r');
% hold on;
% plot(Time,State_0(6,:)*180/pi,'color',[0.13 0.545 0.13]);
% hold on;
% plot(Time,State_p12(6,:)*180/pi,'color',[0 0 0.5]);
% hold on;
% plot(Time(475),dthed*180/pi,'kx','linewidth',1.5);
% ylabel('Angular Velocity [deg/s]');
% xlabel('Time [s]');