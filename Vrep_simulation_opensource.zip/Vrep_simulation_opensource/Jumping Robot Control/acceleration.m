function ddx = acceleration (t,x,alpha,beta,g)
[P0,P1,P2]=poly(t);
Lt     = P0*alpha;
dLt    = P1*alpha;
thet   = P0*beta;
dthet  = P1*beta;
ddthet = P2*beta;
ddx    = -(Lt*ddthet+2*dLt*dthet-g*sin(thet))/cos(thet);