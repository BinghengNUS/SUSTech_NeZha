function [pf_ref,dpf_ref,ddpf_ref] = FlightTaskReference(baseorientation,wb,dwb,psym,vref) 
%This function returns the reference for task-space. In the flight phase the reference is
%for the wheel center in {b}. The reference of base c.o.m is optimized by a
%one-dimensional SLIP model online using quadratic programming. The wheel
%center reference is temporarily constant in {s}
%state=[x;y;z;roll;pitch;yaw;thetahl;thetakl;thetawl;thetahr;thetakr;thetawr]
%shanktilt=[theta0l;theta0r]
%psym  = [r,d,g,Lg,Ltcom,Lscom,dh,dhs,mfb,mtl,msl,mw,mu];%system parameter vector
%*********************By Bingheng WANG, on Mar.8 2020*********************

    roll    = baseorientation(1);
    pitch   = baseorientation(2);
    yaw     = baseorientation(3);
    Rs2b    = Rzyx(roll,pitch,yaw);
    pfds    = [0;0;-0.6];%desired wheel position w.r.t base c.o.m in {s}
    pfddL   = Rs2b*pfds;%transfered to {b}
    pf_ref  = [pfddL(1);pfddL(3);0;pfddL(1);pfddL(3);0];%desired x, z position of wheel in {b} and wheel joint angle
    dpfdd   = -skew(wb)*Rs2b*pfds;%desired velocity of wheel center in {b}
    dpf_ref = [dpfdd(1);dpfdd(3);vref/psym(1);dpfdd(1);dpfdd(3);vref/psym(1)];
    ddpfdd  = -skew(dwb)*Rs2b*pfds+skew(wb)^2*Rs2b*pfds;%desired acceleration of wheel center in {b}
    ddpf_ref= [ddpfdd(1);ddpfdd(3);0;ddpfdd(1);ddpfdd(3);0];
