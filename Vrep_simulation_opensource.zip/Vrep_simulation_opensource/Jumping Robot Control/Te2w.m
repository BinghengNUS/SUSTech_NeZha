function [T_e2w,dT_e2w] = Te2w(roll,pitch,droll,dpitch)
T_e2w = [1,         0,         -sin(pitch);
         0, cos(roll),cos(pitch)*sin(roll);
         0,-sin(roll),cos(pitch)*cos(roll)];
dT_e2w= [0,0,-cos(pitch)*dpitch;
         0,-sin(roll)*droll,-sin(pitch)*sin(roll)*dpitch+cos(pitch)*cos(roll)*droll;
         0,-cos(roll)*droll,-sin(pitch)*cos(roll)*dpitch-cos(pitch)*sin(roll)*droll];