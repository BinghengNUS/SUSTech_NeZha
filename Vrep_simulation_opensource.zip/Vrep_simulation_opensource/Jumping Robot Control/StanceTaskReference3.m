function [ps_ref,dps_ref,ddps_ref] = StanceTaskReference3(bs_ref,dbs_ref,ddbs_ref)
%This function returns the reference for task-space in stance phase
%The relative position of wheel center w.r.t the base c.o.m is the negative
%value of base c.o.m height minus the wheel radius
%state=[thetahl;thetakl;thetahr;thetakr]
%psym  = [r,d,g,Lg,Ltcom,Lscom,dh,dhs,mfb,mtl,msl,mw,mu];%system parameter vector
%*********************By Bingheng WANG, on May.21 2020*********************
ps_ref  = [0;-bs_ref;0;-bs_ref];%desired x, z position of wheel in {b}
dps_ref = [0;-dbs_ref;0;-dbs_ref];
ddps_ref = [0;-ddbs_ref;0;-ddbs_ref];
    