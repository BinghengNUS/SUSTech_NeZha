function [ddxtsc,ddwheelc] = StanceStateMachineQP(ddhkd,dhkd,hkd,ps,dps,Kps,Kds,vref,dyawref,psym,theta,dtheta,q,dq,deltap_b,dthetasL,dthetasR,Q,R)
%This function returns the dynamic commands in task-space, based on the
%reference and system task-space variables.
%Kps: proportional gain in stance phase
%Kpf: proportional gain in flight phase
%Kds: derivative gain in stance phase
%Kdf: derivative gain in flight phase
%psym  = [r,d,g,Lg,Ltcom,Lscom,dh,dhs,mfb,mtl,msl,mu];%system parameter vector
% Commands consist of a PD-based feedback control law and a feedforward
% term of desired acceleration
% Commands for wheel acceleration are obtained via LQR
    %States for LQR
    mtl      = psym(10);
    Ltcom    = psym(5);
    mfb      = psym(9);
    r        = psym(1);
    d        = psym(2);
    x        = [theta;dq(5);dq(6);dtheta];%+dthetasL+dthetasR
    dx       = 2*mtl*Ltcom*sin((q(1)+q(2))/2)/(2*mtl+mfb);%offset in x axis of c.o.m of base and thigh legs
    %control gain for the LQR controller
    Llqr     = sqrt((deltap_b(1))^2+(deltap_b(3))^2);%length of the pendulum
    thetad   = atan(-dx/Llqr);
    dq1ref   = (vref-d*dyawref)/r;
    dq2ref   = (vref+d*dyawref)/r;
    xref     = [thetad;dq1ref;dq2ref;0];
    K        = LQRcontrolQP(Llqr,Q,R);
    ddwheelc =-K*(x-xref);
    ps_ref   = [hkd;hkd;];
    dps_ref  = [dhkd;dhkd];
    ddps_ref = [ddhkd;ddhkd];
    ddxtsc   = ddps_ref+Kds*(dps_ref-dps)+Kps*(ps_ref-ps);
