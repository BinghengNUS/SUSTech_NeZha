function [pf_ref,dpf_ref,ddpf_ref] = FlightTaskReference_DF2(baseorientation,wb,dwb,psym,v_ref,Lds,theta_LO) 
%This function returns the reference for task-space. In the flight phase the reference is
%for the wheel center in {b}. The reference of base c.o.m is optimized by a
%one-dimensional SLIP model online using quadratic programming. The wheel
%center reference is temporarily constant in {s}
%state=[x;y;z;roll;pitch;yaw;thetahl;thetakl;thetawl;thetahr;thetakr;thetawr]
%shanktilt=[theta0l;theta0r]
%psym  = [r,d,g,Lg,Ltcom,Lscom,dh,dhs,mfb,mtl,msl,mw,mu];%system parameter vector
%*********************By Bingheng WANG, on Mar.8 2020*********************
    dh      = psym(7);%height of base c.o.m relative to the hip joint
    roll    = baseorientation(1);
    pitch   = baseorientation(2);
    yaw     = baseorientation(3);
    Rs2b    = Rzyx(roll,pitch,yaw);
    pfds    = [-(Lds+dh)*sin(theta_LO);0;-(Lds+dh)*cos(theta_LO)];%desired wheel position w.r.t base c.o.m in {s}
    pfddL   = Rs2b*pfds;%transfered to {b}
    pf_ref  = [pfddL(1);pfddL(3);0;pfddL(1);pfddL(3);0];%desired x, z position of wheel in {b} and wheel joint angle
    dpfdd   = -skew(wb)*Rs2b*pfds;%desired velocity of wheel center in {b}
    dpf_ref = [dpfdd(1);dpfdd(3);v_ref/psym(1);dpfdd(1);dpfdd(3);v_ref/psym(1)];
    ddpfdd  = -skew(dwb)*Rs2b*pfds+skew(wb)^2*Rs2b*pfds;%desired acceleration of wheel center in {b}
    ddpf_ref= [ddpfdd(1);ddpfdd(3);0;ddpfdd(1);ddpfdd(3);0];
