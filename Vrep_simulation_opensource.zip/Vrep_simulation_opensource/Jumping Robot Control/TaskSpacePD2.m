function [Ats,ps,dps,Atf,pf,dpf] = TaskSpacePD2(state,dstate,psym)
%This function returns the matrices needed for task-space formulation given
%the system states,e.g. dot x_t = At*dot q
%state=[x;y;z;roll;pitch;yaw;thetahl;thetakl;thetawl;thetahr;thetakr;thetawr]
%shanktilt=[theta0l;theta0r]
%psym  = [r,d,g,Lg,Ltcom,Lscom,dh,dhs,mfb,mtl,msl,mu];%system parameter vector
%****************By Bingheng WANG, on May.21.2020**************************
%-----------------------------------------------------------------------%
%Stance phase, wheel center is the task-space, space frame is body frame
%statef = [thetahipL;thetakneeL;thetahipR;thetakneeR]
%-----------------------------------------------------------------------%
      Ms          = [1,0,0,0;
                     0,1,0,0;
                     0,0,1,-2*psym(4)-psym(7);
                     0,0,0,1];%the home configuration (position and orientation) of end-effector {e} in {b}
      Slists      = [[0;1;0;psym(7);0;0],[0;1;0;psym(4)+psym(7);0;0]];%screw-axis
      thetalistsL = [state(7);state(8)];%hip and knee angles
      thetalistsR = [state(10);state(11)];%hip and knee angles
      TsL         = FKinSpace(Ms, Slists, thetalistsL);%left side
      [RsL, psL]  = TransToRp(TsL);%rotation matrix from {e} to {b} and position of {e} in {b}
      TsR         = FKinSpace(Ms, Slists, thetalistsR);%right side
      [RsR, psR]  = TransToRp(TsR);
      ps          = [psL(1);psL(3);psR(1);psR(3)];
      JssL        = JacobianSpace(Slists, thetalistsL);%velocity Jacobian in {b}
      JssR        = JacobianSpace(Slists, thetalistsR);%right side
      TsLinv      = TransInv(TsL);
      TsRinv      = TransInv(TsR);
      Xb2eL       = Adjoint(TsLinv);%adjoint matrix of Tinv
      Xb2eR       = Adjoint(TsRinv);
      JbsL        = Xb2eL*JssL;%left body Jacobian
      JbsR        = Xb2eR*JssR;
      Select      = [zeros(3,3),eye(3)];%select v among the twist vector
      Selects     = [1,0,0;
                     0,0,1];%select x and z velocities
      AtsL        = Selects*RsL*Select*JbsL;%2-by-2 matrix
      AtsR        = Selects*RsR*Select*JbsR; 
      Ats         = blkdiag(AtsL,AtsR);
      dstates     = [dstate(7);dstate(8);dstate(10);dstate(11)];
      dps         = Ats*dstates;
%-----------------------------------------------------------------------%
%Flight phase, wheel center is the task-space, space frame is body frame
%statef = [baseposition;orientation;thetahipL;thetakneeL;thetawL;thetahipR;thetakneeR;thetawR]
%-----------------------------------------------------------------------%
      Mf          = [1,0,0,0;
                     0,1,0,0;
                     0,0,1,-2*psym(4)-psym(7);
                     0,0,0,1];%the home configuration (position and orientation) of wheel frame in {b}
      Slistf      = [[0;1;0;psym(7);0;0],[0;1;0;psym(4)+psym(7);0;0],[0;1;0;2*psym(4)+psym(7);0;0]];
      thetalistfL = [state(7);state(8);state(9)];%hip, knee and wheel joint angles
      thetalistfR = [state(10);state(11);state(12)];
      TfL         = FKinSpace(Mf, Slistf, thetalistfL);%left side
      [RfL, pfL]  = TransToRp(TfL);%rotation matrix from {w} to {b} and position of {w} in {b}
      TfR         = FKinSpace(Mf, Slistf, thetalistfR);%right side
      [RfR, pfR]  = TransToRp(TfR);
      pf          = [pfL(1);pfL(3);state(9);pfR(1);pfR(3);state(12)];
      JsfL        = JacobianSpace(Slistf, thetalistfL);%velocity Jacobian in {b}
      JsfR        = JacobianSpace(Slistf, thetalistfR);%right side
      TfLinv      = TransInv(TfL);
      TfRinv      = TransInv(TfR);
      Xb2wL       = Adjoint(TfLinv);%adjoint matrix of Tinv
      Xb2wR       = Adjoint(TfRinv);
      JbfL        = Xb2wL*JsfL;%left body Jacobian
      JbfR        = Xb2wR*JsfR;
      Selectf     = [1,0,0;
                     0,0,1];%select x and z velocities
      AtfL        = [Selectf*RfL*Select*JbfL;
                     [0,0,1]];
      AtfR        = [Selectf*RfR*Select*JbfR;
                     [0,0,1]];    
      Atf         = [zeros(6,6),blkdiag(AtfL,AtfR)];
      dpf         = Atf*dstate;