function x = landingCondition(Q,R,zmax,vref,torquelimit)
%*************************************************************************
% Landing Condition Optimization via fmincon
%*************By Bingheng WANG, on Apr 13,2020****************************
%------------------%
%Parameters Setting
%------------------%
g     = 9.8;
m     = 9.568;%total mass
L0    = 0.7;
r     = 0.1;
%------------------%
% LQR acceleration
%------------------%
A     = [0,1,0;
         g/L0,0,0;
         0,0,0];
B     = [0;-1/L0;1];
K     = lqr(A,B,Q,R);
%------------------%
% Reference
%------------------%
t_ref = 0;
dt_ref= 0;
x_ref = [t_ref;dt_ref;v_ref];%reference for LQR
taumax= torquelimit(5);
%------------------%
%fmincon
%------------------%
amax  = taumax/r/m;
fun   =@(x)(-K*([x(1);x(2);x(3)]-x_ref)-amax)^2;
x0    = [0;0;0;0];
% Al    = [K,0];
% bl    = K*x_ref;
lb    = [0;0;0;-sqrt(2*g*(zmax-L0))];
ub    = [pi/6;pi/3;v_ref;0];
nonlcon = @nonlinearcon;
x     = fmincon(fun,x0,[],[],[],[],lb,ub,nonlcon);