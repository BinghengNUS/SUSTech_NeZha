%*************************************************************************
% New two steps for SLIP planning
%*********************By Bingheng WANG, on May.5 2020*********************
clear all
%---parameters---%
m      = 9.5;
mb     = 3.2;
kL     = m/(m+mb);
g      = 9.8;
r      = 0.1;
dh     = 0.0474;
Lg     = 0.429;
L0     = 2*Lg+r+dh;
theta_LO = 18/180*pi;
dtheta_LO= 8/180*pi;
thekmin  = -140/180*pi;
thekmax  = -60/180*pi;
Lmin     = -Lg*sin(thekmax/2);
Lmax     = -Lg*sin(thekmin/2);
zmin     = 2*Lg*cos(thekmin/2)+dh;
kp     = 70;
Ksmax  = kp/(Lmin^2);
Ksmin  = kp/(Lmax^2);
Ks     = 1/2*(Ksmax+Ksmin);
T      = 2*pi*sqrt(m/Ks);%estimate of the spring period
Lds    = 0.72;
zmax   = 1.25;%0.6*kL*(Lds+dh)+r+0.5;
%---STEP 1: plan spring length and lean angle via decoupled models---%
  %initialization of length planning
  L_0    = Lds+dh;%0.84
  the_0  = 0;%-2.5/180*pi;
  dL_0   = 0;%-sqrt(2*g*(zmax-L_0*cos(the_0)))/cos(the_0);%0
  ddL_0  = 0;%-g;
  %QP formulation
  N      = 10;
  delt   = T/N;
  H1      = zeros(10,10);
    %constraints
    Ld     = Lds+dh;
    thed   = theta_LO;
    dthed  = dtheta_LO;
    dLd    = (kL^(-1)*sqrt(2*g*(zmax-kL*Ld*cos(thed)-r))+Ld*sin(thed)*dthed)/cos(thed);
    Accd   = [-(1+mb/m)*g+2*dLd*sin(thed)*dthed+Ld*cos(thed)*dthed^2;
                 -mb/m*g*tan(thed)-g*tan(thed)-2*dLd*cos(thed)*dthed+Ld*sin(thed)*dthed^2];
        Mcc    = [cos(thed),  sin(thed);
                  -sin(thed)/Ld,cos(thed)/Ld];
        accd   = Mcc^(-1)*Accd;
        ddLd   = accd(1);
    dLmax  = (L0-zmin)*(Ksmax-Ks)/Ks;
  dLmin  = (L0-zmin)*(Ksmin-Ks)/Ks;
    A      = zeros(2*N+2,10);
    b      = zeros(2*N+2,1);
    k      = 1;
    for t=0:delt:T
        [P0,~,P2] = poly(t);
        H1          = H1+P2.'*P2;
        A(k,:)     = m/Ks*P2+P0;
        A(k+101,:) = -m/Ks*P2-P0;
        b(k)       = dLmax+L0-m*g/Ks;
        b(k+101)   = -dLmin-L0+m*g/Ks;
        k          = k+1;
    end
    [P0_0,P1_0,~] = poly(0);
    [P0_T,P1_T,P2_T] = poly(T);
    Aeq    = [P0_0;
              P1_0;
              P0_T;
              P1_T;
              P2_T];
    beq    = [L_0;
              dL_0;
              Ld;
              dLd;
              ddLd];
    options = optimset('Display', 'on','LargeScale', 'off','MaxIter',300);
    alphaL = quadprog(H1,[],A,b,Aeq,beq,[],[],[],options);
  %initialization of angle planning
%   t_top  = sqrt(2*(zmax-Ld)/g);
%   kv     = 1.5;
  the_0  = 0;%-2.5/180*pi;
  dthe_0 = 0;
  ddthe_0= 0;
  dx_0   = 0.9;%kv*Lg/t_top
  ddx_0  = 0;%0
  %constraints
  thed   = theta_LO;
  dthed  = dtheta_LO;
  ddthed = accd(2);
  ddxd   = g*tan(thed);
  dxd    = 1;%+ddxd*T;
  Fxmax  = 200;
  Fxmin  = -200;
  %QP formulation
  [P0_T,P1_T,P2_T] = poly(T);
  P0_T   = double(P0_T);
  P1_T   = double(P1_T);
  P2_T   = double(P2_T);
  Q1     = 1e-8;
  Q6     = 1e5;%1e5;%1e5
  Q2     = 1e9/Q6;%1e11;
  Q3     = 1e8/Q6;%1e10;
  Q4     = 1e7/Q6;%1e8;
  Q5     = 1e6/Q6;%1e7;%1e7
  Q6     = 1;
  Q2     = double(Q2);
  Q3     = double(Q3);
  Q4     = double(Q4);
  Q5     = double(Q5);
  Q6     = double(Q6);
  Ha     = P0_T.'*Q2*P0_T+P1_T.'*Q3*P1_T+P2_T.'*Q4*P2_T;
  Hx     = P1_T.'*Q5*P1_T+P2_T.'*Q6*P2_T;
  Hax    = 0;
  Hxa    = 0;
  fa     = -(P0_T.'*Q2*thed+P1_T.'*Q3*dthed+P2_T.'*Q4*ddthed);
  fx     = -(P1_T.'*Q5*dxd+P2_T.'*Q6*ddxd);
%   H2     = blkdiag(Ha,Hx);
  f2     = [fa;
            fx];
  Aeq2   = zeros(N+4,20);
  beq2   = zeros(N+4,1);
  A2     = zeros(3*(N+1),20);
  b2     = zeros(3*(N+1),1);
  k      = 1;
  for t=0:delt:T
      [P0,P1,P2] = poly(t);
      L          = P0*alphaL;
      dL         = P1*alphaL;
      ddL        = P2*alphaL;
%       Ha         = Ha+P2.'*L*Q1*L*P2+2*P2.'*L*Q1*dL*P1-P2.'*L*Q1*g*P2+2*P1.'...
%           *dL*Q1*L*P2+4*P1.'*dL*Q1*dL*P1-2*P1.'*dL*Q1*g*P0-P0.'*g*Q1*L*P2-2*P0.'*g*Q1*dL*P1+P0.'*g*Q1*g*P0;
%       Hx         = Hx+P2.'*Q1*P2;
%       Hax        = Hax+P2.'*L*Q1*P2+2*P1.'*dL*Q1*P2-P0.'*g*Q1*P2;
%       Hxa        = Hxa+P2.'*Q1*L*P2+2*P2.'*Q1*dL*P1-P2.'*Q1*g*P0;
      %Aeq2(k,:)  = [L*P2-g*P0+2*dL*P1,P2];
      Aeq2(k,:)  = [(m*L^2+r*m*L)*P2+(r*m*ddL-m*g*L)*P0+2*m*(L+r)*dL*P1,(m*L+r*(m+mb))*P2];
      beq2(k,1)  = 0;
      A2(k,:)    = [m*L*P2+m*ddL*P0+2*m*dL*P1,(m+mb)*P2];
      b2(k)    = Fxmax;
      A2(k+N+1,:)= -[m*L*P2+m*ddL*P0+2*m*dL*P1,(m+mb)*P2];
      b2(k+N+1)= -Fxmin;
      A2(k+2*(N+1),:)=[zeros(1,10),-P1];
      b2(k+2*(N+1))=-0.1;
      k          = k+1;
  end
  [P0_0,P1_0,P2_0] = poly(0);
  H2 = blkdiag(Ha,Hx);
%   H2     = [Ha,Hax;
%             Hxa,Hx];
  Aeq2(N+2:N+4,:)   = [P0_0,zeros(1,10);
            P1_0,zeros(1,10);
            zeros(1,10),P1_0;
%             zeros(1,10),P2_0
                        ];
  beq2(N+2:N+4,:)   = [the_0;
            dthe_0;
            dx_0;
%             ddx_0
                       ];
  options = optimset('Display', 'on','LargeScale', 'off','MaxIter',300);
  coeff2 = quadprog(H2,f2,A2,b2,Aeq2,beq2,[],[],[],options);
  alphat = coeff2(1:10,1);
  betax  = coeff2(11:20,1);

%---STEP 2: Trade-off---%
kq     = 1e-8;
Q1     = kq*eye(10);
Q2     = kq*eye(10);
kr     = 1;
QT3    = kr;
QT4    = kr;
QT5    = kr;
QT6    = kr*1e3;
QT7    = kr*1e3;
QT8    = kr*1e3;
N      = 200;
delt   = T/N;
%constraints
x0     = [L_0;the_0;dL_0;0];%length, angle, length rate, angular rate
thed   = theta_LO;
      dthed  = dtheta_LO;
      ddthed = accd(2);
      Ld     = Lds+dh;
      dLd    = (kL^(-1)*sqrt(2*g*(zmax-kL*Ld*cos(thed)-r))+Ld*sin(thed)*dthed)/cos(thed);
      ddLd   = accd(1);
[P0_0,P1_0,~]=poly(0);
% [P0_T,P1_T,~]=poly(T);
Aeq    = [P0_0,zeros(1,10);
          P1_0,zeros(1,10);
          zeros(1,10),P0_0;
          zeros(1,10),P1_0];
beq    = [x0(1);x0(3);x0(2);x0(4)];
%QP formulation
[PT0,PT1,PT2]=poly(T);
Ha     = Q1+PT0.'*QT3*PT0+PT1.'*QT4*PT1+PT2.'*QT5*PT2;
Hb     = Q2+PT0.'*QT6*PT0+PT1.'*QT7*PT1+PT2.'*QT8*PT2;
fa     = -(Q1*alphaL+PT0.'*QT3*Ld+PT1.'*QT4*dLd+PT2.'*QT5*ddLd);
fb     = -(Q2*alphat+PT0.'*QT6*thed+PT1.'*QT7*dthed+PT2.'*QT8*ddthed);
H      = blkdiag(Ha,Hb);
f      = [fa;
          fb];
coeff  = quadprog(H,f,[],[],Aeq,beq);

alpha  = coeff(1:10,1);%final coefficient of length
beta   = coeff(11:20,1);%final coefficient of angle
%---Plot---%
ts    = 0:delt:T;
lt    = zeros(size(ts,2),1);
dlt   = zeros(size(ts,2),1);
ddlt  = zeros(size(ts,2),1);
Thet  = zeros(size(ts,2),1);
dThet = zeros(size(ts,2),1);
dellt = zeros(size(ts,2),1);
ddxt  = zeros(size(ts,2),1);
dxt   = zeros(size(ts,2),1);
Fxf   = zeros(size(ts,2),1);
F_G   = zeros(size(ts,2),1);
k     = 1;
for t = 0:delt:T
    [P0,P1,P2]=poly(t);
    Lt     = P0*alpha;
    lt(k,1)= Lt;
    dLt    = P1*alpha;
    dlt(k,1)=dLt;
    ddLt   = P2*alpha;
    ddlt(k,1)=ddLt;
    thet   = P0*beta;
    Thet(k,1) = thet;
    dthet  = P1*beta;
    dThet(k,1)=dthet;
    ddthet = P2*beta;
%     ddx    = -(Lt*ddthet+2*dLt*dthet-g*sin(thet))/cos(thet);
    ddx    = -(r*m*sin(thet)*ddLt+(m*Lt^2+r*m*cos(thet)*Lt)*ddthet+(2*m*Lt+2*r*m*cos(thet))*dLt*dthet-m*g*Lt*sin(thet)-2*m*r*sin(thet)*Lt*dthet^2)/(m*Lt*cos(thet)+r*(m+mb));
    delL   = (m*ddLt-m*Lt*dthet^2+m*g*cos(thet)-Ks*(L0-Lt)+m*sin(thet)*ddx)/Ks;
    dellt(k,1) = delL;
    ddxt(k,1) = ddx;
    Fxf(k)    = (m+mb)*ddx+m*Lt*cos(thet)*ddthet+m*ddLt*sin(thet)+2*m*cos(thet)*dLt*dthet-m*sin(thet)*Lt*dthet^2;
    F_G(k)    = Ks*(L0-Lt+delL)-m*g*cos(thet);
    k      = k+1;
end
opts   = odeset('RelTol',1e-13,'AbsTol',1e-14);
x0     = dx_0;
tspan  = [0 T];
[t,x]  = ode45(@(t,x)acceleration (t,x,alpha,beta,g),tspan,x0,opts);
figure(1)
plot(ts,lt);
xlabel('Time [s]');
ylabel('Length [m]');
figure(2)
plot(ts,dlt);
xlabel('Time [s]');
ylabel('Length rate [m/s]');
figure(3)
plot(ts,ddlt);
xlabel('Time [s]');
ylabel('Length acceleration [m/s/s]');
figure(4)
plot(ts,Thet);
xlabel('Time [s]');
ylabel('Lean angle [rad]');
figure(5)
plot(ts,dThet);
xlabel('Time [s]');
ylabel('Angular rate [rad/s]');
figure(6)
plot(ts,dellt);
xlabel('Time [s]');
ylabel('Length change [m]');
figure(7)
plot(ts,ddxt);
xlabel('Time [s]');
ylabel('Acceleration [m/s/s]');
figure(8)
plot(ts,Fxf);
xlabel('Time [s]');
ylabel('Force [N]');
figure(9)
plot(t,x);
xlabel('Time [s]');
ylabel('Forward velocity [m/s]');
figure(10)
plot(t,x);
xlabel('Time [s]');
ylabel('Difference F-mg [N]');