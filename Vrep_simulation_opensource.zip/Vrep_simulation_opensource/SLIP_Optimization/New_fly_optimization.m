%*************************************************************************
% New Trajectory Optimization in Fly Phase based on Dynamics Directly
%**********************By Bingheng WANG, on May 19, 2020******************
clear all
%------------------%
%Parameters Setting
%------------------%
Lg       = 0.42;
Lds      = 0.7;
g        = 9.8;
r        = 0.1;
dh       = 0.0474;
L0       = 2*Lg+dh;
Lp       = Lds+dh;
Hob      = 0.5;
z1max    = L0+Hob+r;
z2max    = L0+r;
theta_LO = 10/180*pi;
vz1_0    = sqrt(2*g*(z1max-Lp*cos(theta_LO)-r));
theta_0  = theta_LO;
L_0      = Lp;
dtheta_0 = 5/180*pi;
dL_0     = (vz1_0+L_0*sin(theta_0)*dtheta_0)/cos(theta_0);
T        = 2*vz1_0/g;
T_top    = T/2;
thekmin  = -130/180*pi;
thekmax  = -60/180*pi;
Lmin     = -Lg*sin(thekmax/2);
Lmax     = -Lg*sin(thekmin/2);
m2       = 2.88;
taumax   = 50;
%---------------------------------%
%STEP 1: Length planning
%---------------------------------%
  %constraints
  L_d      = Lp;
  dL_d     = -vz1_0/cos(theta_LO);
  eps      = r/2;
  %QP formulation
  Q1       = 1;
  N        = 10;
  delt     = T/N;
%   H        = zeros(10,10);
%   f        = 0;
  A        = zeros(4*(N+1),10);
  b        = zeros(4*(N+1),1);
  k        = 1;
  for t=0:delt:T
      [P0,P1,P2]= poly(t);
%       H         = H+P0.'*Q1*P0;
%       f         = f-P0.'*Q1*Lp;
      A(k,:)= P0;
      b(k,:)= 2*Lg-eps;
      A(k+N+1,:)= -P0;
      b(k+N+1,:)= -Hob;
%       A(k+2*(N+1),:)= P2;
%       b(k+2*(N+1),:)= taumax/(Lmin*m2);
%       A(k+3*(N+1),:)= -P2;
%       b(k+3*(N+1),:)= taumax/(Lmin*m2);
      k     = k+1;
  end
  [P0_0,P1_0,P2_0] = poly(0);
  [P0_T,P1_T,P2_T] = poly(T);
  [P0_T_top,P1_T_top,P2_T_top] = poly(T_top);
  H   = P0_T_top.'*Q1*P0_T_top+P1_T_top.'*Q1*P1_T_top;
  f   = -P0_T_top.'*Q1*Hob;
  Aeq = [P0_0;P1_0;P0_T;P1_T];
  beq = [L_0;dL_0;L_d;dL_d];
  alpha = quadprog(H,f,A,b,Aeq,beq);
  %plot
%   N      = 200;
%   delt   = T/N;
%   ts     = 0:delt:T;
%   L      = zeros(size(ts,2),1);
%   DL     = zeros(size(ts,2),1);
%   DDL    = zeros(size(ts,2),1);
%   k      = 1;
%   for t=0:delt:T
%       [P0,P1,P2]= poly(t);
%       L(k)      = P0*alpha;
%       DL(k)     = P1*alpha;
%       DDL(k)    = P2*alpha;
%       k         = k+1;
%   end
%   figure(1)
%   plot(ts,L);
%   xlabel('Time [s]');
%   ylabel('L [m]');
%   figure(2)
%   plot(ts,DL);
%   xlabel('Time [s]');
%   ylabel('dL [m/s]');
%   figure(3)
%   plot(ts,DDL);
%   xlabel('Time [s]');
%   ylabel('ddL [m/s/s]');
%---------------------------------%
%STEP 2: Pitch planning
%---------------------------------%
  %constraints
  thetd  = theta_LO;
  dthetd = 0;
  %QP formulation
  Q2     = 1;
  Q3     = 1;
  Aeq2   = zeros((N+3),10);
  beq2   = zeros((N+3),1);
  k      = 1;
  N        = 5;
  delt     = T/N;
  for t=0:delt:T
      [P0,P1,P2]= poly(t);
      dL        = P1*alpha;
      L         = P0*alpha;
      Aeq2(k,:) = P2+2*dL/L*P1;
      beq2(k,:) = 0;
      k         = k+1;
  end
  [P0_T,P1_T,P2_T]= poly(T);
  [P0_0,P1_0,P2_0]= poly(0);
  H2        = P0_T.'*Q2*P0_T+P1_T.'*Q3*P1_T;
  f2        = -P0_T.'*Q2*thetd-P1.'*Q3*dthetd;
  Aeq2(N+2:N+3,:)= [P0_0;P1_0];
  beq2(N+2:N+3,:)= [theta_0;dtheta_0];
  beta = quadprog(H2,f2,[],[],Aeq2,beq2);
   %plot
  N      = 200;
  delt   = T/N;
  ts     = 0:delt:T;
  L      = zeros(size(ts,2),1);
  DL     = zeros(size(ts,2),1);
  theta  = zeros(size(ts,2),1);
  dtheta = zeros(size(ts,2),1);
  k      = 1;
  for t = 0:delt:T
      [P0,P1,P2]= poly(t);
      L(k)=P0*alpha;
      DL(k)=P1*alpha;
      theta(k)=P0*beta;
      dtheta(k)=P1*beta;
      k        = k+1;
  end
  x0     = [theta_0;dtheta_0];
  opts   = odeset('RelTol',1e-12,'AbsTol',1e-13);
  tspan  = [0 T];
  [t,x]  = ode45(@(t,x)flydyn (t,x,alpha),tspan,x0,opts);
  figure(1)
  plot(ts,L);
  xlabel('Time [s]');
  ylabel('L [m]');
  figure(2)
  plot(ts,DL);
  xlabel('Time [s]');
  ylabel('dL [m/s]');
  figure(3)
  plot(ts,theta*180/pi);
  xlabel('Time [s]');
  ylabel('theta [deg]');
  figure(4)
  plot(ts,dtheta*180/pi);
  xlabel('Time [s]');
  ylabel('dtheta [deg/s]');
  figure(5)
  plot(t,x(:,1)*180/pi);
  xlabel('Time [s]');
  ylabel('theta [deg]');
  figure(6)
  plot(t,x(:,2)*180/pi);
  xlabel('Time [s]');
  ylabel('dtheta [deg/s]');