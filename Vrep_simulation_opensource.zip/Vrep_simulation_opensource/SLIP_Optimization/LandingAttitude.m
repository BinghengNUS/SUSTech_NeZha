function Jval = LandingAttitude(zmax,Lds,kp,theta_0,v_0,v_ref,N)
%*************************************************************************
% This function returns the cost value in order to find out the optimal
% landing attitude that corresponds to the minimum cost value
%*********************By Bingheng WANG, on May.9 2020*********************
%---parameters---%
m      = 9.5;%6.68
mb     = 3.2;%2.88
kL     = m/(m+mb);
g      = 9.8;
r      = 0.1;
dh     = 0.0474;
Lg     = 0.42;
L0     = 2*Lg+r+dh;
thekmin  = -140/180*pi;
thekmax  = -60/180*pi;
Lmin     = -Lg*sin(thekmax/2);
Lmax     = -Lg*sin(thekmin/2);
zmin     = 2*Lg*cos(thekmin/2)+dh;
Ksmax  = 4*kp/(Lmin^2);
Ksmin  = 4*kp/(Lmax^2);
Ks     = 1/2*(Ksmax+Ksmin);
T      = 1.5*2*pi*sqrt(m/Ks);%estimate of the spring period
%---STEP 1: plan spring length and lean angle via decoupled models---%
  %A: planning of length based on 1D decoupled linear SLIP model
  %initialization of length planning
  L_0    = Lds+dh;
  dL_0   = -kL^(-1)*sqrt(2*g*(zmax-kL*(Lds+dh)*cos(theta_0))-r)/cos(theta_0);
  %QP formulation
  delt   = T/N;
  H      = zeros(10,10);
  %constraints
  Ld     = Lds+dh;
  dLd    = 0;
  ddLd   = 0;
  dLmax  = (L0-zmin)*(Ksmax-Ks)/Ks;
  dLmin  = (L0-zmin)*(Ksmin-Ks)/Ks;
  A      = zeros(2*N+2,10);
  b      = zeros(2*N+2,1);
  k      = 1;
  for t=0:delt:T
      [P0,~,P2] = poly(t);
      H          = H+P2.'*P2;
      A(k,:)     = m/Ks*P2+P0;
      A(k+N+1,:) = -m/Ks*P2-P0;
      b(k)       = dLmax+L0-m*g/Ks;
      b(k+N+1)   = -dLmin-L0+m*g/Ks;
      k          = k+1;
  end
  [P0_0,P1_0,~] = poly(0);
  [P0_T,P1_T,P2_T] = poly(T);
  Aeq    = [P0_0;
            P1_0;
            P0_T;
            P1_T;
            P2_T];
  beq    = [L_0;
            dL_0;
            Ld;
            dLd;
            ddLd];
  options = optimset('Display', 'on','LargeScale', 'off','MaxIter',1e3);
  alphaL = quadprog(H,[],A,b,Aeq,beq,[],[],[],options);
  %B:planning of angle based on 1D linearized constraint
  %initialization of angle planning
  the_0  = theta_0;%0
  dthe_0 = 0;
  dx_0   = v_0;%kv*Lg/t_top
  ddx_0  = 0;%0
  %constraints
  thed   = 0;
  dthed  = 0;
  ddthed = 0;
  dxd    = v_ref;
  ddxd   = 0;
  Fxmax  = 200;
  Fxmin  = -200;
  %QP formulation
  [P0_T,P1_T,P2_T] = poly(T);
  Q5     = 1e5;%1e5
  Q1     = 1e9/Q5;
  Q2     = 1e8/Q5;
  Q3     = 1e7/Q5;
  Q4     = 1e6/Q5;%1e7
  Q5     = 1;
  Ha     = P0_T.'*Q1*P0_T+P1_T.'*Q2*P1_T+P2_T.'*Q3*P2_T;
  Hx     = P1_T.'*Q4*P1_T+P2_T.'*Q5*P2_T;
  fa     = -(P0_T.'*Q1*thed+P1_T.'*Q2*dthed+P2_T.'*Q3*ddthed);
  fx     = -(P1_T.'*Q4*dxd+P2_T.'*Q5*ddxd);
  H2     = blkdiag(Ha,Hx);
  f2     = [fa;
            fx];
  Aeq2   = zeros(N+5,20);
  beq2   = zeros(N+5,1);
  A2     = zeros(3*(N+1),20);
  b2     = zeros(3*(N+1),1);
  k      = 1;
  for t=0:delt:T
      [P0,P1,P2] = poly(t);
      L          = P0*alphaL;
      dL         = P1*alphaL;
      ddL        = P2*alphaL;
%       Aeq2(k,:)  = [L*P2-g*P0+2*dL*P1,P2];
      Aeq2(k,:)  = [(m*L^2+r*m*L)*P2+(r*m*ddL-m*g*L)*P0+2*m*(L+r)*dL*P1,(m*L+r*(m+mb))*P2];
      beq2(k,1)  = 0;
      A2(k,:)    = [m*L*P2+m*ddL*P0+2*m*dL*P1,(m+mb)*P2];
      b2(k)      = Fxmax;
      A2(k+N+1,:)= -[m*L*P2+m*ddL*P0+2*m*dL*P1,(m+mb)*P2];
      b2(k+N+1)  = -Fxmin;
      A2(k+2*(N+1),:)=[zeros(1,10),-P1];
      b2(k+2*(N+1))=-0.2;
      k          = k+1;
  end
  [P0_0,P1_0,P2_0] = poly(0);
  Aeq2(N+2:N+5,:)   = [P0_0,zeros(1,10);
                       P1_0,zeros(1,10);
                       zeros(1,10),P1_0;
                       zeros(1,10),P2_0
                        ];
  beq2(N+2:N+5,:)   = [the_0;
                       dthe_0;
                       dx_0;
                       ddx_0
                       ];
  coeff2 = quadprog(H2,f2,A2,b2,Aeq2,beq2,[],[],[],options);
  alphat = coeff2(1:10,1);
  betadx = coeff2(11:20,1);
  val1   = 1/2*((P0_T*alphat-thed).'*Q1*(P0_T*alphat-thed)+(P1_T*alphat-dthed).'...
      *Q2*(P1_T*alphat-dthed)+(P2_T*alphat-ddthed).'*Q3*(P2_T*alphat-ddthed)...
      +(P1_T*betadx-dxd).'*Q4*(P1_T*betadx-dxd)+(P2_T*betadx-ddxd).'*Q5*(P2_T*betadx-ddxd));
%---STEP 2: Trade-off---%
kq     = 0.1;
Q1     = kq*eye(10);
Q2     = kq*eye(10);
kr     = 10;
QT3    = kr;
QT4    = kr;
QT5    = kr;
QT6    = kr;
QT7    = kr;
QT8    = kr;
%constraints
x0     = [L_0;theta_0;dL_0;0];%length, angle, length rate, angular rate
% thed   = 0;%0.1;
% dthed  = 0;
% ddthed = 0;
% Ld     = Lds;
% dLd    = 0;
% ddLd   = 0;
[P0_0,P1_0,~]=poly(0);
Aeq3    = [P0_0,zeros(1,10);
          P1_0,zeros(1,10);
          zeros(1,10),P0_0;
          zeros(1,10),P1_0];
beq3    = [x0(1);x0(3);x0(2);x0(4)];
%QP formulation
[PT0,PT1,PT2]=poly(T);
Ha     = Q1+PT0.'*QT3*PT0+PT1.'*QT4*PT1+PT2.'*QT5*PT2;
Hb     = Q2+PT0.'*QT6*PT0+PT1.'*QT7*PT1+PT2.'*QT8*PT2;
fa     = -(Q1*alphaL+PT0.'*QT3*Ld+PT1.'*QT4*dLd+PT2.'*QT5*ddLd);
fb     = -(Q2*alphat+PT0.'*QT6*thed+PT1.'*QT7*dthed+PT2.'*QT8*ddthed);
H      = blkdiag(Ha,Hb);
f      = [fa;
          fb];
coeff  = quadprog(H,f,[],[],Aeq3,beq3,[],[],[],options);
alpha  = coeff(1:10,1);%final coefficient of length
beta   = coeff(11:20,1);%final coefficient of angle
val2   = 1/2*((alpha-alphaL).'*Q1*(alpha-alphaL)+(beta-alphat).'*Q2*(beta-alphat)...
    +(PT0*alpha-Ld).'*QT3*(PT0*alpha-Ld)+(PT1*alpha-dLd).'*QT4...
    *(PT1*alpha-dLd)+(PT2*alpha-ddLd).'*QT5*(PT2*alpha-ddLd)+(PT0*beta-thed).'...
    *QT6*(PT0*beta-thed)+(PT1*beta-dthed).'*QT7*(PT1*beta-dthed)...
    +(PT2*beta-ddthed).'*QT8*(PT2*beta-ddthed));
% Jval   = val1+val2;
%re-define the cost value based on energy consumption
N      = 1000;
delt   = T/N;
Jval   = 0;
for t=0:delt:T
    [P1,P2,P3] = poly(t);
     L_ref      = P1*alpha;
     bs_ref     = L_ref;
     dbs_ref    = P2*alpha;
     ddbs_ref   = P3*alpha;
     theta_ref  = P1*beta;
     dtheta_ref = P2*beta;
     ddtheta_ref= P3*beta;
     ddx_ref    = -(r*m*sin(theta_ref)*ddbs_ref+(m*L_ref^2+r*m*cos(theta_ref)*L_ref)*ddtheta_ref+...
         (2*m*L_ref+2*r*m*cos(theta_ref))*dbs_ref*dtheta_ref-m*g*L_ref*sin(theta_ref)-2*m*r*sin(theta_ref)*L_ref*dtheta_ref^2)/(m*L_ref*cos(theta_ref)+r*(m+mb));
     F_ref      = (m+mb)*ddx_ref+m*L_ref*cos(theta_ref)*ddtheta_ref+...
         m*ddbs_ref*sin(theta_ref)+2*m*cos(theta_ref)*dbs_ref*dtheta_ref-m*sin(theta_ref)*L_ref*dtheta_ref^2;
     Jval       = Jval+1/2*F_ref^2*delt;
end
Jval = Jval+val1+val2;