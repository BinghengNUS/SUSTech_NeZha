%*************************************************************************
% Find out optimal take-off attitude that leads to the minimum cost value
%**********************By Bingheng WANG, on May 23, 2020*******************
clear all
%Parameters Setting
r     = 0.1;%radius of wheel
d     = 0.175;%distance from the wheel to the center of body
g     = 9.8;
Lg    = 0.429;%length of Thighlink
Ltcom = -0.0894;%z position of Thigh_link C.O.M in link frame
Lscom = -0.29;%z position of Shank_link C.O.M in link frame
dh    = 0.0474;% height of C.O.M of the main body relative to the hip joint
dhs   = -2.003e-02;%height of C.O.M of the main body in shape frame of bounding box
mfb   = 5.5;%3.83;%mass of the floating base
mtl   = 2;%1.429;%mass of the thigh leg
msl   = 1.05;%0.7;%mass of the shank leg
mw    = 0.55;%0.74;%mass of the wheel
psym  = [r,d,g,Lg,Ltcom,Lscom,dh,dhs,mfb,mtl,msl,mw];%system parameter vector
m1    = psym(9)+2*psym(10);
m2    = 2*(psym(11)+psym(12));
kL    = m1/(m1+m2);
k1    = 3;
Lds   = 0.72;
H_ob  = 0.5;
L0    = Lds+dh;
zmax  = 0.8;%kL*L0+H_ob+r;
theta_TD = -2/180*pi;
v0    = 1;
%Matrix Setting
theta_min  = -5/180*pi;
dtheta_min = -5/180*pi;%should not be zero
theta_max  = 25/180*pi;
dtheta_max = 15/180*pi;
N       = 30;
Nv      = 20;
Np1     = 11;
Np2     = 7;
delthe  = (theta_max-theta_min)/N;
deldthe = (dtheta_max-dtheta_min)/Nv;
Fval    = zeros(N+1,Nv+1);
FVals   = zeros(N+1,Nv+1);
VX1     = zeros(N+1,Nv+1);
%Solving optimal problem
i       = 1;
j       = 1;
is      = 1;
eps     = 0.2;
vxd     = 1.6;
for theta0 = theta_min:delthe:theta_max
%     theta0 = theta_min;
%     dtheta0= dtheta_min;
    vzb0   = sqrt(2*g*(zmax-kL*L0*cos(theta0)-r));
    for dtheta0 = dtheta_min:deldthe:dtheta_max
        [optval,alphat] = TakeOffOptimization(k1,psym,Lds,theta0,v0,vzb0,dtheta0,zmax,theta_TD,H_ob,Np1,Np2);
        Fval(i,j)   = optval;
        %---Selection of Take-off Angle and Angular Velocity---%
        vx1         = v0+vzb0*tan(theta0)+kL*L0*dtheta0/cos(theta0);
        VX1(i,j)    = vx1;
        if vx1<=vxd+eps && vx1>=vxd-eps
            FVals(i,j) = optval;
%             theta0s(is)  = theta0;          
        end
        j           = j+1;
    end
    j   = 1;
%     js  = 1;
    i   = i+1;
%     if vx1<=vxd+eps && vx1>=vxd-eps
%        is  = is+1;
%     end
end
%plot
% N     = 200;
% vzb0   = sqrt(2*g*(zmax-(Lds)*cos(theta_min)-r));
% T     = 2*vzb0/g;
% delt  = T/N;
% ts    = 0:delt:T;
% THETA = zeros(size(ts,2),1);
% DTHETA= zeros(size(ts,2),1);
% k     = 1;
% for t=0:delt:T
%     [P0,P1,P2]= poly(t);
%     THETA(k)  = P0*alphat;
%     DTHETA(k) = P1*alphat;
%     k         = k+1;
% end
% figure(1)
% plot(ts,THETA*180/pi);
% xlabel('Time [s]');
% ylabel('pitch angle [deg]');
% figure(2)
% plot(ts,DTHETA*180/pi);
% xlabel('Time [s]');
% ylabel('pitch angular velocity [deg/s]');
theta_LO  = theta_min:delthe:theta_max;
dtheta_LO = dtheta_min:deldthe:dtheta_max;
[X,Y]=meshgrid(dtheta_LO*180/pi,theta_LO*180/pi);
figure(1)
surf(X,Y,Fval);
colorbar
ylabel('Pitch Angle [deg]');
xlabel('Pitch Angular Velocity [deg/s]');
zlabel('Cost Value');
% figure(2)
% surf(X,Y,VX1);
% colorbar
% ylabel('Pitch Angle [deg]');
% xlabel('Pitch Angular Velocity [deg/s]');
% zlabel('Forward Velocity [m/s]');
figure(3)
% [Xl,Yl]=meshgrid(dtheta_LO*180/pi,theta0s*180/pi);
% replace zero element in FVals with NaN
  ind = find(FVals == 0);
  FVals(ind)=nan;
surf(X,Y,FVals);
colorbar
ylabel('Pitch Angle [deg]');
xlabel('Pitch Angular Velocity [deg/s]');
zlabel('Cost Value');

%find gloablly optimal take-off attitude corresponding to minimal cost value
mG  = min(Fval);
mmG = min(mG);
[rowG,columnG]=find(Fval==mmG);
Gpitchopt = theta_LO(rowG)*180/pi;
dGpitchopt= dtheta_LO(columnG)*180/pi;
%find locally optimal take-off attitude based on selected angle range
%   % replace zero element in FVals with NaN
%   ind = find(FVals == 0);
%   FVals(ind)=nan;
  %find locally optimal take-off attitude
  mL  = min(FVals);
  mmL = min(mL);
  [rowL,columnL]=find(FVals==mmL);
  Lpitchopt = theta_LO(rowL)*180/pi;
  dLpitchopt= dtheta_LO(columnL)*180/pi;