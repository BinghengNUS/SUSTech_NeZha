%*************************************************************************
% New SLIP model in flight phase, based on m1 coordinate
%***************By Bingheng WANG, on Apr.26 2020**************************
clear all
syms m1 m2 x dx ddx z dz ddz L dL ddL the dthe ddthe g t
vm1  = [dx;dz];
vm2  = [dx-dL*sin(the)-L*cos(the)*dthe;
        dz-dL*cos(the)+L*sin(the)*dthe];
Km1  = 1/2*m1*vm1.'*vm1;
Km2  = 1/2*m2*vm2.'*vm2;
Pm1  = m1*g*z;
Pm2  = m2*g*(z-L*cos(the));
Lag  = Km1+Km2-Pm1-Pm2;

dLagddx     = diff(Lag,dx);
dLagdx      = diff(Lag,x);
dLagddz     = diff(Lag,dz);
dLagdz      = diff(Lag,z);
dLagddL     = diff(Lag,dL);
dLagdL      = diff(Lag,L);
dLagddthe   = diff(Lag,dthe);
dLagdthe    = diff(Lag,the);

xt          = str2sym('x(t)');
zt          = str2sym('z(t)');
Lt          = str2sym('L(t)');
thet        = str2sym('the(t)');
dxt         = str2sym('dx(t)');
dzt         = str2sym('dz(t)');
dLt         = str2sym('dL(t)');
dthet       = str2sym('dthe(t)');
dLagddx     = subs(dLagddx,[x,z,L,the,dx,dz,dL,dthe],[xt,zt,Lt,thet,dxt,dzt,dLt,dthet]);
dLagddz     = subs(dLagddz,[x,z,L,the,dx,dz,dL,dthe],[xt,zt,Lt,thet,dxt,dzt,dLt,dthet]);
dLagddL     = subs(dLagddL,[x,z,L,the,dx,dz,dL,dthe],[xt,zt,Lt,thet,dxt,dzt,dLt,dthet]);
dLagddthe   = subs(dLagddthe,[x,z,L,the,dx,dz,dL,dthe],[xt,zt,Lt,thet,dxt,dzt,dLt,dthet]);

dLagddxdt   = diff(dLagddx,t);
dLagddzdt   = diff(dLagddz,t);
dLagddLdt   = diff(dLagddL,t);
dLagddthedt = diff(dLagddthe,t);
dLagddxdt   = subs(dLagddxdt,[xt,zt,Lt,thet,dxt,dzt,dLt,dthet,diff(xt,t),diff(zt,t),diff(Lt,t),diff(thet,t),diff(dxt,t),diff(dzt,t),diff(dLt,t),diff(dthet,t)],[x,z,L,the,dx,dz,dL,dthe,dx,dz,dL,dthe,ddx,ddz,ddL,ddthe]);
dLagddzdt   = subs(dLagddzdt,[xt,zt,Lt,thet,dxt,dzt,dLt,dthet,diff(xt,t),diff(zt,t),diff(Lt,t),diff(thet,t),diff(dxt,t),diff(dzt,t),diff(dLt,t),diff(dthet,t)],[x,z,L,the,dx,dz,dL,dthe,dx,dz,dL,dthe,ddx,ddz,ddL,ddthe]);
dLagddLdt   = subs(dLagddLdt,[xt,zt,Lt,thet,dxt,dzt,dLt,dthet,diff(xt,t),diff(zt,t),diff(Lt,t),diff(thet,t),diff(dxt,t),diff(dzt,t),diff(dLt,t),diff(dthet,t)],[x,z,L,the,dx,dz,dL,dthe,dx,dz,dL,dthe,ddx,ddz,ddL,ddthe]);
dLagddthedt = subs(dLagddthedt,[xt,zt,Lt,thet,dxt,dzt,dLt,dthet,diff(xt,t),diff(zt,t),diff(Lt,t),diff(thet,t),diff(dxt,t),diff(dzt,t),diff(dLt,t),diff(dthet,t)],[x,z,L,the,dx,dz,dL,dthe,dx,dz,dL,dthe,ddx,ddz,ddL,ddthe]);

Qx   = dLagddxdt-dLagdx;
Qz   = dLagddzdt-dLagdz;
QL   = dLagddLdt-dLagdL;
Qthe = dLagddthedt-dLagdthe;

Qx   = simplify(Qx);
Qz   = simplify(Qz);
QL   = simplify(QL);
Qthe = simplify(Qthe);
Qx   = collect(Qx,[ddx,ddz,ddL,ddthe]);
Qz   = collect(Qz,[ddx,ddz,ddL,ddthe]);
QL   = collect(QL,[ddx,ddz,ddL,ddthe]);
Qthe = collect(Qthe,[ddx,ddz,ddL,ddthe]);
pretty(Qx)
pretty(Qz)
pretty(QL)
pretty(Qthe)