%*************************************************************************
% New two steps for SLIP planning
%*********************By Bingheng WANG, on May.5 2020*********************
clear all
load('state_500.mat');
load('tc.mat');
%---parameters---%
m      = 9.5;
mb     = 3.2;
kL     = m/(m+mb);
g      = 9.8;
r      = 0.1;
dh     = 0.0674;
Lg     = 0.429;
L0     = 2*Lg+r+dh;
theta_LO = 18/180*pi;
dtheta_LO= 10/180*pi;
thekmin  = -140/180*pi;
thekmax  = -60/180*pi;
Lmin     = -Lg*sin(thekmax/2);
Lmax     = -Lg*sin(thekmin/2);
zmin     = 2*Lg*cos(thekmin/2)+dh;
kp     = 30;
kpn    = 30;
Ksmax  = kp/(Lmin^2);
Ksmin  = kp/(Lmax^2);
Ksnmax  = kpn/(Lmin^2);
Ksnmin  = kpn/(Lmax^2);
Ks     = 1/2*(Ksmax+Ksmin);
Ksn     = 1/2*(Ksnmax+Ksnmin);
T      = 2*pi*sqrt(m/Ks)-0.41;%estimate of the spring period
Tn     = T;
Lds    = 0.72;
zmax   = 0.8;%0.6*kL*(Lds+dh)+r+0.5;
vd     = 1;
%**********%
L_0    = state_500(1);
dL_0   = state_500(2);
the_0  = state_500(3);
dthe_0 = state_500(4);
dx_0   = state_500(5);
%---STEP 1: plan delL and acceleration---%
  %initialization of length planning
%     L_0    = Lds+dh;
%     dL_0   = 0;
%     the_0  = 2/180*pi;
%     dthe_0 = 0/180*pi;
%     dx_0   = 0.9;%kv*Lg/t_top
  %constraints
    Ld     = Lds+dh;
    thed   = theta_LO;
    dthed  = dtheta_LO;
    dLd    = (kL^(-1)*sqrt(2*g*(zmax-kL*Ld*cos(thed)-r))+Ld*sin(thed)*dthed)/cos(thed);
    Accd   = [-(1+mb/m)*g+2*dLd*sin(thed)*dthed+Ld*cos(thed)*dthed^2;
                 -mb/m*g*tan(thed)-g*tan(thed)-2*dLd*cos(thed)*dthed+Ld*sin(thed)*dthed^2];
        Mcc    = [cos(thed),  sin(thed);
                  -sin(thed)/Ld,cos(thed)/Ld];
        accd   = Mcc^(-1)*Accd;
       ddLd   = accd(1);
    %QP formulation for delL
    dLmax  = (L0-zmin)*(Ksmax-Ks)/Ks;
    dLmin  = (L0-zmin)*(Ksmin-Ks)/Ks;
    Nddx   = 200;
    A1      = zeros(2*Nddx+2,10);
    b1      = zeros(2*Nddx+2,1);
    k      = 1;
    H1     = zeros(10,10);
   deltx  = T/Nddx;
    for t=0:deltx:T
        [P0,~,P2] = poly(t);
        H1          = H1+P2.'*P2*deltx;
        A1(k,:)     = m/Ks*P2+P0;
        A1(k+101,:) = -m/Ks*P2-P0;
        b1(k)       = dLmax+L0-m*g/Ks;
        b1(k+101)   = -dLmin-L0+m*g/Ks;
        k          = k+1;
    end
    [P0_0,P1_0,~] = poly(0);
    [P0_T,P1_T,P2_T] = poly(T);
    Aeq1    = [P0_0;
              P1_0;
              P0_T;
              P1_T;
              P2_T];
    beq1    = [L_0;
              dL_0;
              Ld;
              dLd;
              ddLd];
    options = optimset('Display', 'on','LargeScale', 'off','MaxIter',300);
    alphaL = quadprog(H1,[],A1,b1,Aeq1,beq1,[],[],[],options);
    DelL   = zeros(Nddx+1,1);
    k=1;
    for t=0:deltx:T
        [P0,~,P2] = poly(t);
        DelL(k)   = (m*P2*alphaL+m*g-Ks*(L0-P0*alphaL))/Ks;
        k=k+1;
    end
    t=0:deltx:T;
    alphaDL = polyfit(t,DelL.',9);
    alphaDL = alphaDL.';
   %QP formulation for acceleration
  
   
   H2     = zeros(10,10);
   for t=0:deltx:T
       [P0,P1,P2]=poly(t);
       H2 = H2+P2.'*P2*deltx;
   end
   [~,P1_0,~]=poly(0);
   [PT0,PT1,PT2]=poly(T);
   Aeq2   = [P1_0;
             PT1;
             PT2];
   beq2   = [dx_0;
             vd;
             g*tan(thed)];
  options = optimset('Display', 'on','LargeScale', 'off','MaxIter',300);
  betax = quadprog(H2,[],[],[],Aeq2,beq2,[],[],[],options);
%---STEP 2: Integration through nonlinear model---%
  opts   = odeset('RelTol',1e-12,'AbsTol',1e-13);
  xs0    = [L_0;the_0;dL_0;dthe_0];
  tspan  = [0 Tn];
%   alphaDL= zeros(10,1);
%   betax  = zeros(10,1);
%   delL   = -0;
  [t,xs]  = ode45(@(t,xs)nonlinearmodel(t,xs,alphaDL,betax,g,m,mb,r,Ksn,L0),tspan,xs0,opts);
  alphaLn = polyfit(t,xs(:,1),9);
  alphaLn = alphaLn.';
  betatn  = polyfit(t,xs(:,2),9);
  betatn  = betatn.';

%---STEP 3: Trade-off---%
kq     = 1e-6;
Q1     = kq*eye(10);
Q2     = kq*eye(10);
kr     = 1;
QT3    = kr;
QT4    = kr;
QT5    = kr;
QT6    = kr;
QT7    = kr;
QT8    = kr;
N      = 1000;
delt   = T/N;
%constraints

x0     = [L_0;the_0;dL_0;dthe_0];%length, angle, length rate, angular rate
thed   = theta_LO;
      dthed  = dtheta_LO;
      ddthed = accd(2);
      Ld     = Lds+dh;
      dLd    = (kL^(-1)*sqrt(2*g*(zmax-kL*Ld*cos(thed)-r))+Ld*sin(thed)*dthed)/cos(thed);
      ddLd   = accd(1);
[P0_0,~,~]=poly(0);
% [P0_T,P1_T,~]=poly(T);
Aeq    = [P0_0,zeros(1,10);
          P1_0,zeros(1,10);
          zeros(1,10),P0_0;
          zeros(1,10),P1_0];
beq    = [x0(1);x0(3);x0(2);x0(4)];
%QP formulation
% [PT0,PT1,PT2]=poly(T);
Ha     = Q1+PT0.'*QT3*PT0+PT1.'*QT4*PT1+PT2.'*QT5*PT2;
Hb     = Q2+PT0.'*QT6*PT0+PT1.'*QT7*PT1+PT2.'*QT8*PT2;
fa     = -(Q1*alphaLn+PT0.'*QT3*Ld+PT1.'*QT4*dLd+PT2.'*QT5*ddLd);
fb     = -(Q2*betatn+PT0.'*QT6*thed+PT1.'*QT7*dthed+PT2.'*QT8*ddthed);
H      = blkdiag(Ha,Hb);
f      = [fa;
          fb];
A      = zeros(3*(Nddx+1),20);
b      = zeros(3*(Nddx+1),1);
k=1;
for t=0:deltx:T
    [P0,P1,P2]=poly(t);
    A(k,:)=[zeros(1,10),P0];
    b(k,:)=theta_LO;
    A(k+Nddx+1,:)=[zeros(1,10),-P0];
    b(k+Nddx+1,:)=-the_0;
    A(k+2*(Nddx+1),:)=[P0,zeros(1,10)];
    b(k+2*(Nddx+1),:)=Ld;
    k=k+1;
end
coeff  = quadprog(H,f,A,b,Aeq,beq);

alpha  = coeff(1:10,1);%final coefficient of length
beta   = coeff(11:20,1);%final coefficient of angle
%---Plot---%
ts    = 0:delt:T;
lt    = zeros(size(ts,2),1);
dlt   = zeros(size(ts,2),1);
ddlt  = zeros(size(ts,2),1);
Thet  = zeros(size(ts,2),1);
dThet = zeros(size(ts,2),1);
ddThet= zeros(size(ts,2),1);
dellt = zeros(size(ts,2),1);
ddxt  = zeros(size(ts,2),1);
dxt   = zeros(size(ts,2),1);
Fxf   = zeros(size(ts,2),1);
F_G   = zeros(size(ts,2),1);
V_plan= zeros(size(ts,2),1);
A_plan= zeros(size(ts,2),1);

k     = 1;
for t = 0:delt:T
    [P0,P1,P2]=poly(t);
    Lt     = P0*alpha;
    lt(k,1)= Lt;
    dLt    = P1*alpha;
    dlt(k,1)=dLt;
    ddLt   = P2*alpha;
    ddlt(k,1)=ddLt;
    thet   = P0*beta;
    Thet(k,1) = thet;
    dthet  = P1*beta;
    dThet(k,1)=dthet;
    ddthet = P2*beta;
    ddThet(k,1)=ddthet;
    V_plan(k)  = P1*betax;
    A_plan(k)  = P2*betax;
   
%     ddx    = -(Lt*ddthet+2*dLt*dthet-g*sin(thet))/cos(thet);
    ddx    = -(r*m*sin(thet)*ddLt+(m*Lt^2+r*m*cos(thet)*Lt)*ddthet+(2*m*Lt+2*r*m*cos(thet))*dLt*dthet-m*g*Lt*sin(thet)-2*m*r*sin(thet)*Lt*dthet^2)/(m*Lt*cos(thet)+r*(m+mb));
    delL   = (m*ddLt-m*Lt*dthet^2+m*g*cos(thet)-Ks*(L0-Lt)+m*sin(thet)*ddx)/Ks;
    dellt(k,1) = delL;
    ddxt(k,1) = ddx;
    Fxf(k)    = (m+mb)*ddx+m*Lt*cos(thet)*ddthet+m*ddLt*sin(thet)+2*m*cos(thet)*dLt*dthet-m*sin(thet)*Lt*dthet^2;
    F_G(k)    = Ks*(L0-Lt+delL)-m*g*cos(thet);
    k      = k+1;
end
opts   = odeset('RelTol',1e-13,'AbsTol',1e-14);
x0     = dx_0;
tspan  = [0 T];
[t,dx]  = ode45(@(t,dx)acceleration2 (t,dx,alpha,beta,g),tspan,x0,opts);
figure(1)
plot(ts,lt);
xlabel('Time [s]');
ylabel('Length [m]');
figure(2)
plot(ts,dlt);
xlabel('Time [s]');
ylabel('Length rate [m/s]');
figure(3)
plot(ts,ddlt);
xlabel('Time [s]');
ylabel('Length acceleration [m/s/s]');
figure(4)
plot(ts,Thet);
xlabel('Time [s]');
ylabel('Lean angle [rad]');
figure(5)
plot(ts,dThet);
xlabel('Time [s]');
ylabel('Angular rate [rad/s]');
figure(6)
plot(ts,dellt);
xlabel('Time [s]');
ylabel('Length change [m]');
figure(7)
plot(ts,ddxt);
xlabel('Time [s]');
ylabel('Acceleration [m/s/s]');
figure(8)
plot(ts,A_plan);
xlabel('Time [s]');
ylabel('Planned acceleration [m/s/s]');
figure(9)
plot(ts,Fxf);
xlabel('Time [s]');
ylabel('Force [N]');
figure(10)
plot(t,dx);
xlabel('Time [s]');
ylabel('Forward velocity [m/s]');
figure(11)
plot(ts,V_plan);
xlabel('Time [s]');
ylabel('Planned forward velocity [m/s]');
