%*************************************************************************
% Landing Optimization for a Modified 3-DOF SLIP model via CVX package
%*************By Bingheng WANG, on Apr 12,2020****************************
clear all
%------------------%
%Parameters Setting
%------------------%
g      = 9.8;
m      = 9.568;%total mass
kp     = 100;%proportional coefficient of knee torque
dt     = 0.001;%sampling time
r      = 0.1;%radius of wheel
Lg     = 0.429;%length of leg (Thigh link and Shank link)
dh     = 0.0474;%height of base c.o.m relative to the hip joint
Ib     = 0.0249232975683053;
It     = 0.022309557436881;
Is     = 0.0177210394041728;
zmax   = 1.5;%maximum height of jump
%---------------------------------------%
%Initial and Desired Final States
%---------------------------------------%
y10    = 0.7;
dy10   = 0;
y20    = 0;
dy20   = 0;
y1d    = 0.7;%desired length of pendulum
y2d    = 0.1367;%desired pitch angle 
A      = [cos(y2d),-y1d*sin(y2d);
         (It-Is)/(Ib+2*(It+Is)*Lg*sin(acos(y1d/(2*Lg)))),-1];
B      = [sqrt(2*g*(zmax-r-(y1d+dh)*cos(y2d)));0];
xd     = A^(-1)*B;
dy1d   = xd(1);
dy2d   = xd(2);
Yd     = [y1d;dy1d;y2d;dy2d];
timef  = 0.8;
%-----------%
%stiffness
%-----------%
Lmin   = 0.2;
Lmax   = 2*Lg;
Ksmax  = 4*kp/(Lmin^2);
Ksmin  = 4*kp/(Lmax^2);
Ks     = 1/2*(Ksmax+Ksmin);%spring constant stiffness
%----------------------------------------%
%Differential flatness based optimization
%----------------------------------------%
cvx_begin
    variable a(8,1);%coefficient of length
    variable b(8,1);%coefficient of angle
    J   = 0;
    Q   = 100*eye(4);
    R   = eye(2);
    Qf  = 1000*eye(4);
    Rf  = diag([100,0]);
    k   = 1;
    Y1  = cvx(zeros(1,timef/dt));
    for t=0:dt:timef
        P0   = [1,t,t^2,t^3,t^4,t^5,t^6,t^7];
        P1   = [0,1,2*t,3*t^2,4*t^3,5*t^4,6*t^5,7*t^6];
        P2   = [0,0,2,6*t,12*t^2,20*t^3,30*t^4,42*t^5];
        P    = [P0;P1];
        Phat = blkdiag(P,P);
        gamma= [a;b];
        y1   = P0*a;%pendulum length
        y2   = P0*b;%pendulum tilting angle
        dy1  = P1*a;
        dy2  = P1*b;
        ddy1 = P2*a;
        ddy2 = P2*b;
%         u2   = -(y1*ddy2+2*dy1*dy2-g*sin(y2))/cos(y2);
%         u1   = (m*ddy1-m*y1*dy2^2+m*g*cos(y2)-Ks*(L0-y1)+m*sin(y2)*u2)/Ks;
%         U    = [u1;u2];
        
%             J    = J+(Phat*gamma-Yd).'*Q*(Phat*gamma-Yd);%+U.'*R*U;
       
        Y1(k)  = y1;
        dY1(k) = dy1;
        Y2(k)  = y2;
        dY2(k) = dy2;
        time(k)=t;
        k      = k+1;
    end
    J    = J+(Phat*gamma-Yd).'*Q*(Phat*gamma-Yd);%results are better with terminal cost only
    minimize(J)
    subject to
    [1,0,0,0,0,0,0,0]*a==y10;
    [0,1,0,0,0,0,0,0]*a==dy10;
    [1,0,0,0,0,0,0,0]*b==y20;
    [0,1,0,0,0,0,0,0]*b==dy20;
%     [1,timef,timef^2,timef^3,timef^4,timef^5,timef^6,timef^7]*a==y1d;
%     [0,1,2*timef,3*timef^2,4*timef^3,5*timef^4,6*timef^5,7*timef^6]*a==dy1d;
%     [1,timef,timef^2,timef^3,timef^4,timef^5,timef^6,timef^7]*b==y2d;
%     [0,1,2*timef,3*timef^2,4*timef^3,5*timef^4,6*timef^5,7*timef^6]*b==dy2d;
cvx_end