%*************************************************************************
% Trajectory Optimization using SLIP model
% This code aims to optimize the C.O.M trajectory by optimizing the
% external force acting on the spring
% 'CVX' matlab package, by Bingheng WANG, on Jan/02/2020*******************
clear all
g  = 9.8;%gravitational acceleration
m  = 13;%total mass
L0 = 0.6;%length of the leg
Ks  = 5000;
x0 = [0.6;0];%initial states
xf = [0.7;1.7];%final states
dt = 0.005;
x_L= [0.4;-5];
x_U= [0.8;1.7];
X_L= zeros(400,1);
X_U= zeros(400,1);
u_max=0;
u_min=-0.5;
Q  = diag([20,20]);
Qt = diag([50000,50000]);%terminal penalty on state
for k=1:2:799
    X_L(k:k+1)=x_L;
    X_U(k:k+1)=x_U;
end
cvx_begin %quiet
    variable u(400,1) %external control force
    x_t = x0;%initialization
    u0  = 0;
    i   = 1;
    j   = 1;
    J   = 0;%R*((Ks*(L0+0.2-x_t(1))+u0)/m-g)^2;

    for t=dt:dt:2
        x_t = x_t+dt*[x_t(2);Ks*(L0+0.1-x_t(1)+u(i))/m-g];%prediction 
        X(j:j+1,1) = x_t;
        z_descending(i)=x_t(1);
        dz_descending(i)=x_t(2);
        Fopt(i)=u(i);
        ddz_t=Ks*(L0+0.1-x_t(1)+u(i))/m-g;
        ddz_descending(i)=ddz_t;
        if t==2
            J=J+(x_t-xf).'*Qt*(x_t-xf);
        else
            J = 0;%+(x_t-xf).'*Q*(x_t-xf);
        end
        time(i)=t;
        i = i+1;
        j = j+2;
    end
    minimize(J);
    subject to
    X<=X_U;
    X>=X_L;
    u<=u_max*ones(400,1);
    u>=u_min*ones(400,1);
%     x_t==xf;
%     ddz_t==Ks*(L0+0.2-xf(1))/m-g;% u_tf =0 ensures the smooth transfer to the pure spring force
cvx_end
