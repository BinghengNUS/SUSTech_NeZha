%*************************************************************************
% 1D-SLIP Planning based on differential flatness
%********************By Bingheng WANG, on May2, 2020**********************
clear all
%initialization
L_0    = 0.84;
dL_0   = 0;
%parameters
m      = 9.568;
g      = 9.8;
r      = 0.1;
dh     = 0.0474;
Lg     = 0.42;
L0     = 2*Lg+r+dh;
Lmin   = 0.2+r+dh;
Lmax   = L0;
kp     = 20;
Ksmax  = 4*kp/(Lmin^2);
Ksmin  = 4*kp/(Lmax^2);
Ks     = 1/2*(Ksmax+Ksmin);
T      = 2*pi*sqrt(m/Ks);%estimate of the spring period
zmax   = L0+0.5;
%QP Formulation
Q1     = 1;
Q2     = 1;
N      = 100;
delt   = T/N;
H      = 0;

 %constraints
 Ld     = 0.7+r+dh;
 thetad = 0;
 dthetad= 0;
 dLd    = sqrt(2*g*(zmax-Ld*cos(thetad)))/cos(thetad);
 dLmax  = (L0-Lmin)*(Ksmax-Ks)/Ks;
 dLmin  = (L0-Lmin)*(Ksmin-Ks)/Ks;
 A      = zeros(2*N+2,8);
 b      = zeros(2*N+2,1);
 k      = 1;
for t=0:delt:T
    [P0,P1,P2]=poly(t);
    H  = H+P2.'*Q1*P2;
    A(k,:)=m/Ks*P2+P0;
    A(k+101,:)=-m/Ks*P2-P0;
    b(k)=dLmax+L0-m*g/Ks;
    b(k+101)=-dLmin-L0+m*g/Ks;
end
[P0_0,P1_0,~]=poly(0);
[P0_T,P1_T,~]=poly(T);
Aeq    = [P0_0;
          P1_0;
          P0_T;
          P1_T];
beq    = [L_0;
          dL_0;
          Ld;
          dLd];
alphaL = quadprog(H,[],A,b,Aeq,beq);
%---Plot---%
ts    = 0:delt:T;
lt    = zeros(size(ts,2),1);
dlt   = zeros(size(ts,2),1);
delL  = zeros(size(ts,2),1);
k     = 1;
for t = 0:delt:T
    [P0,P1,P2]=poly(t);
    Lt     = P0*alphaL;
    lt(k,1)= Lt;
    dLt    = P1*alphaL;
    dlt(k,1)=dLt;
    ddLt   = P2*alphaL;
    deLL   = m*(ddLt+g)/Ks-L0+Lt;
    delL(k,1)=deLL;
    k      = k+1;
end
figure(1)
plot(ts,lt);
xlabel('Time [s]');
ylabel('Length [m]');
figure(2)
plot(ts,dlt);
xlabel('Time [s]');
ylabel('Length rate [m/s]');
figure(3)
plot(ts,delL);
xlabel('Time [s]');
ylabel('Length change [m]');

