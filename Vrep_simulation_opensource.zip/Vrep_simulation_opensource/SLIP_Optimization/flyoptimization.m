%**************************************************************************
% Trajectory Optimization in Flight Phase
%*********************By Bingheng WANG, on May.17 2020*********************
% Similar to the optimization in stance phase, this function takes two
% stpes to generate the trajectories in fly. First, plan the open-loop
% trajectories provided dtheta = 0 and the top mass m_1 follows a ballistic
% trajectory. Second, optimize the trajectory that respects the linear
% nonholonomic constraint based on the open-loop trajectory
clear all
%------------------%
%Parameters Setting
%------------------%
Lg       = 0.42;
Lds      = 0.7;
g        = 9.8;
r        = 0.1;
dh       = 0.0474;
L0       = 2*Lg+dh;
Lp       = Lds+dh;
Hob      = 0.7;
z1max    = L0+Hob+r;
z2max    = L0+r;
theta_LO = 0.34;%20/180*pi;
vz1_0    = sqrt(2*g*(z1max-Lp*cos(theta_LO)-r));%4.2251;
vx2_0    = 0.3786;
theta_0  = theta_LO;
L_0      = Lp;
dtheta_0 = 15/180*pi;
dz2_0    = vz1_0;
dL_0     = (vz1_0-dz2_0+L_0*sin(theta_0)*dtheta_0)/cos(theta_0);
vx1_0    = vx2_0+dL_0*sin(theta_0)+L_0*cos(theta_0)*dtheta_0;%1.3379;
T        = 2*vz1_0/g;
T_top    = T/2;
thekmin  = -130/180*pi;
thekmax  = -60/180*pi;
Lmin     = -Lg*sin(thekmax/2);
Lmax     = -Lg*sin(thekmin/2);
m2       = 2.88;
taumax   = 50;

%---------------------------------%
%STEP 1: Open-loop planning
%---------------------------------%
  %---A: z2 planning via QP---%
    %initialization
    x1_0   = Lp*sin(theta_LO);
    z1_0   = Lp*cos(theta_LO)+r;
    z2_0   = r;
    ddz2_0 = 0;
    %constraints
    z2_T   = r;
    dz2_T  = -vz1_0;
    ddz2_T = 0;
    x1_top = x1_0+T_top*vx1_0;
    x2_top = x1_top-(z1max-z2max)*tan(theta_LO/2);
    %QP formulation
    Q1     = 1;
    [P0_0,P1_0,P2_0] = poly(0);
    [P0_T_top,P1_T_top,P2_T_top] = poly(T_top);
    [P0_T,P1_T,P2_T] = poly(T);
    H1     = P0_T_top.'*Q1*P0_T_top+P1_T_top.'*Q1*P1_T_top;
    f1     = -P0_T_top.'*Q1*z2max;
    Aeq1   = [P0_0;P1_0;P2_0;P0_T;P1_T;P2_T];
    beq1   = [z2_0;dz2_0;ddz2_0;z2_T;dz2_T;ddz2_T];
    N      = 20;
    delt   = T/N;
    A1     = zeros(2*(N+1),10);
    b1     = zeros(2*(N+1),1);
    k      = 1;
    for t=0:delt:T
        dz1       = vz1_0-g*t;
        Z1        = z1_0+(dz1^2-vz1_0^2)/(-2*g);
        [P0,P1,P2]= poly(t);
        A1(k,:)   = P0;
        b1(k,:)   = Z1-Hob;
        A1(k+N+1,:)= -P0;
        b1(k+N+1,:)= -Z1+L0*cos(theta_LO);
        k         = k+1;
    end
    alphaz2 = quadprog(H1,f1,[],[],Aeq1,beq1);
  %---B: x2 planning via QP---%
    %initialization
    x2_0   = 0;
    dx2_0  = vx2_0;
    ddx2_0 = g*tan(theta_LO);
    %constraints
    x2_T   = T*vx1_0;
    dx2_T  = vx1_0;%-(-vz1_0-dz2_T)*tan(theta_LO);
    ddx2_T = 0;
    %QP formulation
    Q2     = 1;
    H2     = P0_T_top.'*Q2*P0_T_top;
    f2     = -P0_T_top.'*Q2*x2_top;
    Aeq2   = [P0_0;P1_0;P2_0;P0_T;P1_T;P2_T];
    beq2   = [x2_0;dx2_0;ddx2_0;x2_T;dx2_T;ddx2_T];
    betax2 = quadprog(H2,f2,[],[],Aeq2,beq2);
 %plot
 N      = 200;
 delt   = T/N;
 ts     = 0:delt:T;
 x1     = zeros(size(ts,2),1);
 z1     = zeros(size(ts,2),1);
 x2     = zeros(size(ts,2),1);
 z2     = zeros(size(ts,2),1);
 L      = zeros(size(ts,2),1);
 dL     = zeros(size(ts,2),1);
 theta  = zeros(size(ts,2),1);
 dtheta = zeros(size(ts,2),1);
 k      = 1;
 for t = 0:delt:T
     X1        = x1_0+vx1_0*t;
     dz1       = vz1_0-g*t;
     Z1        = z1_0+(dz1^2-vz1_0^2)/(-2*g);
     x1(k)     = X1;
     z1(k)     = Z1;
     [P0,P1,P2]= poly(t);
     X2        = P0*betax2;
     Z2        = P0*alphaz2;
     x2(k)     = X2;
     z2(k)     = Z2;
     dx2       = P1*betax2;
     dz2       = P1*alphaz2;
     l         = sqrt((X1-X2)^2+(Z1-Z2)^2);
     L(k)      = l;
     Theta     = acos((Z1-Z2)/l);
     theta(k)  = Theta;
     Ainv      = [sin(Theta),   cos(Theta);
                  cos(Theta)/l,-sin(Theta)/l];
     dstate    = Ainv*[vx1_0-dx2;dz1-dz2];
     dL(k)     = dstate(1);
     dtheta(k) = dstate(2);
     k         = k+1;
 end
    t = 0:delt:T;
    alphaL     = polyfit(t,L.',9);
    betat      = polyfit(t,theta.',9);
    alphaL     = alphaL.';
    betat      = betat.';
    ddtheta    = zeros(size(ts,2),1);
    Dyn        = zeros(size(ts,2),1);
    k          = 1;
   for t = 0:delt:T
       [P0,P1,P2]= poly(t);
       ddTheta   = P2*betat;
       ddtheta(k)= ddTheta;
       dyn       = ddTheta+2*P1*alphaL*P1*betat/(P0*alphaL);
       Dyn(k)    = dyn;
       k         = k+1;
   end
    figure(1)
    plot(ts,x2);
    xlabel('Time [s]');
    ylabel('x2 [m]');
    figure(2)
    plot(ts,z2);
    xlabel('Time [s]');
    ylabel('z2 [m]');
    figure(3)
    plot(ts,x1);
    xlabel('Time [s]');
    ylabel('x1 [m]');
    figure(4)
    plot(ts,z1);
    xlabel('Time [s]');
    ylabel('z1 [m]');
    figure(5)
    plot(ts,L);
    xlabel('Time [s]');
    ylabel('L [m]');
    figure(6)
    plot(ts,theta*180/pi);
    xlabel('Time [s]');
    ylabel('theta [deg]'); 
    figure(7)
    plot(ts,dtheta*180/pi);
    xlabel('Time [s]');
    ylabel('dtheta [deg/s]');
    figure(8)
    plot(ts,dL);
    xlabel('Time [s]');
    ylabel('dL [m/s]');
    figure(9)
    plot(ts,Dyn);
    xlabel('Time [s]');
    ylabel('ddt+2*dL*dt/L');
% %-----------------------------------------%
% %STEP 2: Re-planning via linear constraint
% %-----------------------------------------%
%  
%   %constraints
%   thetd    = theta_LO;
%   dthetd   = 0;
%   L_d      = Lp;
%   dL_d     = 0;%-vz1_0/cos(thetd);
%   eps      = r/2;
%   %QP formulation
%   Q1       = 1e0;
%   Q2       = 1e2;
%   Q3       = 1e2;
%   Q4       = 1e2;
% %   Ha       = P0_T.'*Q1*P0_T+P1_T.'*Q2*P1_T;
% %   Hb       = P0_T.'*Q3*P0_T+P1_T.'*Q4*P1_T;
% %   H3       = blkdiag(Ha,Hb);
%   H3b      = zeros(10,10);
% %   fa       = -P0_T.'*Q1*thetd-P1_T.'*Q2*dthetd;
% %   fb       = -P0_T.'*Q3*L_d-P1_T.'*Q4*dL_d;
% %   f3       = [fa;fb];
%   N        = 5;
%   delt     = T/N;
%   Aeq3     = zeros(N+9,20);
%   beq3     = zeros(N+9,1);
%   A3       = zeros(4*(N+1),20);
%   b3       = zeros(4*(N+1),1);
%   k        = 1;
%   for t = 0:delt:T
%       X1        = x1_0+vx1_0*t;
%       dz1       = vz1_0-g*t;
%       Z1        = z1_0+(dz1^2-vz1_0^2)/(-2*g);
%       [P0,P1,P2]= poly(t);
%       H3b       = H3b+P2.'*Q1*P2;
%       X2        = P0*betax2;
%       Z2        = P0*alphaz2;
%       dx2       = P1*betax2;
%       dz2       = P1*alphaz2;
%       l         = sqrt((X1-X2)^2+(Z1-Z2)^2);
%       Theta     = acos((Z1-Z2)/l);
%       dTheta    = (vx1_0-dx2)*cos(Theta)/l-(dz1-dz2)*sin(Theta)/l;
%       A_t       = dTheta/l;
%       Aeq3(k,:) = [P2,2*A_t*P1];
%       beq3(k,:) = 0;
%       A3(k,:)   = [zeros(1,10),P0];
%       A3(k+N+1,:)=[zeros(1,10),-P0];
%       A3(k+2*(N+1),:)=[zeros(1,10),P2];
%       A3(k+3*(N+1),:)=[zeros(1,10),-P2];
%       b3(k,:)   = 2*Lg-eps;
%       b3(k+N+1,:)=-Hob;
% %       b3(k+2*(N+1),:)=taumax/(Lmin*m2);
% %       b3(k+3*(N+1),:)=taumax/(Lmin*m2);
%       k         = k+1;
%   end
%   H3             = blkdiag(zeros(10,10),H3b);
%   Aeq3(N+2:N+9,:)=[P0_0,zeros(1,10);
%                    P1_0,zeros(1,10);
%                    zeros(1,10),P0_0;
%                    zeros(1,10),P1_0;
%                    P0_T,zeros(1,10);
%                    P1_T,zeros(1,10);
%                    zeros(1,10),P0_T;
%                    zeros(1,10),P1_T];
%   beq3(N+2:N+9,:)=[theta_0;dtheta_0;L_0;dL_0;thetd;dthetd;L_d;dL_d];
%   coeff3 = quadprog(H3,[],A3,b3,Aeq3,beq3);
%   alpha  = coeff3(1:10,1);
%   beta   = coeff3(11:20,1);
%   %plot
%   N      = 200;
%   delt   = T/N;
%   ts     = 0:delt:T;
%   L      = zeros(size(ts,2),1);
%   DL     = zeros(size(ts,2),1);
%   theta  = zeros(size(ts,2),1);
%   dtheta = zeros(size(ts,2),1);
%   k      = 1;
%   for t = 0:delt:T
%       [P0,P1,P2]= poly(t);
%       L(k)=P0*beta;
%       DL(k)=P1*beta;
%       theta(k)=P0*alpha;
%       dtheta(k)=P1*alpha;
%       k        = k+1;
%   end
%   figure(8)
%   plot(ts,L);
%   xlabel('Time [s]');
%   ylabel('L [m]');
%   figure(9)
%   plot(ts,DL);
%   xlabel('Time [s]');
%   ylabel('dL [m/s]');
%   figure(10)
%   plot(ts,theta*180/pi);
%   xlabel('Time [s]');
%   ylabel('theta [deg]');
%   figure(11)
%   plot(ts,dtheta*180/pi);
%   xlabel('Time [s]');
%   ylabel('dtheta [deg/s]');