%*************************************************************************
% New two steps for SLIP planning
%*********************By Bingheng WANG, on May.5 2020*********************
clear all
%---parameters---%
m      = 9.568;
g      = 9.8;
r      = 0.1;
dh     = 0.0474;
Lg     = 0.42;
L0     = 2*Lg+r+dh;
Lmin   = 0.75*Lg+r+dh;
Lmax   = L0;
kp     = 150;
Ksmax  = 4*kp/(Lmin^2);
Ksmin  = 4*kp/(Lmax^2);
Ks     = 1/2*(Ksmax+Ksmin);
T      = 2*pi*sqrt(m/Ks);%estimate of the spring period
zmax   = L0+0.5;
%---STEP 1: plan spring length and lean angle via decoupled models---%
  %initialization of length planning
  L_0    = 0.84;
  dL_0   = 0;
  %QP formulation
  N      = 100;
  delt   = T/N;
  H      = zeros(8,8);
    %constraints
    Ld     = 0.7+r+dh;
    thetad = 0;
    dthetad= 0;
    dLd    = sqrt(2*g*(zmax-Ld*cos(thetad)))/cos(thetad);
    ddLd   = -g;
    dLmax  = (L0-Lmin)*(Ksmax-Ks)/Ks;
    dLmin  = (L0-Lmin)*(Ksmin-Ks)/Ks;
    A      = zeros(2*N+2,8);
    b      = zeros(2*N+2,1);
    k      = 1;
    for t=0:delt:T
        [P0,~,P2] = poly(t);
        H          = H+P2.'*P2;
        A(k,:)     = m/Ks*P2+P0;
        A(k+101,:) = -m/Ks*P2-P0;
        b(k)       = dLmax+L0-m*g/Ks;
        b(k+101)   = -dLmin-L0+m*g/Ks;
        k          = k+1;
    end
    [P0_0,P1_0,~] = poly(0);
    [P0_T,P1_T,P2_T] = poly(T);
    Aeq    = [P0_0;
              P1_0;
              P0_T;
              P1_T;
              P2_T];
    beq    = [L_0;
              dL_0;
              Ld;
              dLd;
              ddLd];
    alphaL = quadprog(H,[],A,b,Aeq,beq);
  %initialization of angle planning
  t_top  = sqrt(2*(zmax-Ld)/g);
  kv     = 1.5;
  the_0  = 0;
  dthe_0 = 0;
  ddthe_0= 0;
  dx_0   = kv*Lg/t_top;
  ddx_0  = 0;
  %constraints
  thed   = 0.1;
  dthed  = 0;
  ddthed = 0;
  ddxd   = g*tan(thed);
  dxd    = dx_0+ddxd*T;
  %QP formulation
  [P0_T,P1_T,P2_T] = poly(T);
  Q1     = 1e11;
  Q2     = 1e10;
  Q3     = 1e8;
  Q4     = 1e7;
  Q5     = 1e5;
  Ha     = P0_T.'*Q1*P0_T+P1_T.'*Q2*P1_T+P2_T.'*Q3*P2_T;
  Hx     = P1_T.'*Q4*P1_T+P2_T.'*Q5*P2_T;
  fa     = -(P0_T.'*Q1*thed+P1_T.'*Q2*dthed+P2_T.'*Q3*ddthed);
  fx     = -(P1_T.'*Q4*dxd+P2_T.'*Q5*ddxd);
  H2     = blkdiag(Ha,Hx);
  f2     = [fa;
            fx];
  Aeq2   = zeros(N+6,16);
  beq2   = zeros(N+6,1);
  for t=0:delt:T
      [P0,P1,P2] = poly(t);
      L          = P0*alphaL;
      dL         = P1*alphaL;
      Aeq2(k,:)  = [L*P2-g*P0+2*dL*P1,P2];
      beq2(k,1)  = 0;
      k          = k+1;
  end
  [P0_0,P1_0,P2_0] = poly(0);
  Aeq2(102:106,:)   = [P0_0,zeros(1,8);
                       P1_0,zeros(1,8);
                       P2_0,zeros(1,8);
                       zeros(1,8),P1_0;
                        zeros(1,8),P2_0];
  beq2(102:106,:)   = [the_0;
                       dthe_0;
                       ddthe_0;
                       dx_0;
                       ddx_0];
  coeff2 = quadprog(H2,f2,[],[],Aeq2,beq2);
  alphat = coeff2(1:8,1);
  betax  = coeff2(9:16,1);
            %---Plot---%
            ts    = 0:delt:T;
            lt    = zeros(size(ts,2),1);
            dlt   = zeros(size(ts,2),1);
            thet  = zeros(size(ts,2),1);
            dthet = zeros(size(ts,2),1);
            ddthet= zeros(size(ts,2),1);
            xt    = zeros(size(ts,2),1);
            dxt   = zeros(size(ts,2),1);
            ddxt  = zeros(size(ts,2),1);
            delL  = zeros(size(ts,2),1);
            k     = 1;
           for t = 0:delt:T
              [P0,P1,P2]=poly(t);
              lt(k)     = P0*alphaL;
              Lt        = P0*alphaL;
              dlt(k)    = P1*alphaL;
              dLt       = P1*alphaL;
              ddLt      = P2*alphaL;
              thet(k)   = P0*alphat;
              dthet(k)  = P1*alphat;
              ddthet(k) = P2*alphat;
              xt(k)     = P0*betax;
              dxt(k)    = P1*betax;
              ddxt(k)   = P2*betax;
              delL(k)   = (m*ddLt+m*g-Ks*(L0-Lt))/Ks;
              k         = k+1;
           end
           figure(1)
           plot(ts,thet);
           xlabel('Time [s]');
           ylabel('Lean angle [rad]');
           figure(2)
           plot(ts,dthet);
           xlabel('Time [s]');
           ylabel('Angular rate [rad/s]');
           figure(3)
           plot(ts,ddthet);
           xlabel('Time [s]');
           ylabel('Angular acceleration [rad/s/s]');
           figure(4)
           plot(ts,dxt);
           xlabel('Time [s]');
           ylabel('Forward speed [m/s]');
           figure(5)
           plot(ts,ddxt);
           xlabel('Time [s]');
           ylabel('Acceleration [m/s/s]');