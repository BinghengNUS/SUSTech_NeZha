%*************************************************************************
% Trajectory Optimization using SLIP model
% This code aims to optimize the C.O.M trajectory by optimizing the
% external force acting on the spring
% 'CVX' matlab package, by Bingheng WANG, on Jan/02/2020*******************
clear all
g  = 9.8;%gravitational acceleration
m  = 13;%total mass
L0 = 0.6;%length of the leg
Ks  = 1274;
x0 = [0.7;0];%initial states
xf = [0.526;0];%final states
ddz= Ks*(L0+0.2-xf(1))/m-g;%desired terminal acceleration
dt = 0.005;
x_L= [0.526;-0.2];
x_U= [0.7;0];
X_L= zeros(800,1);
X_U= zeros(800,1);
u_max=2*m*g;
u_min=-2*m*g;
R  = 0.0001;
Q  = diag([2000,2000]);
Qt = diag([5000,5000]);%terminal penalty on state
Qta= 5000;%terminal penalty on acceleration
for k=1:2:799
    X_L(k:k+1)=x_L;
    X_U(k:k+1)=x_U;
end
cvx_begin 
    variable u(1,400)%u(400,1) %external control force
    x_t = x0;%initialization
    u0  = 0;
    i   = 1;
    j   = 1;
    J   = (x0-xf).'*Q*(x0-xf)+R*u0^2;%R*((Ks*(L0+0.2-x_t(1))+u0)/m-g)^2;

    for t=dt:dt:2
        x_t = x_t+dt*[x_t(2);(Ks*(L0+0.2-x_t(1))+u(i))/m-g];%prediction 
        X(j:j+1,1) = x_t;
        z_descending(i)=x_t(1);
        dz_descending(i)=x_t(2);
        Fopt(i)=u(i);
        ddz_t=(Ks*(L0+0.2-x_t(1))+u(i))/m-g;
        ddz_descending(i)=ddz_t;
        if t==2
            J=J+(x_t-xf).'*Qt*(x_t-xf);%+Qta*(ddz_t-ddz)^2;
        else
            J = J+(x_t-xf).'*Q*(x_t-xf)+R*u(i)^2;%R*((Ks*(L0+0.2-x_t(1))+u(i))/m-g)^2;
        end
        time(i)=t;
        i = i+1;
        j = j+2;
    end
    minimize(J);
    subject to
    X<=X_U;
    X>=X_L;
    u<=u_max*ones(1,400);
    u>=u_min*ones(1,400);
%     x_t==xf;
%     ddz_t==Ks*(L0+0.2-xf(1))/m-g;% u_tf =0 ensures the smooth transfer to the pure spring force
cvx_end
