%*************************************************************************
% Trajectory Optimization using SLIP model
% This code aims to optimize the C.O.M trajectory by optimizing the
% external force acting on the spring
% 'CVX' matlab package, by Bingheng WANG, on Jan/14/2020*******************
clear all
g  = 9.8;%gravitational acceleration
m  = 13;%total mass
L0 = 0.6;%length of the leg
Ks  = 1274;
x0 = [0.69;-2];%initial states
xf = [0.69;0];%final states

dt = 0.005;
x_L= [0.4;-2];
x_U= [0.7;0.05];
X_L= zeros(800,1);
X_U= zeros(800,1);
u_max=2*m*g;
u_min=-2*m*g;

R  = 1;
%Q  = 0.00001;
for k=1:2:799
    X_L(k:k+1)=x_L;
    X_U(k:k+1)=x_U;
end
cvx_begin 
    variable u(400,1) %external control force
    x_t = x0;%initialization
    u0  = 0;
    i   = 1;
    j   = 1;
    %J   = R*((Ks*(L0+0.2-x_t(1))+u0)/m-g)^2;
    J   = R*u0^2;%R*((Ks*(L0+0.2-x_t(1))+u0)/m-g)^2;

    for t=dt:dt:2
        x_t = x_t+dt*[x_t(2);(Ks*(L0+0.2-x_t(1))+u(i))/m-g];%prediction 
        X(j:j+1,1) = x_t;
        z_landing(i)=x_t(1);
        dz_landing(i)=x_t(2);
        Fopt(i)=u(i);
        %J = R*((Ks*(L0+0.2-x_t(1))+u(i))/m-g)^2;
        J = J+R*u(i)^2;%R*((Ks*(L0+0.2-x_t(1))+u(i))/m-g)^2;
        ddz_t =(Ks*(L0+0.2-x_t(1))+u(i))/m-g;
        ddz_landing(i)=ddz_t;
        time(i)=t;
        i = i+1;
        j = j+2;
    end
    minimize(J);
    subject to
    X<=X_U;
    X>=X_L;
    u<=u_max*ones(400,1);
    u>=u_min*ones(400,1);
    x_t==xf;
    ddz_t==0;
cvx_end
