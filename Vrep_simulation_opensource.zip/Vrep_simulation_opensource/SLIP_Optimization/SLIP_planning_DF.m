%*************************************************************************
%  SLIP planning based on differential flatness
%********************By Bingheng WANG, on Apr.29 2020*********************
% This is to plan the trajectories of SLIP length and lean angle based on a
% 3D modified SLIP model in stance. With the length change and the linear
% acceleration of the contact point as control inputs, the remaining 2D
% model is differentially flat (DF). We first generate the open-loop
% trajectories of the length and lean angle with specified inputs.
% Using the DF property, the planning can be formulated as a Quadratic
% Programming problem that penalizes the deviation away from the open-loop
% trajectories, which when tracked results in feasible optimal inputs.
% The optimization is solved using the function 'quadprog'.
clear all
%---STEP 1: Generation of open-loop trajectories---%
%initialization
x0     = [0.84;0;0;0];%length, angle, length rate, angular rate
dx0    = 1;
%parameters
dxd    = 1;
m      = 9.568;
g      = 9.8;
r      = 0.1;
dh     = 0.0474;
Lg     = 0.42;
L0     = 2*Lg+r+dh-0.1;
Lmin   = 0.2+r+dh;
Lmax   = L0+0.1;
kp     = 50;
Ksmax  = 4*kp/(Lmin^2);
Ksmin  = 4*kp/(Lmax^2);
Ks     = 1/2*(Ksmax+Ksmin);
T      = 2*pi*sqrt(m/Ks);%estimate of the spring period
zmax   = L0+0.6;
%open-loop trajectories generation via oed45
opts   = odeset('RelTol',1e-16,'AbsTol',1e-20);
tspan  = [0 T];
[t,x]  = ode45(@(t,x)SLIP_2Ddyn(t,x,dx0,dxd,T,m,L0,Ks,g),tspan,x0,opts);

%---STEP 2: Curve fitting---%
alphaD = polyfit(t,x(:,1),7);%coefficient of 7-order polynomial of length
betaD  = polyfit(t,x(:,2),7);
alphaD = alphaD.';
betaD  = betaD.';
%---STEP 3: Optimal planning via 'quadprog'---%
kq     = 0.0001;
Q1     = 2*kq*eye(8);
Q2     = kq*eye(8);
kr     = 1;
QT3    = kr;
QT4    = kr;
QT5    = kr;
QT6    = kr;
QT7    = kr;
QT8    = kr;
N      = 100;
delt   = T/N;
%constraints
Ld     = 0.7+r+dh;
thetad = 0.1;
dthetad= 0;
dLd    = sqrt(2*g*(zmax-Ld*cos(thetad)))/cos(thetad);
ddLd   = -g*cos(thetad);
ddthetad = 0;
[P0_0,P1_0,~]=poly(0);
% [P0_T,P1_T,~]=poly(T);
Aeq    = [P0_0,zeros(1,8);
          P1_0,zeros(1,8);
          zeros(1,8),P0_0;
          zeros(1,8),P1_0];
beq    = [x0(1);x0(3);x0(2);x0(4)];
%QP formulation
[PT0,PT1,PT2]=poly(T);
Ha     = Q1+PT0.'*QT3*PT0+PT1.'*QT4*PT1+PT2.'*QT5*PT2;
Hb     = Q2+PT0.'*QT6*PT0+PT1.'*QT7*PT1+PT2.'*QT8*PT2;
fa     = -(Q1*alphaD+PT0.'*QT3*Ld+PT1.'*QT4*dLd+PT2.'*QT5*ddLd);
fb     = -(Q2*betaD+PT0.'*QT6*thetad+PT1.'*QT7*dthetad+PT2.'*QT8*ddthetad);
H      = blkdiag(Ha,Hb);
f      = [fa;
          fb];
coeff  = quadprog(H,f,[],[],Aeq,beq);

alpha  = coeff(1:8,1);
beta   = coeff(9:16,1);
%---Plot---%
ts    = 0:delt:T;
lt    = zeros(size(ts,2),1);
dlt   = zeros(size(ts,2),1);
Thet  = zeros(size(ts,2),1);
dThet = zeros(size(ts,2),1);
dellt = zeros(size(ts,2),1);
ddxt  = zeros(size(ts,2),1);
dxt   = zeros(size(ts,2),1);
k     = 1;
for t = 0:delt:T
    [P0,P1,P2]=poly(t);
    Lt     = P0*alpha;
    lt(k,1)= Lt;
    dLt    = P1*alpha;
    dlt(k,1)=dLt;
    ddLt   = P2*alpha;
    thet   = P0*beta;
    Thet(k,1) = thet;
    dthet  = P1*beta;
    dThet(k,1)=dthet;
    ddthet = P2*beta;
    ddx    = -(Lt*ddLt+2*dLt*dthet-g*sin(thet))/cos(thet);
    delL   = (m*ddLt-m*Lt*dthet^2+m*g*cos(thet)-Ks*(L0-Lt)+m*sin(thet)*ddx)/Ks;
    dellt(k,1) = delL;
    ddxt(k,1) = ddx;
    k      = k+1;
end

figure(1)
plot(ts,lt);
xlabel('Time [s]');
ylabel('Length [m]');
figure(2)
plot(ts,dlt);
xlabel('Time [s]');
ylabel('Length rate [m/s]');
figure(3)
plot(ts,Thet);
xlabel('Time [s]');
ylabel('Lean angle [rad]');
figure(4)
plot(ts,dThet);
xlabel('Time [s]');
ylabel('Angular rate [rad/s]');
figure(5)
plot(ts,dellt);
xlabel('Time [s]');
ylabel('Length change [m]');
figure(6)
plot(ts,ddxt);
xlabel('Time [s]');
ylabel('Acceleration [m/s/s]');
% figure(5)
% plot(ts,dxt);
% xlabel('Time [s]');
% ylabel('Velocity [m/s]');
