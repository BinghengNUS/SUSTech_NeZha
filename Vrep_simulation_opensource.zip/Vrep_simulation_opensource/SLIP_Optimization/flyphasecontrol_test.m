% This model considers two legs and deems the main body as a floating base
clear all
Lg  = 0.3;
dh  = 0.1;
r   = 0.1;
handle.NB = 7;
handle.parent = [0 1 2 3 1 5 6];
handle.jtype = {'Ry', 'Rx', 'Rx', 'Ry','Rx','Rx','Ry'};
handle.Xtree{1} = eye(6);
handle.Xtree{2} = rotz(-pi/2) * xlt([0,0,dh]);
handle.Xtree{3} = xlt([0,0,Lg]);
handle.Xtree{4} = rotz(pi/2) * xlt([0,0,Lg]);
handle.Xtree{5} = rotz(-pi/2) * xlt([0,0,dh]);
handle.Xtree{6} = xlt([0,0,Lg]);
handle.Xtree{7} = rotz(pi/2) * xlt([0,0,Lg]);
mass = 9;
CoM = [0,0,0];
Icm = diag(2*[0.0246;0.022;0.035]);
handle.I{1} = mcI( mass, CoM, Icm );

mass = 0.5;
CoM = [0,0,-0.5*Lg];
Icm =  diag([0.01;0.01;0.0012]);%mass * (0.5*Lg)^2 +
handle.I{2} = mcI( mass, CoM, Icm );

mass = 0.5;
CoM = [0,0,-0.5*Lg];
Icm =  diag([0.01;0.01;0.0012]);%mass * (0.5*Lg)^2 +
handle.I{3} = mcI( mass, CoM, Icm );

mass = 1;
CoM = [0,0,0];
Icm = diag([0.0047;0.0023;0.0023]);
handle.I{4} = mcI( mass, CoM, Icm );

mass = 0.5;
CoM = [0,0,-0.5*Lg];
Icm = diag([0.01;0.01;0.0012]);%mass * (0.5*Lg)^2 + 
handle.I{5} = mcI( mass, CoM, Icm );

mass = 0.5;
CoM = [0,0,-0.5*Lg];
Icm =diag([0.01;0.01;0.0012]); %mass * (0.5*Lg)^2 + 
handle.I{6} = mcI( mass, CoM, Icm );

mass = 1;
CoM = [0,0,0];
Icm =  diag([0.0047;0.0023;0.0023]);
handle.I{7} = mcI( mass, CoM, Icm );

handle_fb = floatbase(handle);
% xb    = baseposition(1);
% zb    = baseposition(3);
% vx    = vbase(1);
% vz    = vbase(3);
xb    = 0;
zb    = 0.8;
vx    = 0.5;
vz    = 2;
pitch = 0;
dpitch= 0;
ddqcl = [0;0;0];
ddqcr = [0;0;0];
q     = [pi/3;pi/3;-pi/10;-pi/10;pi;pi];
dq    = [-pi/6;-pi/6;pi/3;pi/3;0;0];
state = [xb;0;zb;0;pitch;0;q(1);q(3);q(5);q(2);q(4);q(6)];
dstate= [vx;0;vz;0;dpitch;0;dq(1);dq(3);dq(5);dq(2);dq(4);dq(6)];
%compute H and C matrices given the q qd f_ext
[H,C] = HandC(handle_fb, state, dstate, []);
S     = [zeros(6,6);eye(6)];
ddyc  = [ddqcl;ddqcr];
% Model Predictive Control using CVX_package
dt = 0.005;
n  = 1;%prediction horizon
x_L= [0;-2/3*pi;0;0;-2/3*pi;0];
x_U= [pi/4;0;50*pi;pi/4;0;50*pi];
X_L= zeros(n*size(x_L,1),1);
X_U= zeros(n*size(x_U,1),1);
u_max=[60;60;60;60;5;5];
u_min=-[60;60;60;60;5;5];
R  = 0.01*eye(6);
Q  = diag([10,10,1,10,10,1]);

for k=1:6:(n*size(x_L,1)-5)
    X_L(k:k+5)=x_L;
    X_U(k:k+5)=x_U;
end
cvx_begin 
    variable JointTorque(6,1) %joint torques to be optimized
    ddstate = H^(-1)*(S*JointTorque-C);
    J = (S'*ddstate-ddyc)'*Q*(S'*ddstate-ddyc)+JointTorque'*R*JointTorque;
    minimize(J);
    subject to
    dstate = dstate+dt*ddstate;
    state  = state+dt*dstate;
    S'*state<=X_U;
    S'*state>=X_L;
    JointTorque<=u_max;
    JointTorque>=u_min;
cvx_end