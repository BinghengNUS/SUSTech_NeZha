%% This script computes the projection of x into the box l <= u.
function [ proj ] = Projection(x, l, u)
n = size(x, 1);
proj = x;
for i=1:n
    if (x(i) < l(i))
        proj(i) = l(i);
    elseif (x(i) > u(i))
        proj(i) = u(i);
    end
end
    