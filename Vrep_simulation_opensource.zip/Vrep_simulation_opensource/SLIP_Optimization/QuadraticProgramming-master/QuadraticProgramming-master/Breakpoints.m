%% This script determines the breakpoints for the projection method
function [ t ] = Breakpoints(x, g, u, l)
n = size(x, 1);
t = zeros(n, 1);

for i=1:n
    if (g(i) < 0)
        t(i) = (x(i) - u(i))/g(i);
    elseif (g(i) > 0)
        t(i) = (x(i) - l(i))/g(i);
    else
        t(i) = inf;
    end
end
end