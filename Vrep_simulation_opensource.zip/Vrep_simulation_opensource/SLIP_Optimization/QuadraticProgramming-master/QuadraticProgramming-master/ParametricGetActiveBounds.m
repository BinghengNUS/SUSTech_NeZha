%% This function gets the active bounds of the PQP at Wtau
function [ actives ] = ParametricGetActiveBounds(W, al, au)
k = 1;
for i=1:length(W)
    if (W(i) == 0)
        continue;
    elseif (W(i) == -1)
        actives(k) = al(i);
        k = k+1;
    elseif (W(i) == 1)
        actives(k) = au(i);
        k = k+1;
    end
end
end