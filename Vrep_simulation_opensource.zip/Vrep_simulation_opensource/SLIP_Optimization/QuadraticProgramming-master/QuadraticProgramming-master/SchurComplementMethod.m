%% Convex QP-Solver via Schur Complement Method.
% This function solves the equality constrained convex optimization problem
%   min x'Hx + g'x   s.t.   Ax = b
% using a simple elimination strategy.

function [ p, lambda ] = SchurComplementMethod(H, g, A, b, x0)
%% Requirements (currently not checking for coherent dimensions).
% Require the matrix to be symmetric.
if (~issymmetric(H))
    error("Please provide symmetric Hessian matrix H.");
end

% Compute Cholesky factorization.
[~, flag] = chol(H);

% Require H to be positve definite.
if (flag ~= 0)
    error("Could not solve QP as H is not positive definite");
end

% Check LICQ if either A or b is set.
[ licq_flag ] = licq(A);
if (~licq_flag)
    error("LICQ violated.");
end

% Preparation.
h = A*x0 - b;
c = g + H*x0;
G_inv_c = H\c;
G_inv_A = H\A';

% Solve for dual variable.
lambda = (A*G_inv_A)\(A*G_inv_c - h);

% Solve for primal step.
p = H\(A'*lambda - c);

disp('Solution found.');
end