%% Local SQP Algorithm (18.1 Nocedal & Wright)
% Solving min f(x)   s.t. c(x) = 0 
function[ x_sol, lambda_sol ] = SQP(grad_f, hess_L, grad_c, c, x0, storeSteps)
% Pre-computation
m = size(c, 1);                     % Number of constraints
n = size(x0, 1);                    % Number of optimization variables
k=1;                                % Iteration steps
x_sol = x0;                         % Initialization of x
lambda_sol = zeros(m,1);            % Initialization of lambda (irrelevant)
eps = 10e-10;

% Main iteration
while( true )
    if (storeSteps)
        xk = x_sol(:,k);
    else
        xk = x_sol;    
    end    
    
    % Evaluate functions and derivatives.
    Hk = hess_L(xk, lambda_sol);
    gk = grad_f(xk);
    Ak = grad_c(xk);
    bk = -c(xk);
    
    % Solve quadratic subproblem.
    [p_sub, l_sub] = SchurComplementMethod(Hk, gk, Ak, bk, xk);
    
    % Advance step
    if (storeSteps)
        x_sol(:, k+1) = xk + p_sub;
        lambda_sol(:, k+1) = l_sub;
    else
        x_sol = xk + p_sub;
        lambda_sol = l_sub;
    end
    k = k + 1;
    
    % Termination criterion
    if (norm(p_sub) < eps)
        disp('Solution found');
    end
end