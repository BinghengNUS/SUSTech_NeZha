function [ x_sol, success ] = ByrdOmojokunTR( f, Jf, c, params )

x_k = params.x0;


while ( true )
    % Evaluations and gradient computation
    f_k = f(x_k);
    jf_k = Jf(x_k);
    c_k = c(x_k);
    % TODO: Compute Ak?
    
end

end