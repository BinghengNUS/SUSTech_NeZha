%% This function tests the parametric termination.

function [ terminate ] = ParametricTerminationTest(altau, al1, autau, au1, gtau, g1)

terminationTolerance = 10^7 * eps;
normalization = max(1, max(abs(al1)), max(au1), max(abs(g1)));

deltatau = [gtau', altau', autau'];
  delta1 = [g1', al1', au1'];
       s = (delta1 - deltatau)/normalization;
       
if ( max(s) < terminationTolerance )
    terminate = true;
else
    terminate = false;
end
end