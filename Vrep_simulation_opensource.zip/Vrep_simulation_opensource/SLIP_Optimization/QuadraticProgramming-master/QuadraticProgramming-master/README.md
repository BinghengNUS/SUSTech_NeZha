# QuadraticProgramming
A repository which will mainly contain solvers and examples of problems based on the  book 'Numerical Optimization' by Nocedal and Wright. Further, the framework qpOASES will be used.  

#### So far this framework contains solvers for 

* Equality, inequality and mixed convex QPs.
* Generic convex NLPs (twice continuously differentiable objectives and constraints required).

#### The current methods implemented are

* Schur Complement Method (for convex QPs)
* Active Set Method (for convex QPs)
* SQP Method (to be tested)
* Gradient Projection Method (currently only for QPs)
* Unstable Interior Point Method

### Computing Derivatives

Since SQP methods require the computations of derivatives, we need a reliable and fast method to do so. The [casADi](https://web.casadi.org/) package is a framework based on automatic differentiation which makes computations extremely reliable and fast.

### Examples

Plenty of example for using the solvers have been implemented in the QP_examples.m and NLP_examples.m files.