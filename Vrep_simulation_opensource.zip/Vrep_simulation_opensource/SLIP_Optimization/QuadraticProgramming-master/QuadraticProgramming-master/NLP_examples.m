%% This script gives examples of NLPs solved via SQP method.

%% NLP Example 1 (Nocedal & Wright 18.3)
clc; close all; clear variables;
import casadi.*;

x = SX.sym('x', 5);
lambda = SX.sym('lambda', 3);

% Objective & constraints
f = exp(x(1)*x(2)*x(3)*x(4)*x(5)) - 1/2*(x(1)^3+x(2)^3+1)^2;
c = x(1)^2 + x(2)^2 + x(3)^2 + x(4)^2 + x(5)^2 - 10;
c = [c; x(2)*x(3) - 5*x(4)*x(5)];
c = [c; x(1)^3 + x(2)^3 + 1];

% Build Lagrangian
L = f;
for i=1:3
    L = L - lambda(i)*c(i);
end

% For each step need these evaluated
g = jacobian(f, x);
H = hessian(L, x);
A = jacobian(c, x);
L = Function('L', {x, lambda}, {f(x) - lambda'*c(x)});

hess_L = Function('hess_L', {x, lambda}, hessian(f, x) - hessian(c, x)*lambda;

grad_f = @(x) full(g(x));
hess_L = @(x, lambda) full(H(x, lambda));
grad_c = @(x) full(A(x));
constr = @(x) full(c(x));
       
x1 = [-1.71; 1.59; 1.82; -0.763; -0.763];
x_true_sol = [-1.8; 1.7; 1.9; -0.8; -0.8];

[ x_sol, lambda_sol ] = SQP(grad_f, hess_L, grad_c, constr, x1, true);

diff = norm(x_true_sol - x_sol);
disp(['2-Norm difference between real solution and computed solution: ', ...
      num2str(diff)]);