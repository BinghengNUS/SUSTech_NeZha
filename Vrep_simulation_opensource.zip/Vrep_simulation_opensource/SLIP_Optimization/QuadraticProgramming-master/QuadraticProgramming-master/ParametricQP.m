%% This script implements the classic PQP algorithm. (taken from qpOASES)
%% Many improvements described in qpOASES have also been implemented.
%        H = Hessian matrix
%   g0, g1 = parametrization of gradient
% al0, al1 = parametrization of lower bounds
% au0, au1 = parametrization of upper bounds
%        A = constraint matrix
%       x0 = primal solution for initial QP
%       y0 = dual solution for initial QP
%       W0 = active set at initial solution

function [ x_sol, y_sol ] = ParametricQP(H, g0, g1, al0, al1, au0, au1, A, x0, y0, W0)
% Initialize
altau = al0;
autau = au0;
 gtau = g0;
 Wtau = W0;
 xtau = x0;
 ytau = y0;
  tau = 0;
    m = size(A,1);

% Main loop
while ( true )
    % Get active bounds
    a_active_1 = ParametricGetActiveBounds(Wtau, al1, au1);
    a_active_tau = ParametricGetActiveBounds(Wtau, altau, autau);
    
    % Solve KKT for new step direction
    KKT_RHS = [-g1 + gtau; a_active_1 - a_active_tau];
         KW = [H,          A_actives';
               A_actives,  zeros(size(A_actives,1))];
       step = KW\KKT_RHS;
    
    % Extracting primal and dual variables
       deltax = step(1:n);
       deltay = zeros(m,1);
    deltay(W) = step(n+1:end);
    
    % Computing homotopy step length
    % Dual step length
    [tau_d, index_d] = RatioTest(Wtau.*ytau, Wtau.*deltay);
    % Primal step length
    tmp1 = A*xtau;
    tmp2 = A*deltax;
    ratio_lower = RatioTest(tmp1 - altau, -tmp2);
    ratio_upper = RatioTest(autau - tmp1, tmp2);
    [tau_p, index_p] = min(ratio_lower, ratio_upper);
    
    % If block is far enough out, we are done.
    tau_plus = min(tau_d, tau_p);
    if (tau_plus + tau >= 1)
        x_sol = xtau + (1-tau)*deltax;
        y_sol = ytau + (1-tau)*deltay;
        return;
    end
    
    % TODO: Determine primal or dual blocking
    if (tau_d < tau_p)
        % Dual blocking
    else
        % Primal blocking
    end    
    
    % Update the parametric QP
     gtau = (1-tau)*g0  + tau*g1;
    altau = (1-tau)*al0 + tau*al1;
    autau = (1-tau)*au0 + tau*au1;
    
    % Ready to terminate?
    if (ParametricTerminationTest(altau, al1, autau, au1, gtau, g1))
        break;
    end
end
end