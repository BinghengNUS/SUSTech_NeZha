%% This script implements the Gradient Projection Method (Nocedal & Wright)

function [ x_sol ] = GradientProjection(G, c, l, u, storeSteps)
n = size(l,1);

q = @(x) 1/2*x'*G*x + c'*x;

if (size(G,1) ~= n || size(u,1) ~= n)
    error('Please provide coherent dimensions of l, u, H (n-rows)');
end

% Central starting point.
xk = (l + u)/2;

if (storeSteps)
    x_sol = xk;
end
% Tolerances
eps_constraints = 10e-10;

% Not handling equality constraints at the moment, thus:
if (min(u - l) < eps_constraints)
    error('Currently not handling equality constraints!');
end

% Active Set
indices = 1:n;
index_active = [];
index_inactive = [];

% For KKT-Check
stationarity = @(x, lambda_l, lambda_u) G*x + c - lambda_l + lambda_u;

% Step counter
k = 1;
while( true )
    lambdak_l = zeros(n, 1);
    lambdak_u = zeros(n, 1);
    
    % objective derivative value
    obj_prime = G*xk + c;
    
    % Update active, inactive sets;
    for i = indices
        % First assume inactive. Then add in either case.
        % This way we should be able to treat equality constraints.
        index_inactive = union(index_inactive, i);
        index_active = setdiff(index_active, i);
        
        % Lower bound check
        if (xk(i) - l(i) < eps_constraints)
            % Set dual variables. (Ignoring strict complementarity)
            lambdak_l(i) = max(0, obj_prime(i));
        end
        
        % Upper bound check
        if (u(i) - xk(i) < eps_constraints)
            % Set dual variables. (Ignoring strict complementarity)
            lambdak_u(i) = max(0, -obj_prime(i));
        end
    end
    
    % KKT Criterion: Will always enfore dual and primal feasibility.
    %                Left to check is stationarity condition.
    if (stationarity(xk, lambdak_l, lambdak_u) < eps_constraints)
        disp('Solution found');
        return;
    end
    
    % Main computation of step:
    % Steepest Descent:
    g = G*xk + c;
    
    % Projection
    path = @(t) Projection(xk - t*g, l, u);
    
    % Breakpoints
    t = Breakpoints(xk, g, u, l);
    t_unique = union(unique(sort(t)), 0);
    
    % Compute cauchy point
    found_cauchy_flag = false;
    for j = 2:size(t_unique,1)
        % TODO: For each i typically only one entry of inner will change
        %       thus we could be more efficient here!
        inner = zeros(size(g,1),1);
        for i = 1:size(g,1)
            if (t_unique(j-1) < t(i))
                inner(i) = -g(i);
            end
        end
        
        pt = path(t(j-1));
        f = c'*pt + 1/2*pt'*G*pt;
        f_prime = c'*inner + pt'*G*inner;
        
        % Either we find Cauchy Point or continue search on next segment.
        if (f_prime > 0)
            % Cauchy point at beginning of current line segment.
            x_cauchy = path(t(j-1));
            found_cauchy_flag = true;
        else
            f_two_prime = inner'*G*inner;
            delta_t = -f_prime/f_two_prime;
            if (delta_t < t(j)-t(j-1) && delta_t >= 0)
                % Cauchy point on current line segment.
                x_cauchy = path(t(j-1) + delta_t);
                found_cauchy_flag = true;
            end
        end
    end
    
    % This shouldn't be possible.
    if (found_cauchy_flag == false)
        error('Could not compute Cauchy point, must be error in code.');
    end
    
    %for i =1:size(t_unique,1)
    %    x_sol(:,i) = path(t_unique(i));
    %end
    
    % Compute active set at cauchy point:
    active_cauchy = [];
    for i = 1:n
        if (x_cauchy(i) - l(i) < eps_constraints)
            active_cauchy = union(active_cauchy, i);
        elseif (u(i) - x_cauchy(i) < eps_constraints)
            active_cauchy = union(active_cauchy, i);
        end
    end
    
    % Solve equality constrained problem and project onto feasibility.
    n_active = size(active_cauchy,2);
    A_sub = zeros(n_active,n);
    for i=1:n_active
        A_sub(i, active_cauchy(i)) = 1;
    end
    
    x_plus = SchurComplementMethod(G, c, A_sub, x_cauchy(active_cauchy), x_cauchy);
    for i=1:n
        if (x_plus(i) > u(i))
            x_plus(i) = u(i);
        elseif (x_plus(i) < l(i))
            x_plus(i) = l(i);
        end
    end
    
    % x_plus should satisfy q(x_plus) <= q(x_cauchy)
    if (q(x_plus) > q(x_cauchy))
        x_plus = x_cauchy;
    end
    
    if (storeSteps)
        x_sol(:, k+1) = x_plus;
    end
    xk = x_plus;
    
    % Advance counter 
    k = k+1;
end

end