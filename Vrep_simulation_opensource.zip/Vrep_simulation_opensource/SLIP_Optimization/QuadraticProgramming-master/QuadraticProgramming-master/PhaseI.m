%% This script solves the Phase I of a QP using linprog
function [ x_feas ] = PhaseI(A, b, I, E, x0)
[m,n] = size(A);

% Objective will be c'[x; z];
c = [zeros(n,1); ones(n,1)]; 

% Constraint vectors
b_iq = b(I);
b_eq = b(E);

% Signs for equality constraints
gamma = -sign(A(E,:)*x0 - b_eq);
lb = [ones(n,1)*-inf; zeros(m,1)];
ub = [inf,inf];

% Initial point
z0 = zeros(m,1);
for i=1:length(I)
    z0(I(i)) = max(b(I(i)) - A(I(i),:)*x0,0);
end
z0(E) = abs(A(E,:)*x0 - b_eq);
w0 = [x0;  z0];

% Constraint matrices
if (~isempty(I))
    A_iq = [A(I,:),     zeros(m,m);
            zeros(m,n), eye(m)];
else 
    A_iq = [];
    b_iq = [];
end

if (~isempty(E))
    A_eq = [A(E,:),       zeros(m,m);
            zeros(m,n), diag(gamma)];
else 
    A_eq = [];
    b_eq = [];
end

% Solve the LP
x_feas = linprog(c,-A_iq,-b_iq,A_eq,b_eq,lb,ub,w0);

end