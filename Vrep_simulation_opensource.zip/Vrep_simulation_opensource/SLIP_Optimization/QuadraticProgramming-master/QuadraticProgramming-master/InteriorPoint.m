%% This script implements the Mehrotra's Predictor-Corrector Method.

function [ x_sol, lambda_sol ] = InteriorPoint(H, g, A, b, x0, y0, lambda0, storeSteps)

% Preparations
  [m, n] = size(A);                 % m constraints, n optimization variables
    beta = 0.8;                     % backtracking factor
max_iter = 12;                     % Maximum number of iterations
 epsilon = 10e-10;                  % For termination criterion
     K = @(lambda, y) [H          zeros(n,m)   -A';
                       A          eye(m)       zeros(m);
                       zeros(m,n) diag(lambda) diag(y)];
   r_d = @(x, lambda) -H*x - A'*lambda + g;
   r_p = @(x, y) A*x - y - b;
   rhs = @(x, lambda, y, sigma, mu) [ -r_d(x, lambda);
                                      -r_p(x, y);
                                      -diag(lambda)*diag(y)*ones(m,1) - sigma*mu*ones(m,1)];

% Todo: Compute initial point.
x_new = x0;
init_aff = K(lambda0, y0)\rhs(x0, lambda0, y0, 0, 0);
y_new = max(1, abs(y0 + init_aff(n+1:n+m)));
lambda_new = max(1, abs(lambda0 + init_aff(n+m+1:n+2*m)));
k=1;
while (true)
    % Save previous steps.
         x_old = x_new;
    lambda_old = lambda_new;
         y_old = y_new;
    
    % Solve affine scaling step.
      aff = K(lambda0, y0)\rhs(x_old, lambda_old, y_old, 0, 0);
       mu = y_old'*lambda_old/m;
    
    % Do a typical backtracking to find max alpha
    alpha = 1;
    while (min(y_old + alpha*aff(n+1:n+m)) < 0 || min(lambda_old + alpha*aff(n+m+1:n+2*m)) < 0)
        alpha = alpha*beta;
    end
    mu_aff = (y_old + alpha*aff(n+1:n+m))'*(lambda_old + alpha*aff(n+m+1:n+2*m))/m;
    
    % Set centering parameter
    sigma = (mu_aff/mu)^3;
    
    % Do main solve again
    delta = K(lambda0, y0)\rhs(x_old, lambda_old, y_old, sigma, mu);
    
    x_new = x_old + alpha*delta(1);
    y_new = y_old + alpha*delta(2);
    lambda_new = lambda_old + alpha*delta(3);
    
    % Keep steps in mind.
    if (storeSteps)
        x_sol(:, k) = x_new;
        lambda_sol(:, k) = lambda_new;
    end
    
    % Termination criterion
    if (norm(x_new - x_old) < epsilon)
        %disp('Algorithm terminated with stationary point.');
        %break;
    end
    
    % Advance step
    k = k+1;
    
    % Terminate on maximum number of iterations.
    if (k > max_iter) 
        disp('Maximum iteration number reached. No success.');
        break;
    end
    
    % Every ten steps print table header.
    if (mod(b, 10) == 0)
        disp('k | Primal step size | Dual step size');
    end
    
    % Print table of stats.
    disp([num2str(k), '      ', num2str(norm(x_new-x_old)), '     ', num2str(norm(lambda_new - lambda_old))]);
end

end