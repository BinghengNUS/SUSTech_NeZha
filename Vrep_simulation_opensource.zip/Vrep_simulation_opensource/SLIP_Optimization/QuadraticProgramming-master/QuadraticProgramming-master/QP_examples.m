%% This script contains QPs solved by the given framework.

%% For computing derivatives we import casADi.
import casadi.*

%% QP Example 1 (simple constrained QP)
H = [2, 1; 1, 1]; g = 0; A = [1, 1]; b = 0; x0 = [1; 1]; 
[ x_sol, lambda_sol ] = SchurComplementMethod(H, g, A, b, x0);

%% QP Example 2 (simple constrained QP, 16.11 Nocedal & Wright)
H = [1, -1; -1, 2]; g = [-2; -6];
A = [-0.5, -0.5; 1, -2; 1, 0; 0, 1]; b = [-1; -2; 0; 0]; 

% Three different starting points:
x1 = [0.5; 0.5];        % interior
x2 = [0; 0];            % vertex
x3 = [0.5; 0];          % edge
x4 = [0.12; 0.3];       % edge
[ x1_sol, lambda1_sol, W1_sol ] = ActiveSet(H,g,A,b,x1,[],[1 2 3 4],[], true);
[ x2_sol, lambda2_sol, W2_sol ] = ActiveSet(H,g,A,b,x2,[3 4],[1 2 3 4],[], true);
% [ x1_IP, lambda1_IP ] = InteriorPoint(H,g,A,b,x2,[1;1;1;1],[0;0;0;0],true);

% TODO: Make quadprog work.
%x_quadprog = quadprog(H, g, A, b);
%diff = norm(x1_sol - x_quadprog);
%disp(['Difference between quadprog and active set method: ', num2str(diff)]);

% Create polygon shape.
vertices = [0 0; 0 1; 2/3 4/3; 2 0; 0 0];
pgon = polyshape(vertices);

% Plort regions and steps.
RegionPlot(H, g, pgon, x1_sol, 1);
RegionPlot(H, g, pgon, x2_sol, 2);
% RegionPlot(H, g, pgon, x1_IP, 3);

%% QP Example 3 (simple constrained QP, 16.1 Nocedal & Wright)
H = [4, 1; 1, 1]; g = [2; 3];
A = [1, -1; -1, -1; -1, 0;]; b = [0; -4; -3]; 

x1 = [2; 0];
[ x1_sol, lambda1_sol, W1_sol ] = ActiveSet(2*H,g,A,b,x1,[],[1 2 3],[], true);

vertices = [-3 -10; -3 -3; 2 2; 16 -10; -3 -10];
pgon = polyshape(vertices);

RegionPlot(H, g, pgon, x1_sol, 1);

%% QP Example 4 (simple constrained QP, 16.17 Nocedal & Wright)
H = [1, 0; 0, 1]; g = [-6; -4];
A = [-1 -1; 1 0; 0 1]; b = [-3; 0; 0]; 

x1 = [1/2; 1/2];
[ x1_sol, lambda1_sol, W1_sol ] = ActiveSet(2*H,g,A,b,x1,[],[1 2 3],[], true);

vertices = [0 0; 0 3; 3 0; 0 0];
pgon = polyshape(vertices);

RegionPlot(H, g, pgon, x1_sol, 1);

%% QP Example 5 (bounded QP, 16.26 Nocedal & Wright)
H = [4, 1; 1, 2]; g = [-1; 1]; 
A = [1, 0; 0, 1; -1, 0; 0 -1]; b = [0; 0; -5; -3];
l = [0; 0]; u = [5; 3];

x1 = [0; 2];
tic;
[ x1_sol, lambda1_sol, W1_sol ] = ActiveSet(H,g,A,b,x1,[1],[1 2 3 4],[], true);
active_set = toc;

tic;
[ x1_projected ] = GradientProjection(H, g, l, u, true);
gradient_proj = toc;

disp('Time for solving QP:');
disp('method       | steps | time ');
disp(['active set  | ', num2str(size(x1_sol,2)), '  |  ', num2str(active_set)]);
disp(['gradi proj  | ', num2str(size(x1_projected,2)), '  |  ', num2str(gradient_proj)]);


vertices = [0 0; 0 3; 5 3; 5 0; 0 0];
pgon = polyshape(vertices);

RegionPlot(H, g, pgon, x1_sol, 1);
RegionPlot(H, g, pgon, x1_projected, 1);

%% QP Example 6 (5 dimensional  problem self designed)
H = [1  1  1  1  1;
     1  5 17  3  5;
     1 17 69 17 23;
     1  3 17 22 23;
     1  5 23 23 55];
 g = [1; 2; -8; 20; 0];
A = [eye(5), zeros(5,5);
     zeros(5,5), -eye(5)];
b = [10; 5; 9; 20; 2; -2; -20; 0; -3; -10]; 
l = [-2; -20; 0; -3; -10];
u = [10; 5; 9; 20; 2];

x1 = zeros(5,1);
[ sol_AS, ~, ~ ] = ActiveSet(H, g, A, b, x1, [], [1 2 3 4 5 6 7 8 9 10], [], true);
[ sol_GP, ~, ~ ] = GradientProjection(H, g, l, u, true);

vertices = [0 0; 0 3; 3 0; 0 0];
pgon = polyshape(vertices);

RegionPlot(H, g, pgon, x1_sol, 1);

%% QP Example 4 (revisited; Use PhaseI for initial point computation)
H = [1, 0; 0, 1]; g = [-6; -4];
A = [-1 -1; 1 0; 0 1]; b = [-3; 0; 0]; 

x1 = PhaseI(A,b,[1 2 3], [], ones(2,1));
[ x1_sol, lambda1_sol, W1_sol ] = ActiveSet(2*H,g,A,b,x1,[],[1 2 3],[], true);

vertices = [0 0; 0 3; 3 0; 0 0];
pgon = polyshape(vertices);

RegionPlot(H, g, pgon, x1_sol, 1);