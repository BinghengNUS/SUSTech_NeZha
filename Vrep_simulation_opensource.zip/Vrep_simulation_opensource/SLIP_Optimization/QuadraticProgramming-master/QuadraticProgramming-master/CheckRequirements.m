%% This script checks for requirements (currently not checking dimensions) 
function [ flag ] = CheckRequirements(H, A, convex)
if (~issymmetric(H))
    error("Please provide symmetric Hessian H");
end

% Require H to be positve definite.
if (convex)
    [~, flag] = chol(H);
    if (flag ~= 0)
        error("Please provide positive definite Hessian.");
    end
end

%% Currently not checking LICQ.
% Check LICQ if either A or b is set.
%licq_flag = licq(A);
%if (~licq_flag)
%    error("LICQ violated.");
%end
end