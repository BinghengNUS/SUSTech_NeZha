%% This function realizes the ratio test
function [ val, index ] = RatioTest(u, v)
% Require equal sized vectors.
if (size(u) ~= size(v))
    error('Please provide equally sized vectors u and v!');
end

val = inf;
index = -1;

for i = 1:size(v)
    if (v(i) > 0)
        ratio = u(i)/v(i);
        if (ratio < val)
            index = i;
            val = ratio;
        end
    end
end

end