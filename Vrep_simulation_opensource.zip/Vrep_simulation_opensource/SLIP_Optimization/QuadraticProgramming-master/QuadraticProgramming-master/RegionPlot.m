%% Plot a given 2D-region and steps within that region.
function [] = RegionPlot(H, g, pgon, steps, figureID)
% Create figure and clear if existed before.
figure(figureID);
clf(figureID);

% For counter plot.
q = @(x) 1/2*x'*H*x + g'*x;

xmin = min(pgon.Vertices(:,1));
ymin = min(pgon.Vertices(:,2));
xmax = max(pgon.Vertices(:,1));
ymax = max(pgon.Vertices(:,2));
level_width = 100;
x = linspace(xmin - (xmax-xmin)/10, xmax + (xmax-xmin)/10, level_width);
y = linspace(ymin - (ymax-ymin)/10, ymax + (ymax-ymin)/10, level_width);
[X,Y] = meshgrid(x,y);
Z = zeros(level_width,level_width);
for i=1:level_width
    for j=1:level_width
        Z(i,j) = q([X(i,j);Y(i,j)]);
    end
end

% Create the plot.
plot(pgon, 'EdgeColor', 'none'); hold on;
plot(steps(1,1), steps(2,1), 'x');
contour(X,Y,Z);

for i = 2:size(steps, 2)
    p1 = [steps(1,i-1) steps(2,i-1)];
    p2 = [steps(1,i) steps(2,i)];
    dp = p2-p1;
    quiver(steps(1,i-1), steps(2,i-1), dp(1), dp(2), 0);
    % plot([steps(1,i-1) steps(1,i)], [steps(2,i-1) steps(2,i)]);
end
hold off;
end