%% This script checks LICQ of m-n-matrix (m constraints and n variables).
function [ flag ] = licq(A)
% Require less constraints than variables
[m, n] = size(A);

if (m > n)
    flag = false;
    return;
end

if (rank(A) < m)
    flag = false;
    return;
end

flag = true;

end