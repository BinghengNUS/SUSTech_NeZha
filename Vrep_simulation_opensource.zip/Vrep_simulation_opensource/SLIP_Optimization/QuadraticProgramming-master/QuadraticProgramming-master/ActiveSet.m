%% This script solves inequality constrained QPs

function [ x_sol, lambda_sol, W_sol ] = ActiveSet(H, g, A, b, x0, W0, I, E, storeSteps)
%% Requirements (If something fails error will be thrown).
CheckRequirements(H, A, true);

%% Problem set up
[m, n] = size(A);           % Total dimension of problem
Wk = union(W0, E);          % Initial working set
A_sub = A(Wk,1:n);          % Initial working constraint matrix
b_sub = b(Wk,1);            % Initial working constraint vector
mk = size(Wk, 1);           % Initial size of working set
xk = x0;                    % Initial point.
eps = 10e-6;                % Termination epsilon.
x_sol = x0;         
lambda_sol = zeros(m,1);
W_sol = Wk;
k = 1;
%% Main iteration
while (true)   
    k = k + 1;
    [ pk, lambdak ] = SchurComplementMethod(H, g, A_sub, b_sub, xk);
    
    % Step computation
    alph = 1;
    primal_block = 0;
    inactives = setdiff(I, Wk);
    for i = 1:(m-mk)
        tmp = A(inactives(i),1:n)*pk;
        if (tmp < 0)
            new = (b(inactives(i)) - A(inactives(i),1:n)*xk)/tmp;
            if (new < alph)
                alph = new;
                primal_block = inactives(i);
            end
        end
    end
    
    % Compute new step if progress made.
    xk = xk + alph*pk;
    if (storeSteps)
        x_sol(:, k) = xk;
        lambda_sol(:,k) = zeros(m, 1);
        if (mk > 0)
            lambda_sol(Wk,k) = lambdak;
        end
    end
    % primal blocking
    if (alph < 1)
        disp(['Primal blocking detected: Adding constraint ', num2str(primal_block)]);
        Wk = union(Wk, primal_block);
        A_sub = [A_sub; A(primal_block, 1:n)];
        b_sub = [b_sub; b(primal_block,1)];
        mk = mk + 1;
        continue;
    end

    % Found a solution to subproblem.
    if (norm(pk, 2) < eps)
        % Solve for fitting dual variables.
        % lambdak = A_sub'\(H*xk - g);

        % If dual blocking, remove constraint of most negative dual
        lowest = 0;
        for i = 1:mk
            if (lambdak(i) < lowest)
                lowest_index = i;
                lowest = lambdak(i);
            end
        end

        if (lowest < 0)
            disp(['Dual blocking detected: Removing constraint ', num2str(Wk(lowest_index))]);
            index_sub = setdiff(1:mk, lowest_index);
            Wk = setdiff(Wk, Wk(lowest_index));
            mk = mk - 1;
            A_sub = A_sub(index_sub, :);
            b_sub = b_sub(index_sub, :);
        else
            disp('Solution found!');
            W_sol = Wk;
            if (~storeSteps)
                x_sol = xk;
                lambda_sol = zeros(m, 1);
                lambda_sol(W_sol) = lambdak;
            end
            return;
        end
    end
end