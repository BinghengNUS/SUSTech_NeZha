function dx = flydyn(t,x,alpha)
dx1 = x(2);
[P0,P1,P2]= poly(t);
L   = P0*alpha;
dL  = P1*alpha;
dx2 = -2*dL/L*x(2);
dx  = [dx1;dx2];