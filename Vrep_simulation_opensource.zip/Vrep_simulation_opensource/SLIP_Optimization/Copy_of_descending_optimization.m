%*************************************************************************
% Trajectory Optimization using SLIP model
% This code aims to optimize the C.O.M trajectory by optimizing the
% external force acting on the spring
% 'CVX' matlab package, by Bingheng WANG, on Jan/02/2020*******************
clear all
g  = 9.8;%gravitational acceleration
m  = 13;%total mass
L0 = 0.6;%length of the leg
Ks  = 1274;
x0 = [0.7;0];%initial states
xf = [0.526;0];%final states
ddz= Ks*(L0+0.2-xf(1))/m-g;%desired terminal acceleration
dt  = 0.002;
dtm = 0.01;
x_L= [0.526;-0.2];
x_U= [0.7;0];
X_L= zeros(20,1);
X_U= zeros(20,1);
u_max=2*m*g;
u_min=-2*m*g;
kd = 1000;
kp = 2000;
R  = 0.00001;
Q  = diag([20000,20000]);
Qt = diag([50000,50000]);%terminal penalty on state
Qta= 50000;%terminal penalty on acceleration
for k=1:2:19
    X_L(k:k+1)=x_L;
    X_U(k:k+1)=x_U;
end
x_t = x0;%initialization
j   = 1;
for t = dt:dt:2
    cvx_begin %quiet
    variable u(10,1) %external control forc
    x_tm= x_t;
    u0  = 0;
    i   = 1;
    k   = 1;
    J   = (x_tm-xf).'*Q*(x_tm-xf)+R*u0^2;%R*((Ks*(L0+0.2-x_t(1))+u0)/m-g)^2;
    for tmpc=dtm:dtm:0.1
        x_tm = x_tm+dtm*[x_tm(2);(Ks*(L0+0.2-x_tm(1))+u(i))/m-g];%prediction 
        X(k:k+1,1) = x_tm;
        ddz_t=(Ks*(L0+0.2-x_tm(1))+u(i))/m-g;
        ddX(i)=ddz_t;
        if tmpc==0.1
            J=J+(x_tm-xf).'*Qt*(x_tm-xf)+Qta*(ddz_t-ddz)^2;
        else
            J = J+(x_tm-xf).'*Q*(x_tm-xf)+R*u(i)^2;%R*((Ks*(L0+0.2-x_t(1))+u(i))/m-g)^2;
        end
        i = i+1;
        k = k+2;
    end
     minimize(J);
    subject to
    X<=X_U;
    X>=X_L;
    u<=u_max*ones(10,1);
    u>=u_min*ones(10,1);
%     x_t==xf;
%     ddz_t==Ks*(L0+0.2-xf(1))/m-g;% u_tf =0 ensures the smooth transfer to the pure spring force
    cvx_end
    dzd = x_tm(2);
    zd  = x_tm(1);
    x_d(j)=x_tm(1);
%     dzd = X(2);
%     zd  = X(1);
    ut  = ddX(1)+kd*(dzd-x_t(2))+kp*(zd-x_t(1))-Ks*(L0+0.2-x_t(1));%+m*g;
    x_t = x_t+dt*[x_t(2);(Ks*(L0+0.2-x_t(1))+ut)/m-g];%prediction 
    z_descending(j)=x_t(1);
    dz_descending(j)=x_t(2);
    ddz_descending(j)=(Ks*(L0+0.2-x_t(1))+ut)/m-g;
     Fopt(j)=ut;
     j = j+1
     clear X
     clear ddX
end
   