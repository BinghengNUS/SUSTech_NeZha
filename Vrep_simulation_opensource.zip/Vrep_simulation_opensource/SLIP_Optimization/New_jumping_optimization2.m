%*************************************************************************
% Jumping Optimization using a Template Spring Model with the Change of
% Resting Length as Control Input, programmed by CVX Package
%*************By Bingheng WANG, on Feb 29,2020****************************
clear all
%------------------%
%Parameters Setting
%------------------%
g    = 9.8;
m    = 9.568;%total mass
kp   = 100;%proportional coefficient of knee torque
kd   = 10;%damping coefficient of knee torque
dt   = 0.001;%sampling time
r    = 0.1;%radius of wheel
Lg   = 0.429;%length of leg (Thigh link and Shank link)
dh   = 0.0474;%height of base c.o.m relative to the hip joint
%---------------------------------------%
%Initial States and Desired Final States
%---------------------------------------%
L0   = 2*Lg;%initial resting length of the spring excluding r and dh
z0   = 0.91;%initial actual length of the spring including r and dh
dz0  = 0;%initial velocity of actual length
Tf   = 0.6;%final time
%calculate the desired final height and velocity
zdes = 1.2;%desired peak in flight
zf   = z0;%final height
dzf  = sqrt((zdes-zf)*2*g);%final velocity
%-------------------%
%Constraints Setting
%-------------------%
Lmin = 0.2;
Lmax = 2*Lg;
Ksmax= 4*kp/(Lmin^2);
Ksmin= 4*kp/(Lmax^2);
zmin = Lmin+r+dh;
zmax = z0;
Z_L  = zmin*ones(Tf/dt,1);%lower bound vector
Z_U  = zmax*ones(Tf/dt,1);%upper bound vector
dzmin= -4;
dzmax= 2*dzf;
dZ_L = dzmin*ones(Tf/dt,1);
dZ_U = dzmax*ones(Tf/dt,1);
Ks   = 1/2*(Ksmax+Ksmin);%spring constant stiffness
umax = (L0+r-zmin)*(Ksmax-Ks)/Ks;
umin = (L0+r-zmin)*(Ksmin-Ks)/Ks;
U_L  = umin*ones(Tf/dt,1);
U_U  = umax*ones(Tf/dt,1);
cvx_begin
    variable u(Tf/dt,1);%Stiffness
    %------Initialization------%
    z   = z0;
    dz  = dz0;
    u0  = 0;
    i   = 1;
    Z   = cvx(zeros(Tf/dt,1));%;
    dZ  = cvx(zeros(Tf/dt,1));
    FS  = cvx(zeros(Tf/dt,1));
    %------Iteration of Dynamic Model------%
    for t=dt:dt:Tf
        s       = L0+r+dh+u(i)-z;%spring deformation
        Fs      = Ks*s;%spring force 
        ddz     = Fs/m-g;
        %-----update-----%
        dz      = dz+dt*ddz;
        z       = z+dt*dz;
        Z(i,1)  = z;
        dZ(i,1) = dz;
        FS(i,1) = Fs;
        ddZ(i,1)= ddz;
        i       = i+1;
        time(i) = t;
    end
    J  =  1/2*[z-zf,dz-dzf]*[z-zf;dz-dzf];%final cost only, no running cost
    minimize(J)
    subject to
    %-----State Constraint-----%
    Z <= Z_U;
    Z >= Z_L;
    dZ<= dZ_U;
    dZ>= dZ_L;
%     Fs==0;
    %-----Control Constraint-----%
    u <= U_U;
    u >= U_L;
cvx_end