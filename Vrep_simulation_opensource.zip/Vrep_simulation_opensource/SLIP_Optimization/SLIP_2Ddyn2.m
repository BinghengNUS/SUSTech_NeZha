function dx = SLIP_2Ddyn2(t,x,alphaL,betax,m,L0,Ks,g) 
%This function returns the derivative of the state (L,theta,dL,dtheta) of
%the 2D SLIP model with the length change and linear acceleration as
%control inputs.
[P0,~,P2] = poly(t);
Lt         = P0*alphaL;
ddLt       = P2*alphaL;
delL       = (m*ddLt+m*g-Ks*(L0-Lt))/Ks;
ddx        = P2*betax;
L    = x(1);
theta= x(2);
dL   = x(3);
dtheta = x(4);
dx1  = x(3);
dx2  = x(4);
dx3  = (Ks*delL-m*sin(theta)*ddx+Ks*(L0-L)-m*g*cos(theta)+m*L*dtheta^2)/m;%
dx4  = (m*g*L*sin(theta)-2*m*L*dL*dtheta-m*cos(theta)*L*ddx)/(m*L^2);%
dx   = [dx1;dx2;dx3;dx4];