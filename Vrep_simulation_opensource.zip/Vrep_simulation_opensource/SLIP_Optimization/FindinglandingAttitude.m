%*************************************************************************
% Find out optimal landing attitude that leads to the minimum cost value
%**********************By Bingheng WANG, on May 9, 2020*******************
clear all
%Parameters Setting
Lds     = 0.72;
r       = 0.1;
dh      = 0.0474;
L0      = Lds+dh;
H_ob    = 0.5;
m       = 9.5;%6.68
mb      = 3.2;%2.88
kL      = m/(m+mb);
zmax    = 0.8;%kL*L0+H_ob+r;
v_ref   = 1;
kp      = 30;
%Matrix Setting
Nopt    = 10;
N       = 20;
Nv      = 11;
the_min = -7/180*pi;
the_max = 13/180*pi;
v_min   = 0.9*v_ref;
v_max   = 2*v_ref;
Fval    = zeros(Nv+1,N+1);
FVals   = zeros(Nv+1,N+1);
delv    = (v_max-v_min)/Nv;
delthe  = (the_max-the_min)/N;
%Solving optimal problem
i       = 1;
j       = 1;
eps     = 0.2;
vxd     = 1.6;
for v_0 = v_min:delv:v_max
    for theta_0 = the_min:delthe:the_max
        Jval = LandingAttitude(zmax,Lds,kp,theta_0,v_0,v_ref,Nopt);
        Fval(i,j)   = Jval;
        if v_0<=vxd+eps && v_0>=vxd-eps
            FVals(i,j) = Jval;        
        end
        j           = j+1;
    end
    j   = 1;
    i   = i+1;
end
v_0     = v_min:delv:v_max;
theta_0 = the_min:delthe:the_max;
[X,Y]=meshgrid(theta_0*180/pi,v_0);
figure(1)
surf(X,Y,Fval);
% hold on;
% imagesc('XData',v_0,'YData',theta_0,'CData',Fval);
colorbar
ylabel('Velocity [m/s]');
xlabel('Pitch Angle [deg]');
zlabel('Cost Value');
%find gloablly optimal landing attitude corresponding to minimal cost value
m  = min(Fval);
mm = min(m);
[row,column]=find(Fval==mm);
vopt     = v_0(row);
pitchopt = theta_0(column)*180/pi;
figure(2)
  ind = find(FVals == 0);
  FVals(ind)=nan;
surf(X,Y,FVals);
colorbar
ylabel('Velocity [m/s]');
xlabel('Pitch Angle [deg]');
zlabel('Cost Value');
mL  = min(FVals);
mmL = min(mL);
[rowL,columnL]=find(FVals==mmL);
Lvopt = v_0(rowL);
Lpitchopt= theta_0(columnL)*180/pi;