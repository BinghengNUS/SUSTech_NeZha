function [dPf,Pf,dJf,Jf]=foot_trajectory(dq,q,dpitch,pitch,vbase,Lg,dh)
Pl=[-dh*sin(pitch)+Lg*sin(q(1)-pitch)+Lg*sin(q(1)+q(3)-pitch);
     -dh*cos(pitch)-Lg*cos(q(1)-pitch)-Lg*cos(q(1)+q(3)-pitch)];
Pr=[-dh*sin(pitch)+Lg*sin(q(2)-pitch)+Lg*sin(q(2)+q(4)-pitch);
     -dh*cos(pitch)-Lg*cos(q(2)-pitch)-Lg*cos(q(2)+q(4)-pitch)];
Pf=[Pl;Pr];
%% Jacobian Matrix for Forward Kinematics
Jzbl = dh*sin(pitch)-Lg*sin(q(1)-pitch)-Lg*sin(q(1)+q(3)-pitch);
dJzbl= dh*cos(pitch)*dpitch-Lg*cos(q(1)-pitch)*(dq(1)-dpitch)-Lg*cos(q(1)+q(3)-pitch)*(dq(1)+dq(3)-dpitch);
Jzhl = Lg*sin(q(1)-pitch)+Lg*sin(q(1)+q(3)-pitch);
dJzhl= Lg*cos(q(1)-pitch)*(dq(1)-dpitch)+Lg*cos(q(1)+q(3)-pitch)*(dq(1)+dq(3)-dpitch);
Jzkl = Lg*sin(q(1)+q(3)-pitch);
dJzkl= Lg*cos(q(1)+q(3)-pitch)*(dq(1)+dq(3)-dpitch);
Jxbl =-dh*cos(pitch)-Lg*cos(q(1)-pitch)-Lg*cos(q(1)+q(3)-pitch);
dJxbl= dh*sin(pitch)*dpitch+Lg*sin(q(1)-pitch)*(dq(1)-dpitch)+Lg*sin(q(1)+q(3)-pitch)*(dq(1)+dq(3)-dpitch);
Jxhl = Lg*cos(q(1)-pitch)+Lg*cos(q(1)+q(3)-pitch);
dJxhl=-Lg*sin(q(1)-pitch)*(dq(1)-dpitch)-Lg*sin(q(1)+q(3)-pitch)*(dq(1)+dq(3)-dpitch);
Jxkl = Lg*cos(q(1)+q(3)-pitch);
dJxkl=-Lg*sin(q(1)+q(3)-pitch)*(dq(1)+dq(3)-dpitch);

Jzbr = dh*sin(pitch)-Lg*sin(q(2)-pitch)-Lg*sin(q(2)+q(4)-pitch);
dJzbr= dh*cos(pitch)*dpitch-Lg*cos(q(2)-pitch)*(dq(2)-dpitch)-Lg*cos(q(2)+q(4)-pitch)*(dq(2)+dq(4)-dpitch);
Jzhr = Lg*sin(q(2)-pitch)+Lg*sin(q(2)+q(4)-pitch);
dJzhr= Lg*cos(q(2)-pitch)*(dq(2)-dpitch)+Lg*cos(q(2)+q(4)-pitch)*(dq(2)+dq(4)-dpitch);
Jzkr = Lg*sin(q(2)+q(4)-pitch);
dJzkr= Lg*cos(q(2)+q(4)-pitch)*(dq(2)+dq(4)-dpitch);
Jxbr =-dh*cos(pitch)-Lg*cos(q(2)-pitch)-Lg*cos(q(2)+q(4)-pitch);
dJxbr= dh*sin(pitch)*dpitch+Lg*sin(q(2)-pitch)*(dq(2)-dpitch)+Lg*sin(q(2)+q(4)-pitch)*(dq(2)+dq(4)-dpitch);
Jxhr = Lg*cos(q(2)-pitch)+Lg*cos(q(2)+q(4)-pitch);
dJxhr=-Lg*sin(q(2)-pitch)*(dq(2)-dpitch)-Lg*sin(q(2)+q(4)-pitch)*(dq(2)+dq(4)-dpitch);
Jxkr = Lg*cos(q(2)+q(4)-pitch);
dJxkr=-Lg*sin(q(2)+q(4)-pitch)*(dq(2)+dq(4)-dpitch);

Jf   = [zeros(4,4),[Jxbl;Jzbl;Jxbr;Jzbr],zeros(4,1),[Jxhl,Jxkl;Jzhl,Jzkl;zeros(2,2)],zeros(4,1),[zeros(2,2);Jxhr,Jxkr;Jzhr,Jzkr],zeros(4,1)];
dJf  = [zeros(4,4),[dJxbl;dJzbl;dJxbr;dJzbr],zeros(4,1),[dJxhl,dJxkl;dJzhl,dJzkl;zeros(2,2)],zeros(4,1),[zeros(2,2);dJxhr,dJxkr;dJzhr,dJzkr],zeros(4,1)];
dPf  = Jf*[vbase;0;dpitch;0;q(1);q(3);q(5);q(2);q(4);q(6)]; 