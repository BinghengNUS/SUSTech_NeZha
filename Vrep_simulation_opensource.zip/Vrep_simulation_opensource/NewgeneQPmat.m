function [Q,f,Aeq,beq] = NewgeneQPmat(H,C,ddwc,Ja,dJa,dx,ref)
Snew = [zeros(6,4);[eye(2),zeros(2,2)];zeros(1,4);[zeros(2,2),eye(2)];zeros(1,4)];%control matrix for hip and knee torques
Sw   = [zeros(8,2);[1,0];zeros(2,2);[0,1]];% control matrix for wheel torque
Qq = Ja'*Ja;
fq = (dJa*dx-ref)'*Ja;

Q = blkdiag(Qq,zeros(4,4));
f = [fq, zeros(1,4)]';

Aeq = [H, -Snew];
beq = -Sw*ddwc-C;%Note the nagetive wheel torque due to the rotational axis of z
Aeq = double(Aeq);
beq = double(beq);
Q = double(Q);
f = double(f);