function tau = JointTorques(AtsL,AtsR,Atf,dAtsL,dAtsR,dAtf,state,dstate,shanktilt,dshanktilt,ddshanktilt,ddxtscL,ddxtscR,ddxtfc,theta,dtheta,ddtheta,ddq,Llqr,dLlqr,torq_lqr,psym,torqueLimit,wheelzposition) 
%This function returns the joint torques for the task-space control, which
%includes two hip joint torques, two knee joint torques and two wheel joint
%torques. All torques are obtained by quadratic programming based on a full
%dynamic model
%psym  = [r,d,g,Lg,Ltcom,Lscom,dh,dhs,mfb,mtl,msl,mw,mu];%system parameter vector
%*********************By Bingheng WANG, on Mar.8 2020*********************
if wheelzposition <=0.102%stance phase
    %---------------------------------------%
    %model in the sagittal plane (fixed base)
    %---------------------------------------%
    handle.NB = 3;
    handle.parent = [0 1 2];%shank link, thigh link and base
    handle.jtype = {'Ry', 'Ry', 'Ry'};
    handle.Xtree{1} = eye(6);
    handle.Xtree{2} = xlt([0,0.0605,-psym(4)]);%Adjoint Matrix from {parent i} to {i}
    handle.Xtree{3} = xlt([0,0.0385,-psym(4)]);
    mass = psym(11);%Shank link
    CoM = [0,0,psym(4)+psym(6)];
    Icm = diag([0.0175958448813304,0.0177210394041728,0.000378821101531682]);
    handle.I{1} = mcI( mass, CoM, Icm );
    mass = psym(10);%Thigh link
    CoM = [0,0,psym(4)+psym(5)];
    Icm =  diag([0.0223883715246182,0.022309557436881,0.00172727939342223]);
    handle.I{2} = mcI( mass, CoM, Icm );
    mass = 1/2*psym(9);%half of base
    CoM = [0,0,psym(7)];
    Icm =  diag(1/2*[0.0261376195979353,0.0249232975683053,0.0143828822217345]);
    handle.I{3} = mcI( mass, CoM, Icm );
    %compute H and C matrices given the q qd f_ext
    statesL = [shanktilt(1);state(8);state(7)];
    dstatesL= [dshanktilt(1);dstate(8);dstate(7)];
    [ML,CL] = HandC(handle, statesL, dstatesL, []);
    statesR = [shanktilt(2);state(11);state(10)];
    dstatesR= [dshanktilt(2);dstate(11);dstate(10)];
    [MR,CR] = HandC(handle, statesR, dstatesR, []);
    %---------------------------------%
    %Quadratic programming formulation
    %---------------------------------%
    A1L   = AtsL(1);
    AkhL  = [AtsL(2),AtsL(3)];
    dA1L  = dAtsL(1);
    dAkhL = [dAtsL(2),dAtsL(3)];
    HsL   = AkhL.'*AkhL;
    fsL   = AkhL.'*(dA1L*dshanktilt(1)+A1L*ddshanktilt(1)+dAkhL*[dstate(8);dstate(7)]-ddxtscL);
    HsqpL = blkdiag(HsL,zeros(2,2));
    fsqpL = [fsL;zeros(2,1)];
    H1L   = ML(1,1);
    H1khL = [ML(1,2),ML(1,3)];
    HkhL  = [ML(2,2),ML(2,3);
             ML(3,2),ML(3,3)];
    AeqsL = [HkhL-H1khL.'*H1L^(-1)*H1khL,-eye(2)];
    C1sL  = CL(1);
    CkhL  = [CL(2);CL(3)];
    beqsL = H1khL.'*H1L^(-1)*C1sL-CkhL;
    lb    = [-torqueLimit(3);-torqueLimit(1)];%knee torque first
    ub    = [torqueLimit(3);torqueLimit(1)];
    [slnL,optC] = quadprog(HsqpL,fsqpL,[],[],AeqsL,beqsL,lb,ub);
    kneetorqueL = slnL(1);
    hiptorqueL  = slnL(2);
    A1R   = AtsR(1);
    AkhR  = [AtsR(2),AtsR(3)];
    dA1R  = dAtsR(1);
    dAkhR = [dAtsR(2),dAtsR(3)];
    HsR   = AkhR.'*AkhR;
    fsR   = AkhR.'*(dA1R*dshanktilt(2)+A1R*ddshanktilt(2)+dAkhR*[dstate(11);dstate(10)]-ddxtscR);
    HsqpR = blkdiag(HsR,zeros(2,2));
    fsqpR = [fsR;zeros(2,1)];
    H1R   = MR(1,1);
    H1khR = [MR(1,2),MR(1,3)];
    HkhR  = [MR(2,2),MR(2,3);
             MR(3,2),MR(3,3)];
    AeqsR = [HkhR-H1khR.'*H1R^(-1)*H1khR,-eye(2)];
    C1sR  = CR(1);
    CkhR  = [CR(2);CR(3)];
    beqsR = H1khR.'*H1R^(-1)*C1sR-CkhR;
    lb    = -[torqueLimit(4);torqueLimit(2)];%knee torque first
    ub    = [torqueLimit(4);torqueLimit(2)];
    [slnR,optC] = quadprog(HsqpR,fsqpR,[],[],AeqsR,beqsR,lb,ub);
    kneetorqueR = slnR(1);
    hiptorqueR  = slnR(2);
    %----------------------------------------------------%
    %Compensation for the effect of knee torques on wheel
    %----------------------------------------------------%
    mxw   =   psym(9)+2*(psym(10)+psym(11));
    if state(8)~=0 && state(8)~= pi
      Fl     = torqlknee/(-Lg*sin(state(8)/2)); 
    else
        Fl   = mxw/2*(sin(theta)*psym(1)*(ddtheta+ddq(5))-Llqr*dtheta^2+psym(3)*cos(theta));
    end
    if state(11)~=0 && state(11)~= pi
      Fr     = torqrknee/(-Lg*sin(state(11)/2)); 
    else
        Fr   = mxw/2*(sin(theta)*psym(1)*(ddtheta+ddq(6))-Llqr*dtheta^2+psym(3)*cos(theta));
    end
    mddlL = Fl+mxw/2*(-psym(3)*cos(theta)+Llqr*dtheta^2-sin(theta)*psym(1)*(ddtheta+ddq(5)));
    mddlR = Fr+mxw/2*(-psym(3)*cos(theta)+Llqr*dtheta^2-sin(theta)*psym(1)*(ddtheta+ddq(6)));
    MfriL = (Fl*cos(theta)+psym(3))*psym(13)*psym(1);%compensation for the frictional torque
    MfriR = (Fr*cos(theta)+psym(3))*psym(13)*psym(1);
    wheeltorqueL = torq_lqr(1)+mddlL*sin(theta)*psym(1)+2*5.5*psym(1)*dLlqr*dtheta*cos(theta)+MfriL;
    wheeltorqueR = torq_lqr(2)+mddlR*sin(theta)*psym(1)+2*5.5*psym(1)*dLlqr*dtheta*cos(theta)+MfriR;
    tau   = [hiptorqueL;hiptorqueR;kneetorqueL;kneetorqueR;wheeltorqueL;wheeltorqueR];
else%flight phase
    %--------------------------%
    %full model (floating base)
    %--------------------------%
%     handle.NB = 7;
%     handle.parent = [0 1 2 3 1 5 6];%left part first, then right part
%     handle.jtype = {'Ry', 'Ry', 'Ry', 'Ry','Ry','Ry','Ry'};
%     handle.Xtree{1} = eye(6);
%     handle.Xtree{2} = xlt([0,-0.0762,0]);%Adjoint Matrix from {parent i} to {i}
%     handle.Xtree{3} = xlt([0,-0.0385,psym(4)]);
%     handle.Xtree{4} = xlt([0,-0.0605,psym(4)]);
%     handle.Xtree{5} = xlt([0,0.0762,0]);
%     handle.Xtree{6} = xlt([0,0.0385,psym(4)]);
%     handle.Xtree{7} = xlt([0,0.0605,psym(4)]);
%     mass = psym(9);%half of base
%     CoM = [0,0,psym(7)];
%     Icm =  diag([0.0261376195979353,0.0249232975683053,0.0143828822217345]);
%     handle.I{1} = mcI( mass, CoM, Icm );
%     mass = psym(10);%Thigh link
%     CoM = [0,0.0637001804791891,psym(5)];
%     Icm =  diag([0.0223883715246182,0.022309557436881,0.00172727939342223]);
%     handle.I{2} = mcI( mass, CoM, Icm );
%     mass = psym(11);%Shank link
%     CoM = [0,0.0364494458894979,psym(6)];
%     Icm = diag([0.0175958448813304,0.0177210394041728,0.000378821101531682]);
%     handle.I{3} = mcI( mass, CoM, Icm );
%     mass = psym(12);%Wheel link
%     CoM = [0,0.013,0];
%     Icm = diag([0.00249269451196491,0.0049481769879587,0.00249269451196491]);
%     handle.I{4} = mcI( mass, CoM, Icm );
%     mass = psym(10);%Thigh link
%     CoM = [0,-0.0637001804791891,psym(5)];
%     Icm =  diag([0.0223883715246182,0.022309557436881,0.00172727939342223]);
%     handle.I{5} = mcI( mass, CoM, Icm );
%     mass = psym(11);%Shank link
%     CoM = [0,-0.036449445889498,psym(6)];
%     Icm = diag([0.0175958448813304,0.0177210394041728,0.000378821101531682]);
%     handle.I{6} = mcI( mass, CoM, Icm );
%     mass = psym(12);%Wheel link
%     CoM = [0,-0.0129851806070332,0];
%     Icm = diag([0.00249269451196491,0.0049481769879587,0.00249269451196491]);
%     handle.I{7} = mcI( mass, CoM, Icm );
%     handle_fb   = floatbase(handle);
%     [M,C]       = HandC(handle_fb, state, dstate, []);
%     %---------------------------------%
%     %Quadratic programming formulation
%     %---------------------------------%
%     Hf    = Atf.'*Atf;
%     ff    = Atf.'*(dAtf*dstate-ddxtfc);
%     Hfqp  = blkdiag(Hf,zeros(6,6));
%     ffqp  = [ff;zeros(6,1)];
%     Sf    = [zeros(6,6);eye(6)];
%     Aeqf  = [M,-Sf];
%     beqf  = -C;
%     lb    = -[torqueLimit(1);torqueLimit(3);torqueLimit(5);torqueLimit(2);torqueLimit(4);torqueLimit(6)];
%     ub    = [torqueLimit(1);torqueLimit(3);torqueLimit(5);torqueLimit(2);torqueLimit(4);torqueLimit(6)];
%     [slnf,optC] = quadprog(Hfqp,ffqp,[],[],Aeqf,beqf,lb,ub);%hip, knee, wheel, followed by right side
%     tau   = [slnf(1);slnf(4);slnf(2);slnf(5);slnf(3);slnf(6)];
      kp    = 5;
      kd    = 2;
      hiptorqueL  = -kd*dstate(7)+kp*(pi/6-state(7));
      hiptorqueR  = -kd*dstate(10)+kp*(pi/6-state(10));
      kneetorqueL = -kd*dstate(8)+kp*(-pi/3-state(8));
      kneetorqueR = -kd*dstate(11)+kp*(-pi/3-state(11));
      wheeltorqueL= 0;
      wheeltorqueR= 0;
      tau   = [hiptorqueL;hiptorqueR;kneetorqueL;kneetorqueR;wheeltorqueL;wheeltorqueR];
end
