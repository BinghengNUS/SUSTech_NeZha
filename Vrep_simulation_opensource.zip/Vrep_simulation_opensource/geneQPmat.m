function [Q,f,Aeq,beq] = geneQPmat(H,C,Ja,dJa,dx,ref)
S = [zeros(6,6);eye(6)];

Qq = Ja'*Ja;
fq = (dJa*dx-ref)'*Ja;

Q = blkdiag(Qq,zeros(6));
f = [fq, zeros(1,6)]';

Aeq = [H, -S];
beq = C;

Q = double(Q);
f = double(f);