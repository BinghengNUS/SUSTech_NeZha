function [ddPfd,dPfd,Pfd,zw]=desired_foot_trajectory(vzb0,zb0,azb,vzb,zb,tfly,dzmin,r,g)
    %% calculate the polynomial of the wheel height in inertial frame
    tup     = vzb0/g;%rise time
    zbmax   = vzb0^2/(2*g)+zb0;
    zwmax   = zbmax-dzmin;% the maximal height of the wheel in inertial frame
    A       = [  tup^5,   tup^4,  tup^3;
               5*tup^4, 4*tup^3,3*tup^2;
              20*tup^3,12*tup^2,6*tup];
    bup     = [zwmax-r;0;-g];
    bdown   = [r-zwmax+g*tup^2/2;g*tup;g];
    paraup  = A^(-1)*bup;%parameters of polynomial a5, a4, a3 in up phase
    paradown= A^(-1)*bdown;%parameters of polynomial a5, a4, a3 in down phase
    %% calculate the desired foot trajectory
    if tfly<=tup
        zw  = paraup(1)*tfly^5+paraup(2)*tfly^4+paraup(3)*tfly^3+r;
        vw  = 5*paraup(1)*tfly^4+4*paraup(2)*tfly^3+3*paraup(3)*tfly^2;
        aw  = 20*paraup(1)*tfly^3+12*paraup(2)*tfly^2+6*paraup(3)*tfly;
        Pfd  = [0;zw-zb];
        dPfd = [0;vw-vzb];
        ddPfd= [0;aw-azb];
    else
        zw  = paradown(1)*(tfly-tup)^5+paradown(2)*(tfly-tup)^4+paradown(3)*(tfly-tup)^3-g/2*(tfly-tup)^2+zwmax;
        vw  = 5*paradown(1)*(tfly-tup)^4+4*paradown(2)*(tfly-tup)^3+3*paradown(3)*(tfly-tup)^2-g*(tfly-tup);
        aw  = 20*paradown(1)*(tfly-tup)^3+12*paradown(2)*(tfly-tup)^2+6*paradown(3)*(tfly-tup)-g;
        Pfd  = [0;zw-zb];
        dPfd = [0;vw-vzb];
        ddPfd= [0;aw-azb];
    end
        Pfd  = [0;-0.5];
        dPfd = [0;0];
        ddPfd= [0;0];