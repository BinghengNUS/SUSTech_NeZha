%% Configuration codes 
clear all
jointNum=6;   %10
torqueLimit=[60;60;10;10;20;5];
% jointName=["LeftHip_joint","LeftWheel_joint","RightHip_joint",...
%     "RightWheel_joint","Tail_joint","Shoulder_joint","Elbow_joint","Wrist_joint"]; 
jointName=["LeftKnee_joint","RightKnee_joint","LeftWheel_joint","RightWheel_joint","Tail_joint","Wrist_joint"];  
%jointName=["LeftWheel_joint","RightWheel_joint","Tail_joint","Wrist_joint"];  
displayOn=true;
torque=zeros(jointNum,1); 


%% Connect to the Vrep
% 1. load api library
vrep=remApi('remoteApi'); % using the prototype file (remoteApiProto.m)
% 2. close all the potential link
vrep.simxFinish(-1);   
% 3. wait for connecting vrep, detect every 0.2s
while true
    clientID=vrep.simxStart('127.0.0.1',19997,true,true,5000,5);
    if clientID>-1 
        break;
    else
        pause(0.2);
        disp('please run the simulation on vrep...')
    end
end
disp('Connection success!')
% 4. set the simulation time step
tstep = 0.005;  % 5ms per simulation pass
vrep.simxSetFloatingParameter(clientID,vrep.sim_floatparam_simulation_time_step,tstep,vrep.simx_opmode_oneshot);
% 5. open the synchronous mode to control the objects in vrep
vrep.simxSynchronous(clientID,true);

%% Simulation Initialization
vrep.simxStartSimulation(clientID,vrep.simx_opmode_oneshot);
% get the handles
jointHandle=zeros(jointNum,1); 
for i=1:jointNum  % handles of the left and right arms
    [~,returnHandle]=vrep.simxGetObjectHandle(clientID,char(jointName(i)),vrep.simx_opmode_blocking);
    jointHandle(i)=returnHandle;
end
% set the target velocity to 0.1 and torque to 0
for i=1:jointNum
    vrep.simxSetJointForce(clientID,jointHandle(i),0,vrep.simx_opmode_oneshot);
    vrep.simxSetJointTargetVelocity(clientID,jointHandle(i),0.1,vrep.simx_opmode_oneshot);
end
baseName='Body_link_visual';
wheelName='RightWheel_link_visual';
wheelleft='LeftWheel_link_visual';
Shankleft='LeftShank_link_visual';
Shankright='RightShank_link_visual';
[~,baseHandle]=vrep.simxGetObjectHandle(clientID,baseName,vrep.simx_opmode_blocking);  
[~,wheelHandle]=vrep.simxGetObjectHandle(clientID,wheelName,vrep.simx_opmode_blocking);  
[~,wheelleftHandle]=vrep.simxGetObjectHandle(clientID,wheelleft,vrep.simx_opmode_blocking);  
[~,ShankleftHandle]=vrep.simxGetObjectHandle(clientID,Shankleft,vrep.simx_opmode_blocking);  
[~,ShankrightHandle]=vrep.simxGetObjectHandle(clientID,Shankright,vrep.simx_opmode_blocking);  
vrep.simxSynchronousTrigger(clientID);
disp('Handles available!')
% first call to read the joints' configuration and end-effector pose, the mode is chosen to be simx_opmode_streaming
jointConfig=zeros(jointNum,1); 
% get current joint position
for i=1:jointNum
    [~,jpos]=vrep.simxGetJointPosition(clientID,jointHandle(i),vrep.simx_opmode_streaming);
    if i>=3 && i<=5
      jointConfig(i)=-jpos; % inverse the joint angles of tail and wheel joints
    else
        jointConfig(i)=jpos;
    end
end

% get simulation time
currCmdTime=vrep.simxGetLastCmdTime(clientID);

lastCmdTime=currCmdTime;
jointConfig0=jointConfig;
jointConfigLast=jointConfig+[0;0;43.9823;43.9823;0;0];
[~,baseposition0]=vrep.simxGetObjectPosition(clientID,baseHandle,-1,vrep.simx_opmode_streaming);% defined in inertial frame
[~,wheelposition0]=vrep.simxGetObjectPosition(clientID,wheelHandle,-1,vrep.simx_opmode_streaming);
[~,wheelleftposition0]=vrep.simxGetObjectPosition(clientID,wheelleftHandle,-1,vrep.simx_opmode_streaming);  
[~,Shankleftposition0]=vrep.simxGetObjectPosition(clientID,ShankleftHandle,-1,vrep.simx_opmode_streaming);  
[~,Shankrightposition0]=vrep.simxGetObjectPosition(clientID,ShankrightHandle,-1,vrep.simx_opmode_streaming);  

 pause(0.1)
[~,baseposition0]=vrep.simxGetObjectPosition(clientID,baseHandle,-1,vrep.simx_opmode_buffer);% defined in inertial frame
[~,wheelposition0]=vrep.simxGetObjectPosition(clientID,wheelHandle,-1,vrep.simx_opmode_buffer);
[~,wheelleftposition0]=vrep.simxGetObjectPosition(clientID,wheelleftHandle,-1,vrep.simx_opmode_buffer);  
[~,Shankleftposition0]=vrep.simxGetObjectPosition(clientID,ShankleftHandle,-1,vrep.simx_opmode_buffer);  
[~,Shankrightposition0]=vrep.simxGetObjectPosition(clientID,ShankrightHandle,-1,vrep.simx_opmode_buffer);  
 deltaposition0 = baseposition0-wheelposition0; % position of pendulum relative to the wheel
r = 0.1;%radius of wheel
d = 0.167;%distance from the wheel to the center of body
m = 10;%mass excluding the shanklinks and wheels
mp= 1;%mass of balance block
mt=13;%total mass
g = 9.8;
Lg= 0.3;%length of Thighlink
mb= 8;%mass of the base and the end-effector
mg= 0.5;%mass of the arm and gripper
xg= 0.18;
dx= -0.15;
dh= 0.09;% height of C.O.M of the main body relative to the hip joint
mu=0.001;
yawangle0 = (jointConfigLast(4)-jointConfigLast(3))*r/(2*d);% yaw angle obtained by the difference of the wheel rotation angles
px0 = deltaposition0(1);
py0 = deltaposition0(2);
pz0 = deltaposition0(3);
thetaLast = atan((px0*cos(yawangle0)-py0*sin(yawangle0))/pz0);
 positionswleft0=Shankleftposition0-wheelleftposition0;
    positionswright0=Shankrightposition0-wheelposition0;
    pswlx0 = positionswleft0(1);
    pswly0 = positionswleft0(2);
    pswlz0 = positionswleft0(3);
    pswrx0 = positionswright0(1);
    pswry0 = positionswright0(2);
    pswrz0 = positionswright0(3);
    theta0l = atan((pswlx0*cos(yawangle0)-pswly0*sin(yawangle0))/pswlz0);%tilting angle of Shankleft
    theta0r = atan((pswrx0*cos(yawangle0)-pswry0*sin(yawangle0))/pswrz0);%tilting angle of Shankright
theta0lLast = theta0l;
theta0rLast = theta0r;

vrep.simxSynchronousTrigger(clientID);         % every calls this function, verp is triggered, 50ms by default

%% Simulation Start
t=0;  % start the simulation
k=1;
kdl=1.8;%PID gain for left knee joint
kpl=150;
kil=0.1;
kdr=1.8;
kpr=170;
kir=0.1;
%PD for free-flight 
kdlj=50;
kplj=200;
kdrj=50;
kprj=200;

kpp =3;
kdp =1;
%Matrices for LQR
Q   = diag([1,0.01,0.1,1]);
R   = diag([1,1]);
%PD for the balancing mass pendulum
kp  = 3;
kd  = 1;
errorintegl=0;%angle error integration
errorintegr=0;
errorpostjumpl =0;
errorpostjumpr =0;
theta10l = -60/180*pi;
theta10r = -60/180*pi;
ktl = 25/180*pi;%angle change rate
ktr = 25/180*pi;
basepositionLast=baseposition0;
dqLast = zeros(6,1);
Lp   =0.105;
dl   =0.1;
t2d  =asin(dl/Lp);
tpd  =-mp*g*dl;
xref = [0;0.5;0;0];
kj=2;
flagjump =0;
flagerror =0;
while (vrep.simxGetConnectionId(clientID) ~= -1)  % vrep connection is still active
    % time update
    currCmdTime=vrep.simxGetLastCmdTime(clientID);
    dt=(currCmdTime-lastCmdTime)/1000;              % simulation step, unit: s 
    % read the joints' and tips' configuration (position and velocity)
    for i=1:jointNum
        [~,jpos]=vrep.simxGetJointPosition(clientID,jointHandle(i),vrep.simx_opmode_buffer);
            if i>=3 && i<=5
               jointConfig(i)=-jpos; 
            else
               jointConfig(i)=jpos;
            end
    end
    jointConfig=jointConfig+[0;0;43.9823;43.9823;0;0];
    [~,baseposition]=vrep.simxGetObjectPosition(clientID,baseHandle,-1,vrep.simx_opmode_buffer);% defined in inertial frame
    [~,wheelposition]=vrep.simxGetObjectPosition(clientID,wheelHandle,-1,vrep.simx_opmode_buffer);
    [~,wheelleftposition]=vrep.simxGetObjectPosition(clientID,wheelleftHandle,-1,vrep.simx_opmode_buffer);  
    [~,Shankleftposition]=vrep.simxGetObjectPosition(clientID,ShankleftHandle,-1,vrep.simx_opmode_buffer);  
    [~,Shankrightposition]=vrep.simxGetObjectPosition(clientID,ShankrightHandle,-1,vrep.simx_opmode_buffer);  
    % tilt angle
    BasePosition(:,k)=baseposition.';%save the absolute baseposition
    vbase = (baseposition.'-basepositionLast)/dt;
    gapl  = jointConfigLast(3)-jointConfig(3);
    gapr  = jointConfigLast(4)-jointConfig(4);
    if gapl<=-5 %remove the gap between two wheel angles
        jointConfig(3)=jointConfig(3)-round(abs(gapl)/(2*pi))*2*pi;
    end
    if gapr<=-5
        jointConfig(4)=jointConfig(4)-round(abs(gapr)/(2*pi))*2*pi;
    end
    Jointangle(:,k)=jointConfig;%save the joint angles in joint space
    deltaposition = baseposition-wheelposition; % position of pendulum relative to the wheel
    yawangle = (jointConfig(4)-jointConfig(3))*r/(2*d);% yaw angle obtained by the difference of the wheel rotation angles
    Wheelposition(:,k)=wheelposition;
    px = deltaposition(1);
    py = deltaposition(2);
    pz = deltaposition(3);
    theta = atan((px*cos(yawangle)-py*sin(yawangle))/pz);
    Tiltangle(k)=theta;
    dtheta=(theta-thetaLast)/dt;
    positionswleft=Shankleftposition-wheelleftposition;
    positionswright=Shankrightposition-wheelposition;
    pswlx = positionswleft(1);
    pswly = positionswleft(2);
    pswlz = positionswleft(3);
    pswrx = positionswright(1);
    pswry = positionswright(2);
    pswrz = positionswright(3);
    theta0l = atan((pswlx*cos(yawangle)-pswly*sin(yawangle))/pswlz);%tilting angle of Shankleft
    theta0r = atan((pswrx*cos(yawangle)-pswry*sin(yawangle))/pswrz);%tilting angle of Shankright
    % using Finit Difference Method to get the velocity of joints' configuration (a simple version)
    q=jointConfig;       dQ=(q-jointConfigLast)./dt;  % column vector
     if norm(dQ(1),2)>=1e2
        dq=zeros(6,1);
    else
        dq=dQ;
    end
    
    dtheta0l = (theta0l-theta0lLast)./dt;
    dtheta0r = (theta0r-theta0rLast)./dt;

    dyaw = r/(2*d)*(dq(4)-dq(3));
    Yawrate(k)=dyaw;
    Qdot(:,k)=dq;
    v    = r/2*(dq(3)+dq(4));
    vb    = sqrt(vbase(1)^2+vbase(2)^2);
    Vb(k) = vb;
    Vw(k) = v;
    x    = [theta;v;dyaw;dtheta];
    %control gain for the LQR controller
    Llqr   =sqrt(px^2+pz^2);%length of the pendulum
    K    = LQRcontrol(Llqr,Q,R);
    torq_lqr = -K*(x-xref);%control torque obtained by LQR for wheel motors and pendulum motor 
     theta1dl =theta10l-ktl*t;%desired left knee angle
     theta1dr =theta10r-ktl*t;%desired right knee angle
     if theta1dl<=-105/180*pi 
         t1dl=-105/180*pi;
         ktl  =0;
     else
         t1dl=theta1dl;
         
     end
     if theta1dr<=-105/180*pi
         t1dr=-105/180*pi;
         ktr  =0;
     else
         t1dr=theta1dr;
     end
     Desiredt1l(k)=t1dl;
%      theta2ld = -theta0l-q(3);
%      Theta2ld(k)=theta2ld;
%      dtheta2ld = -dtheta0l-dq(3);
%      theta2rd = -theta0r-q(4);
%      dtheta2rd = -dtheta0r-dq(4);
     Hl       =-1/2*m*g*Lg*sin(theta0l+q(1));
     Hr       =-1/2*m*g*Lg*sin(theta0r+q(2));
%      Hkneel   =-1/2*8.8*g*0.1*sin(theta0l+q(3)+q(1));
%      Hkneer   =-1/2*8.8*g*0.1*sin(theta0r+q(4)+q(2));
     Torqlknee=Hl+kdl*(-ktl-dq(1))+kpl*(t1dl-q(1))+kil*errorintegl;
     Torqrknee=Hr+kdr*(-ktr-dq(2))+kpl*(t1dr-q(2))+kir*errorintegr; 
%      torqlhip =Hkneel+kdlk*(dtheta2ld-dq(1))+kplk*(theta2ld-q(1))+kilk*errorintegkl;
%      torqrhip =Hkneer+kdrk*(dtheta2rd-dq(2))+kprk*(theta2rd-q(2))+kirk*errorintegkr;
     
Error(k)=t1dl-q(1);

  torql=torq_lqr(1);
  torqr=torq_lqr(2);
   if  wheelposition(3)<=1.03 %No jump, jump detection
       torqlknee = Torqlknee;
       torqrknee = Torqrknee;
       Torql     = -torql;
       Torqr     = -torqr;
       thepd  = asin(-(xg*mg/mp+dx)/Lp)+asin(-(Lg*sin(-(q(1)+q(2))/4)/mp+dx)/Lp);
       dthepd = Lg*cos(-(q(1)+q(2))/4)*(dq(1)+dq(2))/4/(mp*Lp*cos(thepd));
       torqp  = kd*(dthepd-dq(5))+kp*(thepd-q(5))-mp*g*Lp*sin((q(1)+q(2))/2+(q(1)+q(2))/4+q(5));

       Torqp     = -torqp;
   else %Leaving the ground
       t1dl=-pi/6;
       t1dr=-pi/6;
       torqlknee = kdlj*(-dq(1))+kplj*(t1dl-q(1))+kil*errorintegl;%-mw*g*L2*sin(theta0l)+
       torqrknee = kdrj*(-dq(2))+kprj*(t1dr-q(2))+kir*errorintegr;%-mw*g*L2*sin(theta0r)+
       Torql     = 0;
       Torqr     = 0;
       thepd  = asin(-(xg*mg/mp+dx)/Lp)+asin(-(Lg*sin(-(q(1)+q(2))/4)/mp+dx)/Lp);
       dthepd = Lg*cos(-(q(1)+q(2))/4)*(dq(1)+dq(2))/4/(mp*Lp*cos(thepd));
       torqp  = kd*(dthepd-dq(5))+kp*(thepd-q(5));
       Torqp     = -torqp;
   end
   if t>=2 && flagjump==0 %Triggering the jump
       torqlknee = kj*(m+2)*g*Lg*sin(theta0l);% positive
       torqrknee = kj*(m+2)*g*Lg*sin(theta0r); 
       thepd  = asin(-(xg*mg/mp+dx)/Lp)+asin(-(Lg*sin(-(q(1)+q(2))/4)/mp+dx)/Lp);
       dthepd = Lg*cos(-(q(1)+q(2))/4)*(dq(1)+dq(2))/4/(mp*Lp*cos(thepd));
       torqp  = kd*(dthepd-dq(5))+kp*(thepd-q(5))-mp*g*Lp*sin((q(1)+q(2))/2+(q(1)+q(2))/4+q(5));
       Torqp     = -torqp;
       flagjump  = 1; % Jump ending
   end
   %contact detection
   Fl     = torqlknee/(-Lg*sin(q(1)/2)); 
  Fr     = torqrknee/(-Lg*sin(q(2)/2)); 
  MfriL = (Fl*cos(theta)+g)*mu*r;
  MfriR = (Fr*cos(theta)+g)*mu*r;

     k=k+1;
    torque = [torqlknee;torqrknee;Torql-MfriL;Torqr-MfriR;Torqp;0];
    %torque = [torq(1);torq(2);-torq(3);0.1];
   
    %torque = [1;1;1];
    % 2. display the acquisition data, or store them if plotting is needed.
%     if displayOn==true
%         disp('joints config:');       disp(q'.*180/pi);
%         disp('joints dconfig:');      disp(dq'.*180/pi);
%     end

    %torque=[20,20,10];

    %   3.3 set the torque in vrep way
    for i=1:jointNum
        if sign(torque(i))<0
            setVel=-9999; % set a trememdous large velocity for the screwy operation of the vrep torque control implementaion
            if torque(i)<-torqueLimit(i)
                setTu=-torqueLimit(i);
            else
                setTu=-torque(i);
            end
        else
            setVel=9999;
            if torque(i)>torqueLimit(i)
                setTu=torqueLimit(i);
            else
                setTu=torque(i);
            end
        end
        vrep.simxSetJointTargetVelocity(clientID,jointHandle(i),setVel,vrep.simx_opmode_oneshot);
        vrep.simxSetJointForce(clientID,jointHandle(i),setTu,vrep.simx_opmode_oneshot);
        Torque(i,k)=setTu; 
    end
    % data recording for plotting
%     E=[E qe];    Q=[Q q];        QD=[QD qd];
%     DQ=[DQ dq];  DQD=[DQD dqd];  TAU=[TAU torque];

    % 4. update vrep(the server side)
    %tipPosLast=tipPos;       
    %tipOrtLast=tipOrt;
    lastCmdTime=currCmdTime;
    jointConfigLast=jointConfig;   
    basepositionLast=baseposition.';
    thetaLast=theta;
    dqLast=dq;
    
       errorintegl=errorintegl+(t1dl-q(1))*dt;
       errorintegr=errorintegr+(t1dr-q(2))*dt; 
    if flagjump==1 && flagerror==0 % post-jump, cleaning the integrated error
        errorintegl=0;
        errorintegr=0;
        flagerror=1;
    end

%     errorintegkl=errorintegkl+(theta2ld-q(1))*dt;
%     errorintegkr=errorintegkr+(theta2rd-q(2))*dt;
    vrep.simxSynchronousTrigger(clientID);
    t=t+dt; % updata simulation time
    Time(k)=t;
end
vrep.simxFinish(-1);  % close the link
vrep.delete();        % destroy the 'vrep' class

%%
% figure(1); hold off;
% subplot(411); plot(E(1,:),'r'); hold on; plot(E(2,:),'b'); title('error')
% subplot(412); plot(Q(1,:),'r'); hold on; plot(Q(2,:),'b');  plot(QD(1,:),'k'); hold on; plot(QD(2,:),'k'); title('trajectory')
% subplot(413); plot(DQ(1,:),'r'); hold on; plot(DQ(2,:),'b');  plot(DQD(1,:),'k'); hold on; plot(DQD(2,:),'k'); title('velocity')
% subplot(414); plot(TAU(1,:),'r'); hold on; plot(TAU(2,:),'b'); title('torque')

