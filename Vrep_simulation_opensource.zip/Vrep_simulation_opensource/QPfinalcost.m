%*************************************************************************
% This function returns some vectors needed for quadratic programming
% function in MATLAB (quadprog(H,f,A,b,Aeq,beq,lb,ub)). The QP of interest
% contains only the final cost.
%***************By Bingheng WANG, on Mar.4, 2020**************************
function [Hqp,fqp,Aqp,bqp]=QPfinalcost(Sx,Su,Sd,I,N,xmax,xmin,xref,x0,D)
% I is an identity matrix with dimension corresponding to states
% xmax and xmin are bounds for states of the original system
% xref is the reference state to be tracked
% x0 is the initial state of the original system
% D is the disturbance of the original system
nx   = size(I,1);
Xmax = zeros((N+1)*nx,1);
Xmin = zeros((N+1)*nx,1);
for k=1:nx:(nx*N+1)
    Xmax(k:k+nx-1,:)=xmax;
    Xmin(k:k+nx-1,:)=xmin;
end
Sx_final = Sx((nx*N+1):nx*(N+1),:);
Su_final = Su((nx*N+1):nx*(N+1),:);
Sd_final = Sd((nx*N+1):nx*(N+1),:);

Hqp  = Su_final.'*Su_final;
fqp  = Su_final.'*(Sx_final*x0+Sd_final*D-xref);
Aqp  = [Su;-Su];
bqp  = [Xmax-Sx*x0-Sd*D;Sx*x0+Sd*D-Xmin];
