%% Configuration codes 
clear all
jointNum=4;   %10
torqueLimit=[10;10;10;5];
% jointName=["LeftHip_joint","LeftWheel_joint","RightHip_joint",...
%     "RightWheel_joint","Tail_joint","Shoulder_joint","Elbow_joint","Wrist_joint"]; 
jointName=["LeftWheel_joint","RightWheel_joint","Tail_joint","Wrist_joint"];  
%jointName=["LeftWheel_joint","RightWheel_joint","Tail_joint","Wrist_joint"];  
displayOn=true;
torque=zeros(jointNum,1); 


%% Connect to the Vrep
% 1. load api library
vrep=remApi('remoteApi'); % using the prototype file (remoteApiProto.m)
% 2. close all the potential link
vrep.simxFinish(-1);   
% 3. wait for connecting vrep, detect every 0.2s
while true
    clientID=vrep.simxStart('127.0.0.1',19997,true,true,5000,5);
    if clientID>-1 
        break;
    else
        pause(0.2);
        disp('please run the simulation on vrep...')
    end
end
disp('Connection success!')
% 4. set the simulation time step
tstep = 0.005;  % 5ms per simulation pass
vrep.simxSetFloatingParameter(clientID,vrep.sim_floatparam_simulation_time_step,tstep,vrep.simx_opmode_oneshot);
% 5. open the synchronous mode to control the objects in vrep
vrep.simxSynchronous(clientID,true);

%% Simulation Initialization
vrep.simxStartSimulation(clientID,vrep.simx_opmode_oneshot);
% get the handles
jointHandle=zeros(jointNum,1); 
for i=1:jointNum  % handles of the left and right arms
    [~,returnHandle]=vrep.simxGetObjectHandle(clientID,char(jointName(i)),vrep.simx_opmode_blocking);
    jointHandle(i)=returnHandle;
end
% set the target velocity to 0.1 and torque to 0
for i=1:jointNum
    vrep.simxSetJointForce(clientID,jointHandle(i),0,vrep.simx_opmode_oneshot);
    vrep.simxSetJointTargetVelocity(clientID,jointHandle(i),0.1,vrep.simx_opmode_oneshot);
end
baseName='Body_link_visual';
wheelName='RightWheel_link_visual';
wheelleft='LeftWheel_link_visual';
Shankleft='LeftShank_link_visual';
Shankright='RightShank_link_visual';
[~,baseHandle]=vrep.simxGetObjectHandle(clientID,baseName,vrep.simx_opmode_blocking);  
[~,wheelHandle]=vrep.simxGetObjectHandle(clientID,wheelName,vrep.simx_opmode_blocking);  
[~,wheelleftHandle]=vrep.simxGetObjectHandle(clientID,wheelleft,vrep.simx_opmode_blocking);  
[~,ShankleftHandle]=vrep.simxGetObjectHandle(clientID,Shankleft,vrep.simx_opmode_blocking);  
[~,ShankrightHandle]=vrep.simxGetObjectHandle(clientID,Shankright,vrep.simx_opmode_blocking);  
vrep.simxSynchronousTrigger(clientID);
disp('Handles available!')
% first call to read the joints' configuration and end-effector pose, the mode is chosen to be simx_opmode_streaming
jointConfig=zeros(jointNum,1); 
% get current joint position
for i=1:jointNum
    [~,jpos]=vrep.simxGetJointPosition(clientID,jointHandle(i),vrep.simx_opmode_streaming);
     if i>=1 && i<=3
               jointConfig(i)=-jpos; 
            else
               jointConfig(i)=jpos;
            end
end

% get simulation time
currCmdTime=vrep.simxGetLastCmdTime(clientID);

lastCmdTime=currCmdTime;
jointConfig0=jointConfig;
jointConfigLast=jointConfig;%-[0;0;43;43;0;0];
[~,baseposition0]=vrep.simxGetObjectPosition(clientID,baseHandle,-1,vrep.simx_opmode_streaming);% defined in inertial frame
[~,wheelposition0]=vrep.simxGetObjectPosition(clientID,wheelHandle,-1,vrep.simx_opmode_streaming);
[~,wheelleftposition0]=vrep.simxGetObjectPosition(clientID,wheelleftHandle,-1,vrep.simx_opmode_streaming);  
[~,Shankleftposition0]=vrep.simxGetObjectPosition(clientID,ShankleftHandle,-1,vrep.simx_opmode_streaming);  
[~,Shankrightposition0]=vrep.simxGetObjectPosition(clientID,ShankrightHandle,-1,vrep.simx_opmode_streaming);  

 pause(0.1)
[~,baseposition0]=vrep.simxGetObjectPosition(clientID,baseHandle,-1,vrep.simx_opmode_buffer);% defined in inertial frame
[~,wheelposition0]=vrep.simxGetObjectPosition(clientID,wheelHandle,-1,vrep.simx_opmode_buffer);
[~,wheelleftposition0]=vrep.simxGetObjectPosition(clientID,wheelleftHandle,-1,vrep.simx_opmode_buffer);  
[~,Shankleftposition0]=vrep.simxGetObjectPosition(clientID,ShankleftHandle,-1,vrep.simx_opmode_buffer);  
[~,Shankrightposition0]=vrep.simxGetObjectPosition(clientID,ShankrightHandle,-1,vrep.simx_opmode_buffer);  
 deltaposition0 = baseposition0-wheelposition0; % position of pendulum relative to the wheel
r = 0.1;%radius of wheel
d = 0.167;%distance from the wheel to the center of body
m = 9;%mass excluding the shanklinks and wheels
g = 9.8;
L2= 0.3;%length of Thighlink
yawangle0 = (jointConfigLast(2)-jointConfigLast(1))*r/(2*d);% yaw angle obtained by the difference of the wheel rotation angles
px0 = deltaposition0(1)
py0 = deltaposition0(2)
pz0 = deltaposition0(3)
thetaLast = atan((px0*cos(yawangle0)-py0*sin(yawangle0))/pz0);
vrep.simxSynchronousTrigger(clientID);         % every calls this function, verp is triggered, 50ms by default

%% Simulation Start
t=0;  % start the simulation
k=1;
kdl=12;%PID gain for left knee joint
kpl=50;
kil=0.1;
kdr=6;
kpr=26;
kir=0.1;
errorintegl=0;%angle error integration
errorintegr=0;
theta10l = -45/180*pi;
theta10r = -45/180*pi;
kt = 0/180*pi;%angle change rate
basepositionLast=baseposition0;
dqLast = zeros(6,1);
xref = [0;0;0.5;0;0;0];
while (vrep.simxGetConnectionId(clientID) ~= -1)  % vrep connection is still active
    % time update
    currCmdTime=vrep.simxGetLastCmdTime(clientID);
    dt=(currCmdTime-lastCmdTime)/1000;              % simulation step, unit: s 
    % read the joints' and tips' configuration (position and velocity)
    for i=1:jointNum
        [~,jpos]=vrep.simxGetJointPosition(clientID,jointHandle(i),vrep.simx_opmode_buffer);
         if i>=1 && i<=3
               jointConfig(i)=-jpos; 
            else
               jointConfig(i)=jpos;
            end
    end
    jointConfig=jointConfig;%-[0;0;43;43;0;0];
    [~,baseposition]=vrep.simxGetObjectPosition(clientID,baseHandle,-1,vrep.simx_opmode_buffer);% defined in inertial frame
    [~,wheelposition]=vrep.simxGetObjectPosition(clientID,wheelHandle,-1,vrep.simx_opmode_buffer);
    [~,wheelleftposition]=vrep.simxGetObjectPosition(clientID,wheelleftHandle,-1,vrep.simx_opmode_buffer);  
    [~,Shankleftposition]=vrep.simxGetObjectPosition(clientID,ShankleftHandle,-1,vrep.simx_opmode_buffer);  
    [~,Shankrightposition]=vrep.simxGetObjectPosition(clientID,ShankrightHandle,-1,vrep.simx_opmode_buffer);  
    % tilt angle
    BasePosition(:,k)=baseposition.';%save the absolute baseposition
    vbase = (baseposition.'-basepositionLast)/dt;
    gapl  = jointConfigLast(1)-jointConfig(1);
    gapr  = jointConfigLast(2)-jointConfig(2);
    if gapl<=-5 %remove the gap between two wheel angles
        jointConfig(1)=jointConfig(1)-round(abs(gapl)/(2*pi))*2*pi;
    end
    if gapr<=-5
        jointConfig(2)=jointConfig(2)-round(abs(gapr)/(2*pi))*2*pi;
    end
    Jointangle(:,k)=jointConfig;%save the joint angles in joint space
    deltaposition = baseposition-wheelposition; % position of pendulum relative to the wheel
    yawangle = (jointConfig(2)-jointConfig(1))*r/(2*d);% yaw angle obtained by the difference of the wheel rotation angles
    px = deltaposition(1);
    py = deltaposition(2);
    pz = deltaposition(3);
    theta = atan((px*cos(yawangle)-py*sin(yawangle))/pz);
    Tiltangle(k)=theta;
    dtheta=(theta-thetaLast)/dt;
    positionswleft=Shankleftposition-wheelleftposition;
    positionswright=Shankrightposition-wheelposition;
    pswlx = positionswleft(1);
    pswly = positionswleft(2);
    pswlz = positionswleft(3);
    pswrx = positionswright(1);
    pswry = positionswright(2);
    pswrz = positionswright(3);
    theta0l = atan(-pswlz/(pswlx*cos(yawangle)-pswly*sin(yawangle)));%tilting angle of Shankleft
    theta0r = atan(-pswrz/(pswrx*cos(yawangle)-pswry*sin(yawangle)));%tilting angle of Shankright
    % using Finit Difference Method to get the velocity of joints' configuration (a simple version)
    q=jointConfig;       dq=(q-jointConfigLast)./dt;  % column vector
%     if abs(dq(3)-dqLast(3))>=10 || abs(dq(4)-dqLast(4))>=10 %smooth the dq
%         dq(3)=dqLast(3);
%         dq(4)=dqLast(4);
%     end
    dyaw = r/(2*d)*(dq(2)-dq(1));
    Yawrate(k)=dyaw;
    Qdot(:,k)=dq;
    v    = r/2*(dq(1)+dq(2));
    vb    = sqrt(vbase(1)^2+vbase(2)^2);
    Vb(k) = vb;
    Vw(k) = v;
    x    = [theta;q(3);v;dyaw;dtheta;dq(3)];
    %control gain for the LQR controller
    l1   =sqrt(px^2+pz^2);%length of the pendulum
    if l1>=0.6
        L1=0.6;
    elseif l1<=0.3
        L1=0.3;
    else
        L1=l1;
    end
    i=round((L1-0.3)/0.5);
switch i
     case{0}
        K=[-10.229308273239681  -0.123530879374357  -0.700333617955963  -0.707106781186547 -1.209894533778420   0.072552373369506;
           -10.229308273239679  -0.123530879374357  -0.700333617955962   0.707106781186548 -1.209894533778419   0.072552373369506;
             1.435266856965589   2.046983831947172   0.138078409323903  -0.000000000000000  0.264409190357644   1.010350615144497];
    case{1}
        K=[-10.696897159228234  -0.113218924534403  -0.701853557042230  -0.707106781186547 -1.310836490827061   0.062211843328383;
           -10.696897159228230  -0.113218924534403  -0.701853557042230   0.707106781186548 -1.310836490827062   0.062211843328383;   
             1.318558047239075   2.046612564614754   0.121668274148742  -0.000000000000000  0.253259157833605   1.011673816366744];
    case{2}
        K=[-11.090977167893406  -0.104701989863920  -0.702921591289005  -0.707106781186547 -1.411408313876019   0.053966472412664;
           -11.090977167893412  -0.104701989863921  -0.702921591289006   0.707106781186548 -1.411408313876020   0.053966472412663;
             1.219169855310144   2.046519371987531   0.108639187218292   0.000000000000000  0.243972239966854   1.012580499268344];
    case{3}
        K=[-11.430226012056963  -0.097502490540527  -0.703696753440622  -0.707106781186548 -1.511320209999314   0.047280728064622;
           -11.430226012056966  -0.097502490540527  -0.703696753440623   0.707106781186547 -1.511320209999315   0.047280728064622;
             1.134157737649619   2.046580755108234   0.098090562207748   0.000000000000000  0.236139377309338   1.013218970041879];
    case{4}
        K=[-11.727414536620660  -0.091316295520719  -0.704275479132159  -0.707106781186547 -1.610427302243577   0.041772518163482;
           -11.727414536620655  -0.091316295520719  -0.704275479132158   0.707106781186548 -1.610427302243577   0.041772518163481;
             1.060912382135011   2.046728393703824   0.089398540180193   0.000000000000000  0.229447066562001   1.013679937732178];
    case{5}
        K=[-11.991571840343697  -0.085934288378535  -0.704718242987142  -0.707106781186547 -1.708667779912689   0.037168255980215;
           -11.991571840343704  -0.085934288378533  -0.704718242987143   0.707106781186547 -1.708667779912691   0.037168255980216;
             0.997293867510787   2.046923018506605   0.082124271699798  -0.000000000000000  0.223659924035998   1.014020186844553];
    case{6}
        K=[-12.229265815461252  -0.081204891026407  -0.705064226001728  -0.707106781186547 -1.806027714903048   0.033269529305341;
           -12.229265815461261  -0.081204891026408  -0.705064226001729   0.707106781186548 -1.806027714903049   0.033269529305341;
             0.941592536824500   2.047141458534336   0.075953106751385   0.000000000000001  0.218600948742279   1.014276228182529];
    otherwise
    K=[-11.430226012056963  -0.097502490540527  -0.703696753440622  -0.707106781186548 -1.511320209999314   0.047280728064622;
           -11.430226012056966  -0.097502490540527  -0.703696753440623   0.707106781186547 -1.511320209999315   0.047280728064622;
             1.134157737649619   2.046580755108234   0.098090562207748   0.000000000000000  0.236139377309338   1.013218970041879];     
end 
    
     torq = -K*(x-xref);%control torque obtained by LQR for wheel motors and pendulum motor
     theta1dl =theta10l-kt*t;%desired left knee angle
     theta1dr =theta10r-kt*t;%desired right knee angle
     if theta1dl<=-80/180*pi && theta1dr<=-80/180*pi
         t1dl=-80/180*pi;
         t1dr=-80/180*pi;
     else
         t1dl=theta1dl;
         t1dr=theta1dr;
     end
     Desiredt1l(k)=t1dl;
     Hl       =-1/2*m*g*L2*sin(theta0l+t1dl);
     Hr       =-1/2*m*g*L2*sin(theta0r+t1dr);
     torqlknee=Hl+kdl*(-kt-dq(1))+kpl*(t1dl-q(1))+kil*errorintegl;
     torqrknee=Hr+kdr*(-kt-dq(2))+kpl*(t1dr-q(2))+kir*errorintegr; 
     Error(k)=t1dl-q(1);
   %if t<=2 || t>=2.1
     if torqlknee>=50||torqlknee<=-50
         Torqlknee=Hl;
     else
         Torqlknee=torqlknee;
     end
     if torqrknee>=50||torqrknee<=-50
         Torqrknee=Hr;
     else
         Torqrknee=torqrknee;
     end
%      if torq(1)>=10
%          torql=10;
%      elseif torq(1)<=-10
%          torql=-10;
%      else
%          torql=torq(1);
%      end
%      if torq(2)>=10
%          torqr=10;
%      elseif torq(2)<=-10
%          torqr=-10;
%      else
%          torqr=torq(2);
%      end
  % else
      % Torqlknee=50;
      % Torqrknee=50;
  % end
  torql=torq(1);
  torqr=torq(2);
     k=k+1;
    torque = [-torql;-torqr;-torq(3);0];
    %torque = [torq(1);torq(2);-torq(3);0.1];
    Torque(:,k)=torque;
    %torque = [1;1;1];
    % 2. display the acquisition data, or store them if plotting is needed.
    if displayOn==true
        disp('joints config:');       disp(q'.*180/pi);
        disp('joints dconfig:');      disp(dq'.*180/pi);
    end

    %torque=[20,20,10];

    %   3.3 set the torque in vrep way
    for i=1:jointNum
        if sign(torque(i))<0
            setVel=-9999; % set a trememdous large velocity for the screwy operation of the vrep torque control implementaion
            if torque(i)<-torqueLimit(i)
                setTu=-torqueLimit(i);
            else
                setTu=-torque(i);
            end
        else
            setVel=9999;
            if torque(i)>torqueLimit(i)
                setTu=torqueLimit(i);
            else
                setTu=torque(i);
            end
        end
        vrep.simxSetJointTargetVelocity(clientID,jointHandle(i),setVel,vrep.simx_opmode_oneshot);
        vrep.simxSetJointForce(clientID,jointHandle(i),setTu,vrep.simx_opmode_oneshot);
    end

    % data recording for plotting
%     E=[E qe];    Q=[Q q];        QD=[QD qd];
%     DQ=[DQ dq];  DQD=[DQD dqd];  TAU=[TAU torque];

    % 4. update vrep(the server side)
    %tipPosLast=tipPos;       
    %tipOrtLast=tipOrt;
    lastCmdTime=currCmdTime;
    jointConfigLast=jointConfig;   
    basepositionLast=baseposition.';
    thetaLast=theta;
    dqLast=dq;
    errorintegl=errorintegl+(t1dl-q(1))*dt;
    errorintegr=errorintegr+(t1dr-q(2))*dt;
    vrep.simxSynchronousTrigger(clientID);
    t=t+dt; % updata simulation time
end
vrep.simxFinish(-1);  % close the link
vrep.delete();        % destroy the 'vrep' class

%%
% figure(1); hold off;
% subplot(411); plot(E(1,:),'r'); hold on; plot(E(2,:),'b'); title('error')
% subplot(412); plot(Q(1,:),'r'); hold on; plot(Q(2,:),'b');  plot(QD(1,:),'k'); hold on; plot(QD(2,:),'k'); title('trajectory')
% subplot(413); plot(DQ(1,:),'r'); hold on; plot(DQ(2,:),'b');  plot(DQD(1,:),'k'); hold on; plot(DQD(2,:),'k'); title('velocity')
% subplot(414); plot(TAU(1,:),'r'); hold on; plot(TAU(2,:),'b'); title('torque')

